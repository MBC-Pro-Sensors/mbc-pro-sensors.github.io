# Python Library for MBC Line Tracer 16CH for Pybricks SPIKE Prime
# Author : MBC robotics
# Date   : 2026.10
# v4.0.1 (2026.10): + line_device_id() / line_firmware_version() and line16.device_id() / .firmware_version()
#                   (read SPIKE mode 8 = [ID word, protocol ver, firmware word, counter]; firmware 2026-10 or later).
#                   Everything that reads mode 9 is unchanged.
#
# !! Import this file MBC_line16_Lib.py into your Pybricks editor !!
#
# Port mapping (port= argument):
#   1 → Port.A,  2 → Port.B,  3 → Port.C,
#   4 → Port.D,  5 → Port.E,  6 → Port.F

from pybricks.iodevices import PUPDevice
from pybricks.parameters import Port
from pybricks.tools import StopWatch as _StopWatch

# ════════════════════════════════════════════════════════════════
#  Port number → Port object mapping (SPIKE Prime: 1~6 = A~F)
# ════════════════════════════════════════════════════════════════

_PORT_MAP = {
    1: Port.A,
    2: Port.B,
    3: Port.C,
    4: Port.D,
    5: Port.E,
    6: Port.F,
}

_PORT_LETTER = {1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'E', 6: 'F'}

# ════════════════════════════════════════════════════════════════
#  Packet layout (mode 9, 16 bytes raw → 8 int16 from Pybricks)
#
#  word[0] : buf[0]=IR_calib(ch0,ch1), buf[1]=IR_calib(ch2,ch3)
#  word[1] : buf[2]=IR_calib(ch4,ch5), buf[3]=IR_calib(ch6,ch7)
#  word[2] : buf[4]=IR_calib(ch8,ch9), buf[5]=IR_calib(ch10,ch11)
#  word[3] : buf[6]=IR_calib(ch12,ch13),buf[7]=IR_calib(ch14,ch15)
#  word[4] : buf[8]=linePos16+16, buf[9]=lineWidth
#  word[5] : buf[10]=linePos100+100, buf[11]=binGroupCount
#  word[6] : buf[12]=binRaw_lo,  buf[13]=binRaw_hi
#  word[7] : buf[14]=0(unused),  buf[15]=0(unused)
# ════════════════════════════════════════════════════════════════

_MODE = 9

def _u16(word):
    """Convert signed int16 (from Pybricks) to unsigned uint16."""
    return word & 0xFFFF if word < 0 else word

def _lo(word):
    return _u16(word) & 0xFF

def _hi(word):
    return (_u16(word) >> 8) & 0xFF

# ════════════════════════════════════════════════════════════════
#  PUPDevice is built lazily, only for the port actually passed to
#  line_init_port_multitask() -- never touches the other 5 ports.
#  ★ For multitask=True, call line_init_port_multitask() at the top level,
#    BEFORE run_task(main()) -- not from inside async def main(). Building
#    a device object after run_task() has started is not safe (same rule
#    as MBC_LINE16/MBC_EXP6). For multitask=False (sync) this restriction
#    does not apply -- call it anywhere.
# ════════════════════════════════════════════════════════════════

_devices = {}

# ════════════════════════════════════════════════════════════════
#  Internal state
# ════════════════════════════════════════════════════════════════

_selected_dev  = None
_async_mode    = False
_selected_port = None

_JUNCTION_NAMES = {0: "none", 1: "line", 2: "junction"}

# ════════════════════════════════════════════════════════════════
#  Cache (Aligned with the 10ms sensor update cycle)
# ════════════════════════════════════════════════════════════════

_cache      = None
_cache_time = 0
_CACHE_MS   = 10
_watch      = _StopWatch()

async def _noop():
    pass

def _check_init():
    if _selected_dev is None:
        if _selected_port is None:
            raise RuntimeError(
                "Sensor not found. Please connect the sensor to the correct port."
            )
        letter = _PORT_LETTER.get(_selected_port, str(_selected_port))
        raise RuntimeError(
            "Sensor not found on Port {} (port={}). Please check the connection.".format(
                letter, _selected_port
            )
        )

# ════════════════════════════════════════════════════════════════
#  Parse helpers (Pure computation, shared by sync / async)
# ════════════════════════════════════════════════════════════════

def _parse_ir_calibration(p):
    """
    Unpack 16 IR calibration values (4-bit each, 0~15) from words 0~3.
    Returns list of 16 integers.
    Index 0 = channel 1 (leftmost), index 15 = channel 16 (rightmost).
    """
    values = []
    for word_idx in range(4):
        lo = _lo(p[word_idx])
        hi = _hi(p[word_idx])
        values.append( lo       & 0x0F)
        values.append((lo >> 4) & 0x0F)
        values.append( hi       & 0x0F)
        values.append((hi >> 4) & 0x0F)
    return values

def _parse_line_pos16(p):
    """linePos16: buf[8]-16, range -16~+16 (center=0)."""
    return _lo(p[4]) - 16

def _parse_line_width(p):
    """lineWidth: buf[9], raw channel count."""
    return _hi(p[4])

def _parse_line_pos100(p):
    """linePos100: buf[10]-100, range -100~+100."""
    return _lo(p[5]) - 100

def _parse_junction(p):
    """binGroupCount: buf[11]. 0=no line, 1=line, 2+=junction."""
    return _hi(p[5])

def _parse_bin_raw(p):
    """binRaw 16-bit: buf[12]=lo, buf[13]=hi."""
    return _lo(p[6]) | (_hi(p[6]) << 8)

def _parse_on_sensors(p):
    """List of 1-indexed channel numbers where line is detected."""
    raw = _parse_bin_raw(p)
    return [i + 1 for i in range(16) if raw & (1 << i)]

def _parse_junction_name(p):
    j = _parse_junction(p)
    return _JUNCTION_NAMES.get(min(j, 2), "junction")

def _parse_read_all(p):
    return {
        "ir_calibration": _parse_ir_calibration(p),
        "line_pos16":     _parse_line_pos16(p),
        "line_width":     _parse_line_width(p),
        "line_pos100":    _parse_line_pos100(p),
        "bin_raw":        _parse_bin_raw(p),
        "on_sensors":     _parse_on_sensors(p),
        "junction":       _parse_junction(p),
        "junction_name":  _parse_junction_name(p),
    }

# ★ Specific to line_ir_ch: 16 parsers are pre-created when the module is loaded, not at call time
def _make_ir_ch_parser(ch):
    def _parser(p):
        return _parse_ir_calibration(p)[ch - 1]
    return _parser

_IR_CH_PARSERS = [_make_ir_ch_parser(ch) for ch in range(1, 17)]  # index 0 = ch1

# ════════════════════════════════════════════════════════════════
#  Factory function: Pass in a parser to automatically generate a dual-mode + cache public function
#  sync mode  → returns the result directly
#  async mode → returns a coroutine (requires await)
#  cache      → reads hardware only once for multiple calls within 10ms
# ════════════════════════════════════════════════════════════════

def _make_sensor_func(parse_fn):
    async def _async():
        global _cache, _cache_time
        now = _watch.time()
        if _cache is None or (now - _cache_time) >= _CACHE_MS:
            _cache      = await _selected_dev.read(_MODE)
            _cache_time = now
        return parse_fn(_cache)

    def _func():
        global _cache, _cache_time
        _check_init()
        if _async_mode:
            return _async()
        now = _watch.time()
        if _cache is None or (now - _cache_time) >= _CACHE_MS:
            _cache      = _selected_dev.read(_MODE)
            _cache_time = now
        return parse_fn(_cache)

    return _func

# ════════════════════════════════════════════════════════════════
#  Public sensor functions
# ════════════════════════════════════════════════════════════════

line_ir_calibration = _make_sensor_func(_parse_ir_calibration)
line_pos16          = _make_sensor_func(_parse_line_pos16)
line_width          = _make_sensor_func(_parse_line_width)
line_pos100         = _make_sensor_func(_parse_line_pos100)
line_bin_raw        = _make_sensor_func(_parse_bin_raw)
line_on_sensors     = _make_sensor_func(_parse_on_sensors)
line_junction       = _make_sensor_func(_parse_junction)
line_junction_name  = _make_sensor_func(_parse_junction_name)
line_read_all       = _make_sensor_func(_parse_read_all)

# ★ Specific to line_ir_ch: 16 functions are pre-created when the module is loaded
_IR_CH_FUNCS = [_make_sensor_func(parser) for parser in _IR_CH_PARSERS]  # index 0 = ch1

def line_ir_ch(ch):
    """
    Returns IR calibration value of a single channel.
    ch    : int 1~16
    sync  : line_ir_ch(8)
    async : await line_ir_ch(8)
    ★ Shares cache; reads hardware only once for multiple calls within 10ms
    ★ Function objects are pre-created when the module is loaded; no new objects are created at call time
    """
    if ch < 1 or ch > 16:
        raise ValueError("ch must be 1~16, got {}".format(ch))
    return _IR_CH_FUNCS[ch - 1]()

# ════════════════════════════════════════════════════════════════
#  Extra mode (v4.0.1, 2026.10): mode 8 = identification
#    4 x int16: [ID word, protocol version, firmware word, update counter]
#    ID word : low byte = factory I2C address (0x16), high byte = hw[0] = 16 (channels)
#    firmware word = major*100 + minor (e.g. 100 = 1.0)
#  Reading another mode switches the sensor out of mode 9 for that one
#  read; the next mode-9 call switches it back (a few 10 ms). So call
#  these once at start-up, not inside the control loop. Each extra mode
#  has its own cache; the mode-9 cache above is untouched.
# ════════════════════════════════════════════════════════════════

_ID_MODE = 8

_mcache = {}   # mode -> (time_ms, raw tuple)

def _parse_device_id(v):
    """(id, hw0, firmware_word): e.g. (0x16, 16, 100). hw0 = 16 tells this is the 16-channel model."""
    w = _u16(v[0])
    return (w & 0xFF, (w >> 8) & 0xFF, _u16(v[2]))

def _parse_firmware_version(v):
    """(major, minor): e.g. (1, 0) for firmware 1.0."""
    fw = _u16(v[2])
    return (fw // 100, fw % 100)

def _make_mode_func(mode, parse_fn):
    """Same dual-mode + 10 ms cache pattern as _make_sensor_func, for another LUMP mode."""
    async def _async():
        now = _watch.time()
        e = _mcache.get(mode)
        if e is None or (now - e[0]) >= _CACHE_MS:
            e = (now, await _selected_dev.read(mode))
            _mcache[mode] = e
        return parse_fn(e[1])

    def _func():
        _check_init()
        if _async_mode:
            return _async()
        now = _watch.time()
        e = _mcache.get(mode)
        if e is None or (now - e[0]) >= _CACHE_MS:
            e = (now, _selected_dev.read(mode))
            _mcache[mode] = e
        return parse_fn(e[1])

    return _func

line_device_id        = _make_mode_func(_ID_MODE, _parse_device_id)
line_firmware_version = _make_mode_func(_ID_MODE, _parse_firmware_version)

# ════════════════════════════════════════════════════════════════
#  Initialization functions
# ════════════════════════════════════════════════════════════════

def line_init_port_multitask(port, multitask=False):
    """
    Initialize sensor and select mode.
      port      : int 1~6  (1=A, 2=B, 3=C, 4=D, 5=E, 6=F)
      multitask : bool, True for use inside async/multitask programs

    ★ For multitask=True, call this at the top level BEFORE run_task(main()),
    not from inside async def main() -- building the port's device object
    must happen before the event loop starts (same rule as MBC_LINE16(...)).
    Only the requested port is touched; the other 5 ports are left alone.
    Returns an awaitable no-op so it can safely be used with
    'await line_init_port_multitask(...)'.
    """
    global _selected_dev, _async_mode, _selected_port
    global _cache, _cache_time
    _selected_port = port
    _async_mode    = bool(multitask)
    _cache         = None   # ★ Cache resets upon port switch
    _cache_time    = 0
    if port not in _devices:
        try:
            _devices[port] = PUPDevice(_PORT_MAP[port])
        except Exception:
            _devices[port] = None
    _selected_dev = _devices.get(port)
    return _noop()

# ════════════════════════════════════════════════════════════════
#  Object-style API (MBC_LINE16 class)
#
#  Same reason MBC_EXP6 is a class: graphical block tools place object
#  construction ("object block") in the Setup canvas, before run_task(),
#  while the free functions above are called from an "imported function"
#  block that only lands inside async def main() (after run_task() has
#  already started). Building a PUPDevice there is too late/unsafe.
#
#  MBC_LINE16(port, multitask) builds a PUPDevice for ONLY that one port,
#  in __init__ (before run_task()) -- it never touches the other 5 ports,
#  so it can't collide with another device (e.g. an EXP6 board) that is
#  already streaming on one of them.
#
#  Kept fully independent of the module-level globals above so mixing the
#  old function-style calls with this class in the same program can't
#  cause cross-talk.
# ════════════════════════════════════════════════════════════════

class MBC_LINE16:
    def __init__(self, port, multitask=False):
        self._selected_port = port
        self._async_mode    = bool(multitask)
        self._cache         = None
        self._cache_time    = 0
        try:
            self._selected_dev = PUPDevice(_PORT_MAP[port])
        except Exception:
            self._selected_dev = None

    def _check_init(self):
        if self._selected_dev is None:
            letter = _PORT_LETTER.get(self._selected_port, str(self._selected_port))
            raise RuntimeError(
                "Sensor not found on Port {} (port={}). Please check the connection.".format(
                    letter, self._selected_port
                )
            )

    async def _read_async(self):
        now = _watch.time()
        if self._cache is None or (now - self._cache_time) >= _CACHE_MS:
            self._cache      = await self._selected_dev.read(_MODE)
            self._cache_time = now
        return self._cache

    def _read_sync(self):
        now = _watch.time()
        if self._cache is None or (now - self._cache_time) >= _CACHE_MS:
            self._cache      = self._selected_dev.read(_MODE)
            self._cache_time = now
        return self._cache

    def _get(self, parse_fn):
        self._check_init()
        if self._async_mode:
            return self._get_async(parse_fn)
        return parse_fn(self._read_sync())

    async def _get_async(self, parse_fn):
        return parse_fn(await self._read_async())

    def ir_calibration(self):
        return self._get(_parse_ir_calibration)

    def pos16(self):
        return self._get(_parse_line_pos16)

    def width(self):
        return self._get(_parse_line_width)

    def pos100(self):
        return self._get(_parse_line_pos100)

    def bin_raw(self):
        return self._get(_parse_bin_raw)

    def on_sensors(self):
        return self._get(_parse_on_sensors)

    def junction(self):
        return self._get(_parse_junction)

    def junction_name(self):
        return self._get(_parse_junction_name)

    def read_all(self):
        return self._get(_parse_read_all)

    def ir_ch(self, ch):
        """
        Returns IR calibration value of a single channel (0~15).
        ch : int 1~16  (1=leftmost, 16=rightmost)
        """
        if ch < 1 or ch > 16:
            raise ValueError("ch must be 1~16, got {}".format(ch))
        return self._get(_IR_CH_PARSERS[ch - 1])

    # ---- extra modes (v4.0.1, 2026.10): own cache per mode; the mode-9 methods above are unchanged ----
    def _mode_cache(self):
        try:
            return self._mcache
        except AttributeError:
            self._mcache = {}
            return self._mcache

    async def _read_mode_async(self, mode):
        c = self._mode_cache()
        now = _watch.time()
        e = c.get(mode)
        if e is None or (now - e[0]) >= _CACHE_MS:
            e = (now, await self._selected_dev.read(mode))
            c[mode] = e
        return e[1]

    def _read_mode_sync(self, mode):
        c = self._mode_cache()
        now = _watch.time()
        e = c.get(mode)
        if e is None or (now - e[0]) >= _CACHE_MS:
            e = (now, self._selected_dev.read(mode))
            c[mode] = e
        return e[1]

    def _get_mode(self, mode, parse_fn):
        self._check_init()
        if self._async_mode:
            return self._get_mode_async(mode, parse_fn)
        return parse_fn(self._read_mode_sync(mode))

    async def _get_mode_async(self, mode, parse_fn):
        return parse_fn(await self._read_mode_async(mode))

    def device_id(self):
        """(id, hw0, firmware_word) from mode 8, e.g. (22, 16, 100): id 0x16, 16 channels, firmware 1.0."""
        return self._get_mode(_ID_MODE, _parse_device_id)

    def firmware_version(self):
        """(major, minor) from mode 8, e.g. (1, 0)."""
        return self._get_mode(_ID_MODE, _parse_firmware_version)

# ════════════════════════════════════════════════════════════════
#  MBC_LINE16 -- callable methods (object-style API)
#
#  line16 = MBC_LINE16(port, multitask)   -- call BEFORE run_task(main())
#    port      : int 1~6  (1=A, 2=B, 3=C, 4=D, 5=E, 6=F)
#    multitask : False -> sync (call methods directly)
#                True  -> async (await every method call)
#
#  line16.pos16()            -16~+16   line position, coarse (center=0)
#  line16.pos100()           -100~+100  line position, high-resolution (center=0)
#  line16.width()            0~16     number of triggered sensors
#  line16.bin_raw()          0~65535  raw 16-bit sensor bitmap
#  line16.on_sensors()       [int]    1-indexed channels currently on the line
#  line16.junction()         0~2+     0=no line, 1=single line, 2+=junction
#  line16.junction_name()    str      "none" / "line" / "junction"
#  line16.ir_calibration()   [int]*16 all 16 channels' calibrated IR value (0~15)
#  line16.ir_ch(ch)          0~15     single channel's calibrated IR value, ch=1~16
#  line16.read_all()         dict     all of the above in one dict, one hardware read
#  line16.device_id()        tuple    (id, hw0, firmware_word) from mode 8, e.g. (22, 16, 100)  [v4.0.1]
#  line16.firmware_version() tuple    (major, minor) from mode 8, e.g. (1, 0)                 [v4.0.1]
#
#  Example (sync):
#      line16 = MBC_LINE16(3, False)
#      print(line16.pos16(), line16.width())
#
#  Example (async / multitask):
#      line16 = MBC_LINE16(3, True)
#      async def main():
#          print(await line16.pos16(), await line16.width())
#      run_task(main())
# ════════════════════════════════════════════════════════════════