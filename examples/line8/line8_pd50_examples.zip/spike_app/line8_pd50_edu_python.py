# 循行者 8 路 PD 循線示範（速度 50）× 樂高官方 SPIKE App 3 教育版 Python
# Pathfinder 8 PD line following demo (speed 50) × LEGO SPIKE App 3 (Education), Python
# 接線：循行者 → C 孔；左馬達 → E 孔；右馬達 → F 孔。左右兩顆馬達裝的方向相反，左馬達要給「負的」功率車子才會往前
# Wiring: sensor → C, left motor → E, right motor → F. The motors face opposite ways: give the left motor NEGATIVE power to drive forward
# 方向：站在車後往前看，線在左＝負 → 左輪慢、右輪快 → 往左轉／line on the left = negative → left wheel slower → turns left
# KP、KD 是建議值，請在你的車上調整／KP and KD are starting values, tune them on your robot
# 積木版：同名的 .llsp3 檔／Block version: the matching .llsp3 file
# ===== 循行者 8 路 讀值小工具（樂高官方 SPIKE App 3 教育版 Python，照抄就好、不用改）=====
# ===== Pathfinder 8-Way reading helper (LEGO SPIKE App 3, Education, Python: copy as is) =====
# 循行者在 SPIKE App 裡是「顏色感應器」：顏色＝線寬、反射光＝粗位置＋8、原始紅＝細位置＋100。
# In the SPIKE App the Pathfinder is a colour sensor: colour = line width, reflection = position + 8, raw red = fine position + 100.
# 原始綠、藍放的是 8 路光值（壓成 4 bit），這個小工具不拆；要每一路的光值請改用 Pybricks。
# Raw green and blue hold the 8 channel readings (4 bits each); this helper does not split them. Use Pybricks for those.
# 站在車後往前看：線在左＝負、在右＝正 / seen from behind the robot: line on the left = negative
import color_sensor


class Line8App:
    def __init__(self, port_number):
        self.port = port_number
        self.b = [0] * 8                      # byte 0~7

    def update(self):
        """讀一次最新資料 / read once"""
        c = color_sensor.color(self.port)              # byte 0 = 線寬 / line width
        r = color_sensor.reflection(self.port)         # byte 1 = 粗位置＋8 / position + 8
        rgb = color_sensor.rgbi(self.port)             # 原始紅、綠、藍（各 2 byte）/ raw red, green, blue
        b = [int(c) & 255, int(r) & 255]
        for v in rgb[:3]:
            v = int(v) & 0xFFFF                        # 負數也換回 0~65535 / negatives back to 0~65535
            b += [v & 255, v >> 8]
        self.b = b
        return True

    def _w(self, i):
        # 原始紅（i=0）、綠（1）、藍（2）的 0~65535 / raw red, green, blue word
        return self.b[2 + 2 * i] | (self.b[3 + 2 * i] << 8)

    def pos8(self):
        """粗位置 −8~+8，0＝正中間；看不到線時停在最後離開的那一側 / position −8~+8, 0 = centre; keeps the last side when the line is lost"""
        return self.b[1] - 8

    def pos100(self):
        """細位置 −100~+100，循線用這個比較順 / fine position −100~+100, smoother for line following"""
        return self._w(0) - 100

    def width(self):
        """線寬 0~8：幾路踩在線上，0＝看不到線 / line width 0~8: channels on the line, 0 = no line"""
        return self.b[0]
# ===== 小工具到這裡結束 / end of helper =====

from hub import port
import motor
import runloop

line8 = Line8App(port.C)
SPEED = 50     # 前進速度（%）／forward speed (%)
KP = 0.4       # 轉彎靈敏度：車子左右甩就調小／steering gain: lower it if the robot wobbles
KD = 1.5       # 抑制甩動：轉彎太慢就調小／damping: lower it if turns are too slow
CROSS = 5    # 線寬大於這個值＝十字路口（整排踩到線）：停車／wider than this = crossing: stop


async def main():
    last = 0
    while True:
        line8.update()
        error = line8.pos100()     # 細位置 −100~100（線在左＝負）／fine position, left = negative
        width = line8.width()      # 線寬：幾路踩在線上／line width
        if width > CROSS:
            motor.stop(port.E)
            motor.stop(port.F)
        else:
            PD = error * KP + (error - last) * KD     # P：偏多少轉多少；D：偏移變快時多轉一點
            last = error
            motor.set_duty_cycle(port.E, int(-(SPEED + PD) * 100))   # 左馬達裝反了：給負的（功率 % × 100）
            motor.set_duty_cycle(port.F, int((SPEED - PD) * 100))
        await runloop.sleep_ms(10)

runloop.run(main())
