/**
 * @file MiniR4ColorSensorExt.h
 * @brief Matric Color Sensor functions.
 * @author MATRIX Robotics
 */

#ifndef _MiniR4ColorSensorExt_H_
#define _MiniR4ColorSensorExt_H_

#include <Arduino.h>
#include <Wire.h>

#ifndef ADDR_PCA954X
#define ADDR_PCA954X 0x70
#endif

#define MatrixColor_ADDR 0x22

// Color ID definitions
#define COLOR_BLACK 0
#define COLOR_VIOLET 1
#define COLOR_BLUE 3
#define COLOR_LIGHTBLUE 4
#define COLOR_GREEN 6
#define COLOR_YELLOW 7
#define COLOR_RED 9
#define COLOR_WHITE 10
#define COLOR_NONE -1

typedef enum __ColorType { R = 4, G, B, C, M, Y, K } ColorType;

/**
 * @brief 圖形化積木對應功能與回傳值
 * 
 * ColorID:    24筆資料讀取位置歸零 (回傳值：系統狀態碼 Byte 24)
 * Red:        24筆資料讀取位置往下移動一個型態 (回傳值：移動後的指標位置 Index)
 * 
 * Green:      讀取形態一個Byte 　→ int8 (-128 ~ 127)
 * Blue:       讀取形態一個Byte　→ uint8 (0 ~ 255)
 * Hue:        讀取形態兩個Byte　→ int16 (-32768 ~ 32767)
 * Saturation: 讀取形態兩個Byte　→ uint16 (0 ~ 65535)
 * Value:      讀取形態四個Byte　→ float (單精度浮點數，IEEE 754 標準)
 * 
 * Cyan:       發送命令 0xF1 (並回傳：下位機額外擴充資料 1)
 * Magenta:    發送命令 0xF2 (並回傳：下位機額外擴充資料 2)
 * Yellow:     發送命令 0xF3 (並回傳：下位機額外擴充資料 3)
 * Key:        發送命令 0xF4 (並回傳：下位機額外擴充資料 4)
 * 
 * ====================================================================
 * LauMo 30 Bytes 下行數據封包結構 (I2C 讀取)
 * 下位機 (STM32) 在收到 I2C 位址 0x21 請求後，回傳連續的 30 Bytes：
 * 
 * [Byte 0 ~ 23]：共 24 Bytes。純資料串流區 (供 Green ~ Value 積木根據指標位置讀取)。
 * [Byte 24]：共 1 Byte。系統狀態碼 (呼叫 ColorID 時回傳)。
 * [Byte 25]：共 1 Byte。額外擴充資料 1 (呼叫 Cyan 時回傳)。
 * [Byte 26]：共 1 Byte。額外擴充資料 2 (呼叫 Magenta 時回傳)。
 * [Byte 27]：共 1 Byte。額外擴充資料 3 (呼叫 Yellow 時回傳)。
 * [Byte 28]：共 1 Byte。額外擴充資料 4 (呼叫 Key 時回傳)。
 * [Byte 29]：共 1 Byte。CRC-8 校驗碼 (負責保護前面的 Byte 0 ~ 28 總計 29 個 Bytes)。
 */

/**
 * @brief Class for interacting with a color sensor.
 *
 * This class provides methods to initialize the sensor, configure settings,
 * and retrieve color values from the sensor.
 */
class MatrixColor {
private:
  typedef enum __ColorRegType {
    Device_ID = 1,
    Device_CONFIG,
    Device_LIGHT,
    Device_RED,
    Device_GREEN,
    Device_BLUE,
    Device_CYAN,
    Device_MAGENTA,
    Device_YELLOW,
    Device_BLACK,
    Device_GRAY,
    Device_NUM_COLOR
  } ColorRegType;

  uint8_t setting = 0x0F;
  uint8_t i2cReadData(ColorRegType reg);
  void i2cMUXSelect();
  void i2cWriteData(ColorRegType reg, uint8_t data);

  // LauMo Protocol variables
  uint8_t _sensorCache32[29] = {0}; // 24 bytes data + 1 byte status + 4 bytes feedback
  unsigned long _lastUpdate = 0;
  uint8_t _streamPtr = 0;
  uint8_t _stepSize = 0;
  static const uint8_t crc8_table[256];

  void fetchLineTracerData();

public:
  uint8_t _ch = 0;
  TwoWire *_pWire;

  /**
   * @brief Initializes the sensor.
   *
   * @return true if initialization was successful, false otherwise.
   */
  bool begin();

  /**
   * @brief Gets the value of a specific color from the sensor.
   *
   * @param color The color type to retrieve.
   * @return The value of the specified color.
   */
  float getColor(ColorType color);

  float getH();
  float getS();
  float getV();

  /**
   * @brief Get Color ID for easy color recognition.
   *
   * @return Color ID:
   *   -1 = No color (too dark or sensor error),
   *    0 = Black (Not easy to detect),
   *    1 = Violet,
   *    3 = Blue,
   *    4 = Light Blue (Cyan),
   *    6 = Green,
   *    7 = Yellow,
   *    9 = Red,
   *   10 = White,
   */
  float getColorID();
};

#endif