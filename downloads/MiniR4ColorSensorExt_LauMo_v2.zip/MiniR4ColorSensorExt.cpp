/**
 * @file MiniR4ColorSensorExt.cpp
 * @brief Matrix Color Sensor functions.
 * @author MATRIX Robotics
 */
#include "MiniR4ColorSensorExt.h"

const uint8_t MatrixColor::crc8_table[256] = {
    0x00, 0x07, 0x0e, 0x09, 0x1c, 0x1b, 0x12, 0x15, 0x38, 0x3f, 0x36, 0x31,
    0x24, 0x23, 0x2a, 0x2d, 0x70, 0x77, 0x7e, 0x79, 0x6c, 0x6b, 0x62, 0x65,
    0x48, 0x4f, 0x46, 0x41, 0x54, 0x53, 0x5a, 0x5d, 0xe0, 0xe7, 0xee, 0xe9,
    0xfc, 0xfb, 0xf2, 0xf5, 0xd8, 0xdf, 0xd6, 0xd1, 0xc4, 0xc3, 0xca, 0xcd,
    0x90, 0x97, 0x9e, 0x99, 0x8c, 0x8b, 0x82, 0x85, 0xa8, 0xaf, 0xa6, 0xa1,
    0xb4, 0xb3, 0xba, 0xbd, 0xc7, 0xc0, 0xc9, 0xce, 0xdb, 0xdc, 0xd5, 0xd2,
    0xff, 0xf8, 0xf1, 0xf6, 0xe3, 0xe4, 0xed, 0xea, 0xb7, 0xb0, 0xb9, 0xbe,
    0xab, 0xac, 0xa5, 0xa2, 0x8f, 0x88, 0x81, 0x86, 0x93, 0x94, 0x9d, 0x9a,
    0x27, 0x20, 0x29, 0x2e, 0x3b, 0x3c, 0x35, 0x32, 0x1f, 0x18, 0x11, 0x16,
    0x03, 0x04, 0x0d, 0x0a, 0x57, 0x50, 0x59, 0x5e, 0x4b, 0x4c, 0x45, 0x42,
    0x6f, 0x68, 0x61, 0x66, 0x73, 0x74, 0x7d, 0x7a, 0x89, 0x8e, 0x87, 0x80,
    0x95, 0x92, 0x9b, 0x9c, 0xb1, 0xb6, 0xbf, 0xb8, 0xad, 0xaa, 0xa3, 0xa4,
    0xf9, 0xfe, 0xf7, 0xf0, 0xe5, 0xe2, 0xeb, 0xec, 0xc1, 0xc6, 0xcf, 0xc8,
    0xdd, 0xda, 0xd3, 0xd4, 0x69, 0x6e, 0x67, 0x60, 0x75, 0x72, 0x7b, 0x7c,
    0x51, 0x56, 0x5f, 0x58, 0x4d, 0x4a, 0x43, 0x44, 0x19, 0x1e, 0x17, 0x10,
    0x05, 0x02, 0x0b, 0x0c, 0x21, 0x26, 0x2f, 0x28, 0x3d, 0x3a, 0x33, 0x34,
    0x4e, 0x49, 0x40, 0x47, 0x52, 0x55, 0x5c, 0x5b, 0x76, 0x71, 0x78, 0x7f,
    0x6a, 0x6d, 0x64, 0x63, 0x3e, 0x39, 0x30, 0x37, 0x22, 0x25, 0x2c, 0x2b,
    0x06, 0x01, 0x08, 0x0f, 0x1a, 0x1d, 0x14, 0x13, 0xae, 0xa9, 0xa0, 0xa7,
    0xb2, 0xb5, 0xbc, 0xbb, 0x96, 0x91, 0x98, 0x9f, 0x8a, 0x8d, 0x84, 0x83,
    0xde, 0xd9, 0xd0, 0xd7, 0xc2, 0xc5, 0xcc, 0xcb, 0xe6, 0xe1, 0xe8, 0xef,
    0xfa, 0xfd, 0xf4, 0xf3};

bool MatrixColor::begin() {
  _pWire->begin();
  i2cMUXSelect();
  delay(50);
  if (i2cReadData(Device_ID) == 0x43) {
    i2cWriteData(Device_CONFIG, 0x10); // 發送指令
    delay(100);
    i2cWriteData(Device_CONFIG, setting); // 發送設定 (0x0F)
    return true;
  } else {
    return false;
  }
}

float MatrixColor::getColor(ColorType color) {
  fetchLineTracerData();

  switch (color) {
  case R: {
    _streamPtr += _stepSize;
    if (_streamPtr >= 24)
      _streamPtr = 0;         // 防止溢位，自動循環歸零
    return (float)_streamPtr; // 回傳移動後的指標位置，作為教學除錯用
  }
  case G: {
    _stepSize = 1;
    if (_streamPtr > 23)
      return 0;
    return (float)*(int8_t *)(&_sensorCache32[_streamPtr]);
  }
  case B: {
    _stepSize = 1;
    if (_streamPtr > 23)
      return 0;
    return (float)*(uint8_t *)(&_sensorCache32[_streamPtr]);
  }
  case C:
    i2cMUXSelect();
    _pWire->beginTransmission(MatrixColor_ADDR);
    _pWire->write(0xF1);
    _pWire->endTransmission();
    return (float)_sensorCache32[25]; // 回傳額外擴充資料 1
  case M:
    i2cMUXSelect();
    _pWire->beginTransmission(MatrixColor_ADDR);
    _pWire->write(0xF2);
    _pWire->endTransmission();
    return (float)_sensorCache32[26]; // 回傳額外擴充資料 2
  case Y:
    i2cMUXSelect();
    _pWire->beginTransmission(MatrixColor_ADDR);
    _pWire->write(0xF3);
    _pWire->endTransmission();
    return (float)_sensorCache32[27]; // 回傳額外擴充資料 3
  case K:
    i2cMUXSelect();
    _pWire->beginTransmission(MatrixColor_ADDR);
    _pWire->write(0xF4);
    _pWire->endTransmission();
    return (float)_sensorCache32[28]; // 回傳額外擴充資料 4
  default:
    return 0;
  }
}

float MatrixColor::getH() {
  fetchLineTracerData();
  _stepSize = 2;
  if (_streamPtr > 22)
    return 0;
  return (float)*(int16_t *)(&_sensorCache32[_streamPtr]);
}

float MatrixColor::getS() {
  fetchLineTracerData();
  _stepSize = 2;
  if (_streamPtr > 22)
    return 0;
  return (float)*(uint16_t *)(&_sensorCache32[_streamPtr]);
}

float MatrixColor::getV() {
  fetchLineTracerData();
  _stepSize = 4;
  if (_streamPtr > 20)
    return 0;
  return *(float *)(&_sensorCache32[_streamPtr]);
}

float MatrixColor::getColorID() {
  _streamPtr = 0;
  return (float)_sensorCache32[24]; // 回傳狀態碼，同時指標歸零
}

uint8_t MatrixColor::i2cReadData(ColorRegType reg) {

  _pWire->beginTransmission(MatrixColor_ADDR);
  _pWire->write(reg);
  _pWire->endTransmission(1);

  delay(1);

  _pWire->requestFrom(MatrixColor_ADDR, 1);

  delay(1);

  return _pWire->read();
}

void MatrixColor::i2cMUXSelect() {
  if (_ch < 0)
    return; // no MUX
  _pWire->beginTransmission(ADDR_PCA954X);
  _pWire->write((1 << _ch));
  _pWire->endTransmission(1);
  delayMicroseconds(300);
}

void MatrixColor::i2cWriteData(ColorRegType reg, uint8_t data) {

  _pWire->beginTransmission(MatrixColor_ADDR);

  _pWire->write(reg);
  _pWire->write(data);

  _pWire->endTransmission(1);
}

void MatrixColor::fetchLineTracerData() {
  if (millis() - _lastUpdate < 5)
    return;

  i2cMUXSelect();

  _pWire->beginTransmission(MatrixColor_ADDR);
  _pWire->write(0x21); 
  _pWire->endTransmission();

  delayMicroseconds(300);

  // 讀取 30 Bytes (24 Bytes資料 + 1 Byte狀態碼 + 4 Bytes命令反饋 + 1 Byte CRC8)
  uint8_t bytesReceived = _pWire->requestFrom(MatrixColor_ADDR, (uint8_t)30);

  if (bytesReceived == 30) {
    uint8_t tempBuffer[30];
    for (int i = 0; i < 30; i++) {
      tempBuffer[i] = _pWire->read();
    }

    // CRC-8 驗證 (計算 0~28 bytes)
    uint8_t crc = 0;
    for (int i = 0; i < 29; i++) {
      crc = crc8_table[crc ^ tempBuffer[i]];
    }

    // 核對 Byte 29 (最後一個 Byte 是 CRC)
    if (crc == tempBuffer[29]) {
      memcpy(_sensorCache32, tempBuffer, 29); // 複製前面 29 Bytes 的資料
      _lastUpdate = millis();
    } else {
      // CRC 錯誤，丟棄此包資料，保留舊的 Cache
    }
  } else {
    while (_pWire->available())
      _pWire->read(); // 清除未完成的 Buffer
  }
}