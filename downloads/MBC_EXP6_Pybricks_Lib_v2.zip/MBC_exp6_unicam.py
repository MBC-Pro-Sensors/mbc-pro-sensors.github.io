# MBC_exp6_unicam.py ── EXP6 六路馬達擴充器 v2（Pybricks 4.x）：神攝手通用版（韌體 v1）
#  2026-11-03 從 MBC_exp6_obj_Lib_v2.py 分出來：主機程式上限 52 KB（程式＋所有函式庫），用到哪款才載入哪款。
#  需要 EXP6 v2 韌體 2026-11-03 以後（組模式＋命令轉送）。函式名稱、回傳值跟直插 SPIKE 主機一樣。
#  用法 / usage（UNICAM；要別的相機模式寫 p5=(UNICAM, 51)，預設 13）：
#    from MBC_exp6_obj_Lib_v2 import MBC_EXP6
#    from MBC_exp6_unicam import *
#    exp6 = MBC_EXP6(Port.C, False, p5=UNICAM)    # 宣告接在幾號孔：開始時讀產品碼核對，插錯直接說
#    s = exp6.sensor(5)                       # 照宣告拿物件（多工寫法也不用 await）
#    s = exp6.unicam(5)                           # 舊寫法也可以（不核對）
#    多工寫法（MBC_EXP6(Port.C, True)）宣告時不核對；物件的每個函式都要 await。
from MBC_exp6_obj_Lib_v2 import (MBC_EXP6, _watch)
from MBC_exp6_mbc_common import (_EXP6_SENSOR, _MODE8, _f8, _kind, _s8)


# ── 神攝手通用版（韌體 v1）/ Sharpshooter Vision（對應 MBC_UniCam.py 的 UniCam）──
#  cam = exp6.unicam(port, mode=13)：建立時自動送 E0 把相機切到 mode（跟直插一樣，不用再到相機選單切；
#  多工寫法要自己 await cam.set_mode(mode)）。mode：11～14 顏色追蹤、21～23 座標取色、30 照順序給色號、
#  41～43 循線、51、52 物體偵測。
#  主要組（每 10 ms）照相機模式挑最常用的 4 個 byte；其他值呼叫時才送（4 byte 一組，2 組同一筆）。
#  解碼函式照抄 MBC_UniCam.py。
MODES = (11, 12, 13, 14, 21, 22, 23, 30, 41, 42, 43, 51, 52)
_NCOL = {11: 14, 12: 7, 13: 4, 14: 2}
_NPT = {21: 14, 22: 7, 23: 4}
_NOBJ = {51: 4, 52: 2}
SHAPES = ('other', 'circle', 'ellipse', 'triangle', 'square', 'rectangle', 'pentagon', 'hexagon', 'star', 'trapezoid')
SHAPES_ZH = ('其他', '圓', '橢圓', '三角', '正方', '長方', '五邊', '六邊', '星', '梯形')
# 各相機模式的主要組（模式 9 的第幾個 byte）
_UC_MAIN = {11: (0, 1, 2, 3), 12: (0, 1, 2, 3), 13: (0, 1, 2, 12), 14: (0, 1, 2, 3),
            21: (0, 1, 2, 3), 22: (0, 1, 2, 3), 23: (0, 1, 2), 30: (0, 1, 2, 13),
            41: (0, 3, 5, 6), 42: (0, 3, 5, 6), 43: (0, 3, 5, 6), 51: (0, 1, 2, 3), 52: (0, 1, 2, 3)}

def color_name(h):
    """色相碼 0~255 → 顏色名稱（None＝沒有）"""
    if h is None:
        return None
    if h > 248:
        return 'black'
    if h > 240:
        return 'white'
    if h < 12 or h >= 220:
        return 'red'
    if h < 28:
        return 'orange'
    if h < 56:
        return 'yellow'
    if h < 100:
        return 'green'
    if h < 140:
        return 'cyan'
    if h < 180:
        return 'blue'
    return 'purple'

def shape_name(s, zh=False):
    """形狀編號 0~9 → 名稱；zh=True 回中文；None 或超出範圍回 None"""
    if s is None or not 0 <= s <= 9:
        return None
    return SHAPES_ZH[s] if zh else SHAPES[s]

def _ucb(v, n):
    b = []
    for w in v:
        w = int(w) & 0xFFFF
        b.append(w & 0xFF)
        b.append(w >> 8)
    return b[:n]

def _uc_xy(v, m, c):
    b = _ucb(v, 14)
    if m == 11:
        g = b[c - 1]
        if not g:
            return (0, 0)
        return (((g - 1) % 16) * 10 + 5, ((g - 1) // 16) * 10 + 5)
    k = {12: 2, 13: 3, 14: 6}[m] * (c - 1)
    return (b[k], b[k + 1])

def _uc_cell(v, m, c):
    g = _ucb(v, 14)[c - 1]
    return (0, 0) if not g else ((g - 1) % 16 + 1, (g - 1) // 16 + 1)

def _uc_area(v, m, c):
    b = _ucb(v, 14)
    return b[3 * c - 1] if m == 13 else b[6 * c - 1]

def _uc_size(v, m, c):
    b = _ucb(v, 14)
    return (b[6 * c - 4], b[6 * c - 3])

def _uc_count9(v, m, c):
    b = _ucb(v, 14)
    if m == 13:
        x = b[12 + (c - 1) // 2]
        return x >> 4 if c % 2 else x & 15
    return b[6 * c - 2]

def _uc_count6(v, m, c):
    b = _ucb(v, 6)
    if m == 11:
        o = 3 * (c - 1) if c else 42
        i = o >> 3
        w = b[i] | ((b[i + 1] << 8) if i + 1 < 6 else 0)
        return (w >> (o & 7)) & (7 if c else 15)
    if c == 0:
        return b[3] & 15
    x = b[(c - 1) // 2]
    return x >> 4 if c % 2 else x & 15

def _uc_found14(v, m, c):
    return _ucb(v, 14)[12]

def _uc_hsv(v, m, i):
    b = _ucb(v, 14)
    if m == 21:
        return (b[i - 1], None, None)
    if m == 22:
        return (b[2 * i - 2], b[2 * i - 1], None)
    return (b[3 * i - 3], b[3 * i - 2], b[3 * i - 1])

def _uc_order(v, m, a):
    b = _ucb(v, 14)
    return b[:min(13, b[13])]

def _uc_total(v, m, a):
    return _ucb(v, 14)[13]

def _uc_line(v, m, a):
    b = _ucb(v, 14)
    s = _s8
    return (s(b[0]), s(b[1]), s(b[2]), s(b[3]), b[4], b[5], b[6], b[7], s(b[8]), s(b[9]), b[10], b[11], b[12], b[13])

def _uc_ob(v, m, i):
    b = _ucb(v, 14)
    if m == 51:
        k = 3 * i - 2
        return (b[k], b[k + 1], b[k + 2], None, None, None)
    k = 7 * (i - 1)
    return (b[k] * 10 + b[k + 1] if b[k] else 0, b[k + 2], b[k + 3], b[k + 4], b[k + 5], b[k + 6])

def _uc_ocount(v, m, a):
    return _ucb(v, 14)[0]

# 各解碼函式用到模式 9／6 的第幾個 byte（決定要送哪幾組）
def _need_xy(m, c):
    if m == 11:
        return (c - 1,)
    k = {12: 2, 13: 3, 14: 6}[m] * (c - 1)
    return (k, k + 1)

def _need_count9(m, c):
    return (12 + (c - 1) // 2,) if m == 13 else (6 * c - 2,)

def _need_count6(m, c):
    if m == 11:
        i = (3 * (c - 1) if c else 42) >> 3
        return (i, i + 1) if i + 1 < 6 else (i,)
    return (3,) if c == 0 else ((c - 1) // 2,)

def _need_hsv(m, i):
    if m == 21:
        return (i - 1,)
    if m == 22:
        return (2 * i - 2, 2 * i - 1)
    return (3 * i - 3, 3 * i - 2, 3 * i - 1)

def _need_ob(m, i, part):
    # part：0 代碼、1 XY、2 寬高、3 面積
    if m == 51:
        k = 3 * i - 2
        return ((k,), (k + 1, k + 2))[part]
    k = 7 * (i - 1)
    return ((k, k + 1), (k + 2, k + 3), (k + 4, k + 5), (k + 6,))[part]


class EXP6_UNICAM(_EXP6_SENSOR):
    """神攝手（韌體 v1）：cam = exp6.unicam(port, mode=13)"""
    _SETS = {'m8': _MODE8}

    def __init__(self, exp6, port_num, mode=13):
        if mode not in MODES:
            raise ValueError('mode 要填 %s / mode must be one of %s' % (MODES, MODES))
        _EXP6_SENSOR.__init__(self, exp6, port_num)
        self._m = mode
        self._oldfw = 0
        if not exp6._async_mode:
            self.set_mode(mode)     # 把相機切到 mode（跟直插一樣）；多工要自己 await cam.set_mode(mode)

    # 組集合：'m8'、'9:主要'、'9:b0,b1…'（每 4 byte 一組）；名稱裡帶相機模式，換模式不會混用舊的
    def _sets(self, sname):
        s = self._SETS.get(sname)
        if s is not None:
            return s
        mode, need = sname
        main = _UC_MAIN[self._m]
        if mode == 9 and all(k in main for k in need):
            return ((9, _f8(*main)),)
        chunks = sorted(set(k // 4 for k in need))
        return tuple((mode, _f8(*range(4 * c, min(4 * c + 4, 16 if mode == 9 else 8)))) for c in chunks)

    def _need(self, name, ok):
        if self._m not in ok:
            raise ValueError('%s(): 模式 %d 沒有這個值，要用模式 %s / not available in mode %d, use mode %s'
                             % (name, self._m, ok, self._m, ok))

    def _col(self, c, n):
        if not 1 <= c <= n:
            raise ValueError('第幾色／第幾點要填 1~%d / colour or spot must be 1~%d' % (n, n))

    # ───── 共用 ─────
    def mode_number(self):
        """建構時（或 set_mode）設定的模式編號"""
        return self._r(self._m)

    def device_id(self):
        """模式 8：(位址 0x4C, hw0, 韌體版字)，目前的神攝手 hw0＝3"""
        return self._g('m8', lambda v: (int(v[0]) & 0xFF, (int(v[0]) >> 8) & 0xFF, int(v[2]) & 0xFFFF))

    def is_unicam(self):
        """是不是目前的神攝手（模式 8 的 hw0＝3）"""
        return self._g('m8', lambda v: (int(v[0]) & 0xFFFF) == 0x034C)

    def firmware_version(self):
        """韌體版本 (主版, 次版)"""
        return self._g('m8', lambda v: ((int(v[2]) & 0xFFFF) // 100, (int(v[2]) & 0xFFFF) % 100))

    # ───── 下命令（照 MBC_UniCam.py：wait_done 回狀態碼、cmd 送不出去回 None）─────
    def _newfw(self, v):
        if v is None or not (int(v[1]) & 0x100):
            raise ValueError('模式 8 v1 = %s，沒有命令旗標 0x100' % (None if v is None else v[1]))
        return v

    def _nocmd(self, e):
        if not self._oldfw:
            print('MBC: EXP6 孔', self._port, '相機韌體不支援命令（2026-10-29 以前的韌體），請在相機選單切模式 / '
                  'camera firmware has no commands, use the camera menu:', e)
        self._oldfw = 1

    def _seqfor(self, key, v, again):
        if key == self._ck and not again:
            return self._sq
        if self._sq is None:
            self._sq = (int(v[3]) >> 8) & 0xFF
        self._sq = self._sq % 99 + 1
        self._ck = key
        return self._sq

    def _st(self, v):
        if v is None or self._sq is None:
            return None
        w = int(v[3]) & 0xFFFF
        if (w >> 8) != self._sq:
            return 1
        return w & 0xFF

    def cmd(self, code, *p, again=False):
        """送命令、不等（回序號；送不出去回 None）。同命令＋同參數再叫不會重做，要再做一次寫 again=True"""
        q = tuple(int(x) for x in p)
        if len(q) > 5:
            raise ValueError('參數最多 5 個 / at most 5 parameters')
        if self._a():
            return self._cmd_uc_a(code, q, again)
        try:
            v = None if self._sq is not None else self._newfw(self._m8())
            s = self._seqfor((code,) + q, v, again)
            self._pk = self._cmd_pkts(code, q, s)
            self._send_pk(self._pk)
            return s
        except Exception as e:
            self._nocmd(e)
        return None

    async def _cmd_uc_a(self, code, q, again):
        try:
            v = None if self._sq is not None else self._newfw(await self._m8_a())
            s = self._seqfor((code,) + q, v, again)
            self._pk = self._cmd_pkts(code, q, s)
            await self._send_pk_a(self._pk)
            return s
        except Exception as e:
            self._nocmd(e)
        return None

    def busy(self):
        """最後一個命令還在做嗎"""
        if self._a():
            return self._busy_uc_a()
        return self._st(self._m8()) == 1

    async def _busy_uc_a(self):
        return self._st(await self._m8_a()) == 1

    def wait_done(self, timeout=5000):
        """等最後一個命令做完：回 0 完成、2 失敗、3 拒絕；逾時回 None"""
        if self._a():
            return self._wait_uc_a(timeout)
        t0 = _watch.time()
        while _watch.time() - t0 < timeout:
            s = self._st(self._m8())
            if s is not None and s != 1:
                return s
            self._exp6.keep_alive_wait(10)
        return None

    async def _wait_uc_a(self, timeout):
        t0 = _watch.time()
        while _watch.time() - t0 < timeout:
            s = self._st(await self._m8_a())
            if s is not None and s != 1:
                return s
            await self._exp6.keep_alive_wait(10)
        return None

    def _do(self, timeout, code, *p, again=False):
        if self._a():
            return self._do_a(timeout, code, p, again)
        if self.cmd(code, *p, again=again) is None:
            return None
        return self.wait_done(timeout)

    async def _do_a(self, timeout, code, p, again):
        if await self._cmd_uc_a(code, tuple(int(x) for x in p), again) is None:
            return None
        return await self._wait_uc_a(timeout)

    def set_mode(self, mode):
        """切相機模式（E0，存進相機；值沒變不會重寫）：cam.set_mode(51)"""
        if mode not in MODES:
            raise ValueError('mode 要填 %s / mode must be one of %s' % (MODES, MODES))
        self._m = mode
        self._t = {}
        self._mir = {}
        if self._a():
            return self._set_mode_a(mode)
        r = self._do(500, 0xE0, mode // 10, mode % 10)
        if r == 0:
            self._exp6.keep_alive_wait(60)      # 下一幀才是新模式的值
        return r

    async def _set_mode_a(self, mode):
        r = await self._do_a(500, 0xE0, (mode // 10, mode % 10), False)
        if r == 0:
            await self._exp6.keep_alive_wait(60)
        return r

    def light(self, pct=None):
        """補光燈亮度 0~100 %（0＝關；None＝回相機選單的 Flash 設定；不存）"""
        return self._do(500, 0xE2, 255 if pct is None else max(0, min(100, int(pct))))

    def teach(self, color):
        """遠端教色（E3）：用畫面中央的顏色登錄成目標 color 1~16。回 0 成功、2 失敗"""
        return self._do(3000, 0xE3, color, again=True)

    def clear(self, color):
        """清除目標 color 1~16（E4）"""
        return self._do(1000, 0xE4, color)

    def target_range(self, color, hue=255, sat=255, size=255, search=0):
        """目標 color 的 Hue 範圍、Sta 範圍、最小面積（E5；255＝不改）；search 1 鎖住、2 最大塊、0 不改"""
        return self._do(1000, 0xE5, color, hue, sat, size, search)

    def shape_tolerance(self, tol):
        """形狀容許 1~5（E6）"""
        return self._do(500, 0xE6, tol)

    def target_shape(self, color, shape):
        """目標色 1~8 的指定形狀 0~9（E7）"""
        return self._do(500, 0xE7, color, shape)

    def camera_setting(self, item, value):
        """鏡頭設定（E8）：item 0~12，value 可以是負數"""
        return self._do(2000, 0xE8, item, value)

    def white_cal(self):
        """白色校正（E9，約 3 秒）：白紙要先蓋滿畫面中央"""
        return self._do(8000, 0xE9, 0xA5, again=True)

    def power(self, mode):
        """工作模式（EB）：0 全速、1 省電、2 待機"""
        return self._do(5000, 0xEB, mode)


# 神攝手讀值函式（2026-11-03 瘦身：查表產生；名稱、回傳值同 MBC_UniCam.py）
#  每列：名稱, 哪些相機模式能用, 參數上限 nf(m)（None＝沒有參數）, 要讀哪些 byte nd(m, a)→(模式, bytes), 解碼 dec(v, m, a)
def _ucq(name, ok, nf, nd, dec):
    def g(self, a):
        self._need(name, ok)
        m = self._m
        if nf is not None:
            self._col(a, nf(m))
        md, need = nd(m, a)
        return self._g((md, tuple(need)), lambda v: dec(v, m, a))
    if nf is None:
        return lambda self: g(self, None)
    return lambda self, a: g(self, a)

def _ucmax(name, ok, tbl):
    def f(self):
        self._need(name, ok)
        return self._r(tbl[self._m])
    return f

_C1, _PT, _LN, _OB = (11, 12, 13, 14), (21, 22, 23), (41, 42, 43), (51, 52)
_ncol = lambda m: _NCOL[m]
_npt = lambda m: _NPT[m]
_nob = lambda m: _NOBJ[m]
_nxy = lambda m, c: (9, _need_xy(m, c))
_nhsv = lambda m, p: (9, _need_hsv(m, p))
_n9 = lambda *ks: (lambda m, a: (9, ks))
_c6 = lambda m: m in (11, 12)
_UCQ = (
    # 模式 1 顏色追蹤（11~14）：xy/x/y/found(色)、cell 模式 11 格子、area 面積 %、size 模式 14 寬高、count 幾塊
    ('xy', _C1, _ncol, _nxy, _uc_xy),
    ('x', _C1, _ncol, _nxy, lambda v, m, c: _uc_xy(v, m, c)[0]),
    ('y', _C1, _ncol, _nxy, lambda v, m, c: _uc_xy(v, m, c)[1]),
    ('found', _C1, _ncol, _nxy, lambda v, m, c: _uc_xy(v, m, c)[0] > 0),
    ('cell', (11,), lambda m: 14, lambda m, c: (9, (c - 1,)), _uc_cell),
    ('area', (13, 14), _ncol, lambda m, c: (9, (3 * c - 1 if m == 13 else 6 * c - 1,)), _uc_area),
    ('size', (14,), lambda m: 2, lambda m, c: (9, (6 * c - 4, 6 * c - 3)), _uc_size),
    ('count', _C1, _ncol, lambda m, c: (6, _need_count6(m, c)) if _c6(m) else (9, _need_count9(m, c)),
     lambda v, m, c: _uc_count6(v, m, c) if _c6(m) else _uc_count9(v, m, c)),
    ('colors_found', (11, 12, 14), None, lambda m, a: (9, (12,)) if m == 14 else (6, _need_count6(m, 0)),
     lambda v, m, a: _uc_found14(v, m, a) if m == 14 else _uc_count6(v, m, 0)),
    # 模式 2 座標取色（21~23）：hue 色相碼、sat 飽和度、val 明度、hsv、color 顏色名稱
    ('hue', _PT, _npt, _nhsv, lambda v, m, i: _uc_hsv(v, m, i)[0]),
    ('sat', (22, 23), _npt, _nhsv, lambda v, m, i: _uc_hsv(v, m, i)[1]),
    ('val', (23,), lambda m: 4, _nhsv, lambda v, m, i: _uc_hsv(v, m, i)[2]),
    ('hsv', _PT, _npt, _nhsv, _uc_hsv),
    ('color', _PT, _npt, _nhsv, lambda v, m, i: color_name(_uc_hsv(v, m, i)[0])),
    # 模式 3 照順序給色號（30）：order 由左到右的色相碼、total 總共幾塊
    ('order', (30,), None, _n9(*range(14)), _uc_order),
    ('total', (30,), None, _n9(13), _uc_total),
    # 模式 4 循線（41~43）：edges 近處 (左緣, 右緣)、marker (標記線色號, 累計條數)；其他見下面 _UCL
    ('edges', _LN, None, _n9(8, 9), lambda v, m, a: _uc_line(v, m, a)[8:10]),
    ('marker', _LN, None, _n9(11, 12), lambda v, m, a: _uc_line(v, m, a)[11:13]),
    # 模式 5 物體偵測（51、52）：object 代碼＝色號×10＋形狀、object_found、object_color、object_shape、
    #  object_xy 質心、object_size／object_area 只有模式 52
    ('object_count', (51,), None, _n9(0), _uc_ocount),
    ('object', _OB, _nob, lambda m, i: (9, _need_ob(m, i, 0)), lambda v, m, a: _uc_ob(v, m, a)[0]),
    ('object_found', _OB, _nob, lambda m, i: (9, _need_ob(m, i, 0)), lambda v, m, a: _uc_ob(v, m, a)[0] > 0),
    ('object_color', _OB, _nob, lambda m, i: (9, _need_ob(m, i, 0)), lambda v, m, a: _uc_ob(v, m, a)[0] // 10),
    ('object_shape', _OB, _nob, lambda m, i: (9, _need_ob(m, i, 0)), lambda v, m, a: _uc_ob(v, m, a)[0] % 10),
    ('object_xy', _OB, _nob, lambda m, i: (9, _need_ob(m, i, 1)), lambda v, m, a: _uc_ob(v, m, a)[1:3]),
    ('object_size', (52,), _nob, lambda m, i: (9, _need_ob(m, i, 2)), lambda v, m, a: _uc_ob(v, m, a)[3:5]),
    ('object_area', (52,), _nob, lambda m, i: (9, _need_ob(m, i, 3)), lambda v, m, a: _uc_ob(v, m, a)[5]),
)
for _r in _UCQ:
    setattr(EXP6_UNICAM, _r[0], _ucq(*_r))
# 循線：near／mid／far 偏移 −100~100、angle −90~90、width 線寬 %、flags（近1＋中2＋遠4）、junction 路口類型、
#  junction_dist 路口距離 %、far_width 遠處線寬 %、lost 最後離線方向（0 有線 1 左 2 右）
for _i, _nm in ((0, 'near'), (1, 'mid'), (2, 'far'), (3, 'angle'), (4, 'width'), (5, 'flags'), (6, 'junction'),
                (7, 'junction_dist'), (10, 'far_width'), (13, 'lost')):
    setattr(EXP6_UNICAM, _nm, _ucq(_nm, _LN, None, _n9(_i), lambda v, m, a, i=_i: _uc_line(v, m, a)[i]))
# 這個模式給幾色／幾點／幾個物體
EXP6_UNICAM.max_color = _ucmax('max_color', _C1, _NCOL)
EXP6_UNICAM.max_point = _ucmax('max_point', _PT, _NPT)
EXP6_UNICAM.max_object = _ucmax('max_object', _OB, _NOBJ)


UNICAM = _kind(EXP6_UNICAM, (0x4C, 3))
MBC_EXP6.unicam = lambda self, port_num, mode=13: EXP6_UNICAM(self, port_num, mode)
