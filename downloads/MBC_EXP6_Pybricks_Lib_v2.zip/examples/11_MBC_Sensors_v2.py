# 範例 11：MBC 感應器插在 EXP6 上 (MBC Sensors on EXP6) - Pybricks 版（v2）
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 需要 EXP6 韌體 Exp6_v2（2026-11-03 以後），並把下面 import 的檔案跟本檔放在同一個 Pybricks 專案內：
#      MBC_exp6_obj_Lib_v2.py（EXP6＋馬達）、MBC_exp6_mbc_common.py（共用），以及用到的感應器檔
#      MBC_exp6_line.py（循行者）、MBC_exp6_laser.py（測距者）、MBC_exp6_pad.py（掌控者）、MBC_exp6_unicam.py（神攝手）。
#      只 import 用到的感應器檔就好：主機程式（程式＋函式庫）上限約 52 KB。
#      感應器要先切到 SPIKE 模式。下面的孔號依你實際插的位置修改，沒插的感應器那段會印「讀不到」並回傳 None。
# [EN] Needs EXP6 firmware Exp6_v2 (2026-11-03 or later). Upload the imported files alongside this one:
#      the EXP6 core, the common file, and only the sensor files you use (hub program limit is about 52 KB).
#      Switch each sensor to SPIKE mode first. Unplugged sensors print a notice and return None.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib_v2 import MBC_EXP6, run_task
from MBC_exp6_line import *      # 循行者 LINE8、LINE16
from MBC_exp6_laser import *     # 測距者 LASER2、LASER8
from MBC_exp6_pad import *       # 掌控者 PS2、PS4
from MBC_exp6_unicam import *    # 神攝手 UNICAM

HUB_PORT = 1          # EXP6 插在 Hub 的 A 孔
# 宣告 EXP6 每一孔接什麼（PS4 藍牙遙控寫 PS4；神攝手寫 (UNICAM, 模式)，模式要跟相機選單一樣）
exp6 = MBC_EXP6(HUB_PORT, True, p2=LINE8, p3=LASER8, p4=PS2, p5=(UNICAM, 13))

# 照宣告拿感應器物件（要在 run_task 之前；不用 await）
line8  = exp6.sensor(2)
laser8 = exp6.sensor(3)
ps     = exp6.sensor(4)
cam    = exp6.sensor(5)

async def main():
    print("==============================")
    print(" 範例 11：MBC 感應器（v2）")
    print("==============================")
    await cam.set_mode(13)       # 多工寫法：神攝手的相機模式要自己 await 切一次（同步寫法建立時就切好）

    # [展示 1] 循行者 8 路：pos8、width、pos100、junction 都在主要組（每 10 ms 更新），連續讀最快
    print("\n[展示 1] 循行者 8 路")
    for i in range(5):
        print("  pos8={}  width={}  pos100={}  junction={}".format(
            await line8.pos8(), await line8.width(),
            await line8.pos100(), await line8.junction_name()))
        await wait(200)
    values = []
    for ch in range(1, 9):
        values.append(await line8.ir_ch(ch))
    print("  ch1~ch8 光值:", values)

    # [展示 2] 八方位雷射
    print("\n[展示 2] 八方位雷射")
    for i in range(5):
        print("  最近方位={} 距離={} cm   正前方 ch1={} cm".format(
            await laser8.min_direction(), await laser8.min_distance(), await laser8.ch(1)))
        await wait(200)

    # [展示 3] 遙控器：按 ✕ 結束
    print("\n[展示 3] 遙控器（按 ✕ 結束）")
    while True:
        await ps.update()        # 每一圈先讀一次手把，下面的按鍵、搖桿都用這一次的資料（跟直插一樣）
        if await ps.pressed("cross"):
            break
        print("  左搖桿 ({}, {})  按下: {}".format(await ps.lx(), await ps.ly(), await ps.pressed_buttons()))
        await wait(200)

    # [展示 4] 神攝手：4 個目標色的位置與面積（xy 一次讀到 X、Y）
    print("\n[展示 4] 神攝手（模式 13）")
    print("  韌體版本:", await cam.firmware_version())
    for i in range(5):
        for c in range(1, 5):
            print("  色{} 位置={} 面積={}%".format(c, await cam.xy(c), await cam.area(c)))
        await wait(500)

    print("\n測試結束！")

run_task(main())
