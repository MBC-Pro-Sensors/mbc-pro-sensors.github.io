# 範例 11：MBC 感應器插在 EXP6 上 (MBC Sensors on EXP6) - Pybricks 版（v2）
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 需要 EXP6 韌體 Exp6_v2，並把 MBC_exp6_obj_Lib_v2.py 跟本檔放在同一個 Pybricks 專案內。
#      感應器要先切到 SPIKE 模式。下面的孔號依你實際插的位置修改，沒插的感應器那段會印「讀不到」並回傳 None。
# [EN] Needs EXP6 firmware Exp6_v2; upload MBC_exp6_obj_Lib_v2.py alongside this file.
#      Switch each sensor to SPIKE mode first. Unplugged sensors print a notice and return None.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib_v2 import MBC_EXP6, run_task

HUB_PORT = 1          # EXP6 插在 Hub 的 A 孔
exp6 = MBC_EXP6(HUB_PORT, True)

# 宣告每顆感應器插在 EXP6 的哪一孔（要在 run_task 之前建立）
line8  = exp6.line8(2)
laser8 = exp6.laser8(3)
ps     = exp6.ps2(4)      # PS4 藍牙遙控用 exp6.ps4(4)，用法相同
cam    = exp6.unicam(5, 13)   # 神攝手：相機選單切到 1-3（顏色追蹤 標準），mode 要跟相機一樣

async def main():
    print("==============================")
    print(" 範例 11：MBC 感應器（v2）")
    print("==============================")

    # [展示 1] 循行者 8 路：pos8 與 width 在同一個視窗，連續讀最快
    print("\n[展示 1] 循行者 8 路")
    for i in range(5):
        print("  pos8={}  width={}  pos100={}  junction={}".format(
            await line8.pos8(), await line8.width(),
            await line8.pos100(), await line8.junction_name()))
        await wait(200)
    values = []
    for ch in range(1, 9):
        values.append(await line8.ir_ch(ch))
    print("  ch1~ch8 光值:", values)

    # [展示 2] 八方位雷射
    print("\n[展示 2] 八方位雷射")
    for i in range(5):
        print("  最近方位={} 距離={} cm   正前方 ch1={} cm".format(
            await laser8.min_direction(), await laser8.min_distance(), await laser8.ch(1)))
        await wait(200)

    # [展示 3] 遙控器：按 ✕ 結束
    print("\n[展示 3] 遙控器（按 ✕ 結束）")
    while True:
        if await ps.pressed("cross"):
            break
        print("  左搖桿 ({}, {})  按下: {}".format(await ps.lx(), await ps.ly(), await ps.pressed_buttons()))
        await wait(200)

    # [展示 4] 神攝手：4 個目標色的位置與面積（xy 一次讀到 X、Y）
    print("\n[展示 4] 神攝手（模式 13）")
    print("  韌體版本:", await cam.firmware_version())
    for i in range(5):
        for c in range(1, 5):
            print("  色{} 位置={} 面積={}%".format(c, await cam.xy(c), await cam.area(c)))
        await wait(500)

    print("\n測試結束！")

run_task(main())
