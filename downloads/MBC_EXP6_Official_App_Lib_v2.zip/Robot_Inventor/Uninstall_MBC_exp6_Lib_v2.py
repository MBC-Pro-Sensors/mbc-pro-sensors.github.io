# MBC EXP6 SPIKE App Library Uninstaller (v2)
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式適用於 MINDSTORMS 10.x／SPIKE App 2.x（玩具版）
# [EN] This program is designed for MINDSTORMS 10.x / SPIKE App 2.x
#
# 請在官方 App 中執行此程式，即可將函數庫從主機中移除。

import os
import sys

# 玩具版的函式庫安裝在 /lib（同 Install_MBC_exp6_Lib_v2.py）
filename = "/lib/MBC_exp6_SPIKE_App_Lib_v2.py"

print("=========================================")
print("開始移除 " + filename + " ...")

try:
    os.remove(filename)
    print("移除成功！ (Uninstall Successful!)")
except OSError:
    print("函數庫尚未安裝或已經被移除了。 (File not found.)")
except Exception as e:
    print("移除發生錯誤 (Uninstall Failed):", e)
    
print("=========================================")
