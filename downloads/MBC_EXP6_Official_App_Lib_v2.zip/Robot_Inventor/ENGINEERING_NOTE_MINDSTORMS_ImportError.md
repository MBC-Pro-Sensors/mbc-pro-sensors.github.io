# 工程日誌：MINDSTORMS 10.5.2 (SPIKE 2.x 架構) 函式庫匯入異常分析

## 基本資訊
* **日期**：2026年7月
* **目標環境**：LEGO MINDSTORMS 51515 / 軟體版本 10.5.2
* **核心問題**：執行範例程式時，持續發生 `ImportError: no module named 'MBC_exp6_SPIKE_App_Lib'` 或載入空模組錯誤。
* **限制條件**：必須保持「通用範例」程式碼的純淨，**不允許**在範例開頭加上 `sys.path.append(...)` 等破解系統路徑的程式碼。

---

## 偵錯歷程與發現

### 1. 初次安裝與路徑解析
最初設計了 `Install_MBC_exp6_Lib.py` 將函式庫檔案寫入主機的 `/projects` 目錄。
* **發現**：在不修改 `sys.path` 的情況下，MINDSTORMS 執行一般專案時，預設只會讀取「當前專案資料夾」，完全忽略 `/projects`，導致 `ImportError`。

### 2. 空白模組與跨專案載入 (Cross-Project Import)
當拿掉 `sys.path.append` 後，一度出現 `ImportError: can't import name MBC_EXP6`，這表示系統「找到了模組，但模組裡面是空的」。
* **發現**：MINDSTORMS 軟體具備跨專案載入特性。當存在一個與函式庫同名的專案 (`MBC_exp6_SPIKE_App_Lib`) 時，`import` 系統會優先攔截並載入該專案。因為該專案內沒有程式碼（0 bytes），所以引發此錯誤。
* **處置**：將該同名專案刪除後，錯誤回到 `no module named...`。

### 3. 全域資料夾 `/lib` 測試
為了繞過 `sys.path.append` 的限制，嘗試將函式庫直接寫入 MicroPython 預設的全域資料夾 `/lib`。
* **診斷腳本結果**：透過底層掃描腳本證實，`MBC_exp6_SPIKE_App_Lib.py` 確實成功建立在 `/lib` 中，且檔案大小正確 (13848 bytes)。
* **執行結果**：執行 `01_Motor_Basic.py` 依然報錯 `ImportError: no module named 'MBC_exp6_SPIKE_App_Lib'`。
* **關鍵結論**：MINDSTORMS 10.5.2 的沙盒隔離極度嚴格。它執行專案時的 `sys.path` 是**完全封閉**的，不僅沒有 `/projects`，甚至連原生的 `/lib` 都不在預設讀取路徑中。

### 4. 再次嘗試跨專案載入
嘗試讓使用者建立同名專案並貼入完整程式碼，期望利用軟體原生的跨專案載入功能，但最終仍然報錯。
* **推論**：可能是 MINDSTORMS 10.5.2 在某些韌體版本中，對跨專案的命名空間與檔案實體映射存在 Bug；或者主機端的 `sys.modules` 記憶體快取極度頑強，需要完全冷啟動才能重置。

---

## 最終結論與技術限制

基於「**絕對不修改通用範例程式的 `sys.path`**」此一嚴格前提，目前在 MINDSTORMS 10.5.2 環境下得出以下結論：

1. **底層安裝檔 (Installer) 方案不可行**：因為寫入系統任何位置，都必須靠 `sys.path.append` 才能讀出來，這與限制條件衝突。
2. **MINDSTORMS 系統的封閉性**：其專案間的沙盒隔離機制，阻斷了常規的 Python 模組全域共享方法。

## 暫緩處理與未來建議

* 該相容性問題目前暫時擱置，不影響 SPIKE 3.x 等新版架構的使用者。
* **未來替代方案**：若後續仍需支援 MINDSTORMS 10.5.2 且堅持不改路徑，唯一的作法只能是「放棄模組化 (`import`)」，要求使用者**直接將函式庫原始碼 (約300多行) 貼在他們自己寫的專案最上方**。
