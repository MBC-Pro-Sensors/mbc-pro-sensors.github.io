# MBC EXP6 MINDSTORMS 51515 Library Installer (玩具版專用)
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式專門適用於 LEGO MINDSTORMS 10.x / SPIKE App 2.x
# [EN] This program is designed for MINDSTORMS 10.x / SPIKE App 2.x
#
# 請在官方 App 中執行此程式，即可將函數庫安裝到主機中。

import sys

import os

# 在 SPIKE 2.x / MINDSTORMS 中，/lib 是預設會在 sys.path 裡面的全域路徑
# 把它裝在 /lib 就不需要去改範例程式的 sys.path 了！
try:
    os.mkdir('/lib')
except:
    pass

filename = "/lib/MBC_exp6_SPIKE_App_Lib_v2.py"

print("=========================================")
print("開始安裝 / Installing " + filename + " (玩具版/SPIKE 2.x 專用 / for SPIKE 2.x)...")

source_code = """\
# Python Library for EXP6 Smart Expansion Board for MINDSTORMS 51515
# Author : MBC robotics
# Date   : 2026.07
#
# !! 此函式庫專供 LEGO MINDSTORMS 10.x / SPIKE App 2.x 使用 !!
# !! This library is designed for MINDSTORMS 10.x / SPIKE App 2.x !!
#
# v2（2026-10）：需搭配 EXP6 韌體 Exp6_v2。v1 的函式全部保留；新增 MBC 感應器插在 EXP6 孔上的讀值
#   （exp.line8(port) 等，見類別內「v2：MBC 感應器」一節）。

import hub, utime

_instances = []

def _default_instance():
    if not _instances:
        raise RuntimeError("請先建立擴充板物件 (例: exp = MBC_EXP6('F')) / Create the board first, e.g. exp = MBC_EXP6('F')")
    return _instances[-1]

DEV_NONE = 0
DEV_FORCE = 1
DEV_COLOR = 3          # 跟韌體／Pybricks 庫一致（get_device_id 回傳的顏色感應器代碼）
DEV_ULTRASONIC = 4
DEV_MOTOR = 5

DIR_HOLD = 0
DIR_CW = 1
DIR_CCW = 2
DIR_COAST = 3
DIR_BRAKE = 4

MODE_SPEED = 0
MODE_ANGLE = 1
MODE_ABS_ANGLE = 2
MODE_RESET = 3
MODE_COLOR = 10
MODE_RGB = 11
MODE_HSV = 12
MODE_DISTANCE = 20
MODE_FORCE = 30

class MBC_EXP6:
    DEV_NONE = DEV_NONE
    DEV_FORCE = DEV_FORCE
    DEV_COLOR = DEV_COLOR
    DEV_ULTRASONIC = DEV_ULTRASONIC
    DEV_MOTOR = DEV_MOTOR

    DIR_HOLD = DIR_HOLD
    DIR_CW = DIR_CW
    DIR_CCW = DIR_CCW
    DIR_COAST = DIR_COAST
    DIR_BRAKE = DIR_BRAKE

    MODE_SPEED = MODE_SPEED
    MODE_ANGLE = MODE_ANGLE
    MODE_ABS_ANGLE = MODE_ABS_ANGLE
    MODE_RESET = MODE_RESET
    MODE_COLOR = MODE_COLOR
    MODE_RGB = MODE_RGB
    MODE_HSV = MODE_HSV
    MODE_DISTANCE = MODE_DISTANCE
    MODE_FORCE = MODE_FORCE

    def __init__(self, port_var, multitask=False):
        if type(port_var) == str:
            self._port_obj = getattr(hub.port, port_var)
        elif type(port_var) == int:
            self._port_obj = getattr(hub.port, ['A','B','C','D','E','F'][port_var])
        else:
            self._port_obj = port_var
            
        self.v = 0
        self.d = [0] * 6
        self._la = [0] * 6
        self._aa = [0] * 6
        self._port_mode_cache = {}
        self._mbc_win = {}        # v2：各孔目前要求的 (mode, 起始 byte)
        self._mbc_warn_ms = {}    # v2：讀不到感應器提示的上次時間（限流）
        
        self._time = utime
        self._last_send_time = self._time.ticks_ms()
        self._last_cmd = None
        self._throttle_ms = 20

        for _ in range(100):
            try:
                r = self._port_obj.device.get()
                if r and len(r) >= 8 and r[6] != 0:
                    break
            except Exception:
                pass
            self._time.sleep(0.02)
            
        # 校準輪詢週期：最多等 2 秒，資料一直沒更新就改用預設 25 ms，不會卡住
        try:
            last_tick = self._time.ticks_ms()
            last_d = self._port_obj.device.get()
            timed_out = False
            for _ in range(10):
                while True:
                    cur = self._port_obj.device.get()
                    if cur != last_d:
                        break
                    if self._time.ticks_diff(self._time.ticks_ms(), last_tick) > 2000:
                        timed_out = True
                        break
                    self._time.sleep(0.001)
                if timed_out:
                    break
                last_d = cur
            if timed_out:
                print("[EXP6] 讀不到擴充板資料更新，改用預設通訊週期 25 ms（請確認 EXP6 接在這個孔且已開電）/ No data from EXP6, using the default 25 ms period (check the port and power)")
                self._throttle_ms = 25
            else:
                period = self._time.ticks_diff(self._time.ticks_ms(), last_tick) / 10
                self._throttle_ms = max(20, int(period * 2))
        except Exception:
            self._throttle_ms = 25
            
        self._send(0, 0, 0, 0)
        self._time.sleep(0.1)
        self.update() 
        
        for i in range(1, 7):
            self.set_port_mode(i, self.MODE_ANGLE)
            
        self._time.sleep(0.05)
        self.update()
        for i in range(1, 7):
            self._la[i-1] = self.d[i-1]
            self._aa[i-1] = 0

        _instances.append(self)

    def update(self):
        try:
            r = self._port_obj.device.get()
            if r and len(r) >= 8:
                new_d = []
                for x in r[:6]:
                    val = x & 0xFFFF
                    if val >= 32768:
                        val -= 65536
                    new_d.append(val)
                
                for i in range(6):
                    if self._port_mode_cache.get(i+1) == self.MODE_ANGLE:
                        c = new_d[i]
                        d = (c - self._la[i]) & 0xFFFF
                        if d > 32767:
                            d -= 65536
                        self._aa[i] += d
                        self._la[i] = c
                        
                self.d = new_d
                self.v = (r[6] & 0xFFF) / 100.0
        except Exception:
            pass
        return self.d

    def _send(self, l1, l2, l3, l4):
        cmd = [max(0, min(100, int(x))) for x in (l1, l2, l3, l4)]
        if cmd == self._last_cmd:
            return 

        now = self._time.ticks_ms()
        try:
            elapsed = self._time.ticks_diff(now, self._last_send_time)
        except AttributeError:
            self._last_send_time = now
            elapsed = self._throttle_ms
            
        if elapsed < self._throttle_ms:
            self._time.sleep((self._throttle_ms - elapsed) / 1000.0)
            
        try:
            self._port_obj.device.mode(5, bytes(cmd))
        except Exception:
            pass
        
        self._last_cmd = cmd
        self._last_send_time = self._time.ticks_ms()

    def _send_oneshot(self, l1, l2, l3, l4):
        self._send(l1, l2, l3, l4)
        self._time.sleep(self._throttle_ms * 2.5 / 1000.0)
        self._send(100, 0, 0, 0)

    # ==========================
    # 核心控制指令
    # ==========================
    def motor_run(self, port_num, speed):
        op = 1 if speed >= 0 else 2
        self._send(port_num * 11, op, abs(int(speed)), 0)

    def motor_power(self, port_num, power):
        op = 1 if power >= 0 else 2
        self._send(port_num * 10, op, abs(int(power)), 0)

    def motor_stop(self, port_num):
        self._send(port_num * 10, self.DIR_COAST, 0, 0)

    def motor_brake(self, port_num):
        self._send(port_num * 11, self.DIR_BRAKE, 0, 0)

    def motor_set_pid(self, port_num, p, i, d):
        self._send(80 + port_num, p, i, d)

    def motor_run_degrees(self, port_num, speed, degrees):
        deg = min(abs(int(degrees)), 9999)
        # 方向 = 速度正負 × 角度正負（跟 Pybricks 庫一致）：兩者符號相同→正轉(8)，相異→反轉(9)
        op = 9 if (speed < 0) != (degrees < 0) else 8
        self._send_oneshot(port_num * 10 + op, abs(int(speed)), deg // 100, deg % 100)

    def motor_run_target(self, port_num, speed, angle):
        t = int(angle) % 360
        self._send_oneshot(port_num * 10 + 7, abs(int(speed)), t // 100, t % 100)

    def set_port_mode(self, port_num, mode):
        if mode == self.MODE_RESET:
            self._send(69 + port_num, mode, 0, 0)
            self._time.sleep(0.05)
            self._send(100, 0, 0, 0) # Oneshot
            self._port_mode_cache[port_num] = self.MODE_ANGLE
        else:
            self._send(69 + port_num, mode, 0, 0)
            self._port_mode_cache[port_num] = mode
            self._time.sleep(0.02)

    def drive(self, left_port, right_port, left_speed, right_speed):
        l2 = (0 if left_speed >= 0 else 2) | (0 if right_speed >= 0 else 1)
        self._send(left_port * 10 + right_port, l2, abs(int(left_speed)), abs(int(right_speed)))

    def drive_stop(self, left_port, right_port):
        self._send(left_port * 10 + right_port, self.DIR_COAST, 0, 0)

    def stop_all(self):
        self._send(0, 0, 0, 0)

    def reset_angle(self, port_num):
        self.set_port_mode(port_num, self.MODE_RESET)
        self.set_port_mode(port_num, self.MODE_ANGLE)
        
        for _ in range(20):
            self.update()
            if abs(self.d[port_num - 1]) < 5:
                break
            self._time.sleep(0.02)
            
        self.update()
        self._la[port_num - 1] = self.d[port_num - 1]
        self._aa[port_num - 1] = 0

    # ==========================
    # 狀態讀取指令
    # ==========================
    def _ensure_mode(self, port_num, mode):
        if self._port_mode_cache.get(port_num) != mode:
            self.set_port_mode(port_num, mode)
            self._time.sleep(0.05)

    def get_port_raw(self, port_num):
        self.update()
        return self.d[port_num - 1]

    def get_ultrasonic_distance(self, port_num):
        self._ensure_mode(port_num, self.MODE_DISTANCE)
        return self.get_port_raw(port_num)

    def get_touch_force(self, port_num):
        self._ensure_mode(port_num, self.MODE_FORCE)
        return self.get_port_raw(port_num)

    def get_motor_angle(self, port_num):
        self._ensure_mode(port_num, self.MODE_ANGLE)
        self.update()
        return self._aa[port_num - 1]

    def get_motor_abs_angle(self, port_num):
        # 韌體送的是 -180~179；% 360 換成 0~359（跟 Pybricks 庫一致）
        self._ensure_mode(port_num, self.MODE_ABS_ANGLE)
        return self.get_port_raw(port_num) % 360

    def get_motor_speed(self, port_num):
        self._ensure_mode(port_num, self.MODE_SPEED)
        return self.get_port_raw(port_num)

    def _get_rgb(self, port_num):
        self._ensure_mode(port_num, self.MODE_COLOR)
        val = self.get_port_raw(port_num)
        r = ((val >> 11) & 0x1F) * 100 // 31
        g = ((val >> 5) & 0x3F) * 100 // 63
        b = (val & 0x1F) * 100 // 31
        return (r, g, b)

    def get_color_color(self, port_num):
        h, s, v = self.get_color_hsv(port_num)
        if v < 15: return 0
        if s < 25:
            if v > 60: return 10
            else: return 0
        if h < 20 or h > 340: return 9
        elif 30 <= h <= 80: return 7
        elif 100 <= h <= 150: return 5
        elif 160 <= h <= 200: return 4
        elif 210 <= h <= 270: return 3
        elif 280 <= h <= 330: return 1
        return 0

    def get_color_reflection(self, port_num):
        r, g, b = self._get_rgb(port_num)
        return max(r, g, b)

    def get_color_rgb(self, port_num):
        return self._get_rgb(port_num)

    def get_color_hsv(self, port_num):
        r, g, b = self._get_rgb(port_num)
        cmax = max(r, g, b)
        cmin = min(r, g, b)
        delta = cmax - cmin
        h = 0
        if delta == 0: h = 0
        elif cmax == r: h = 60 * (((g - b) / delta) % 6)
        elif cmax == g: h = 60 * (((b - r) / delta) + 2)
        elif cmax == b: h = 60 * (((r - g) / delta) + 4)
        s = 0 if cmax == 0 else (delta / cmax) * 100
        v = cmax
        return (int(h), int(s), int(v))

    def get_color_hue(self, port_num): return self.get_color_hsv(port_num)[0]
    def get_color_sat(self, port_num): return self.get_color_hsv(port_num)[1]
    def get_color_val(self, port_num): return self.get_color_hsv(port_num)[2]
    def get_color_red(self, port_num): return self._get_rgb(port_num)[0]
    def get_color_green(self, port_num): return self._get_rgb(port_num)[1]
    def get_color_blue(self, port_num): return self._get_rgb(port_num)[2]

    def get_device_id(self, port_num):
        # 從上行第 7、8 筆取裝置代碼：R7 = 電壓 12-bit + 孔1 代碼；R8 = 孔2~6 代碼各 3-bit。
        # 0 無、1 力量、3 顏色、4 超音波、5 馬達、7 其他（跟 Pybricks 庫一致）。讀不到資料回 0。
        try:
            r = self._port_obj.device.get()
        except Exception:
            return self.DEV_NONE
        if not r or len(r) < 8:
            return self.DEV_NONE
        if port_num == 1:
            return ((r[6] & 0xFFFF) >> 12) & 0x7
        return ((r[7] & 0xFFFF) >> ((port_num - 2) * 3)) & 0x7
    # ==========================
    # v2：MBC 感應器 / MBC sensors（需搭配 EXP6 韌體 Exp6_v2）
    # ==========================
    # 宣告感應器插在 EXP6 的哪一孔，回傳該感應器的物件（感應器要先切到 SPIKE 模式）：
    #     line8 = exp.line8(2)      # 循行者 8 路插在 EXP6 的 2 號孔
    #     print(line8.pos100())
    # 可用：line8 line16 laser2 laser8 ps2 ps4 unicam（神攝手，mode 要跟相機選單一樣：exp.unicam(3, 13)）
    def line8(self, port_num):      return EXP6_LINE8(self, port_num)
    def line16(self, port_num):     return EXP6_LINE16(self, port_num)
    def laser2(self, port_num):     return EXP6_LASER2(self, port_num)
    def laser8(self, port_num):     return EXP6_LASER8(self, port_num)
    def ps2(self, port_num):        return EXP6_PS(self, port_num)
    def ps4(self, port_num):        return EXP6_PS(self, port_num)
    def unicam(self, port_num, mode=13): return EXP6_UNICAM(self, port_num, mode)

    def _mbc_id(self, r, port_num):
        # R7 = 電壓 12-bit + 孔1 裝置碼；R8 = 孔2~6 裝置碼各 3-bit
        if port_num == 1:
            return ((r[6] & 0xFFFF) >> 12) & 0x7
        return ((r[7] & 0xFFFF) >> ((port_num - 2) * 3)) & 0x7

    # 讀第 port_num 孔感應器 mode 的第 ofs、ofs+1 個 byte，回傳 (lo, hi)；讀不到回傳 None。
    # 官方 App 每孔只有 int16，放不下「回應的欄位」，所以換欄位後固定等 2 個 Hub 輪詢週期。
    def _mbc_read(self, port_num, mode, ofs):
        _mbc_check_port(port_num)
        r = self._mbc_frame()
        if (r is None or self._mbc_id(r, port_num) != _DEV_MBC
                or self._mbc_win.get(port_num) != (mode, ofs)):
            self._last_cmd = None   # 允許重送同一筆：感應器拔插後 EXP6 已把這孔的格式打回預設
            self._send(69 + port_num, _FMT_MBC_WINDOW, mode, ofs)
            self._port_mode_cache[port_num] = _FMT_MBC_WINDOW   # v1 的讀值函式下次會重送自己的格式
            self._mbc_win[port_num] = (mode, ofs)
            t0 = self._time.ticks_ms()
            self._time.sleep(self._throttle_ms * 2 / 1000.0)
            while True:
                r = self._mbc_frame()
                if r is not None and self._mbc_id(r, port_num) == _DEV_MBC:
                    break
                if self._time.ticks_diff(self._time.ticks_ms(), t0) > _MBC_TIMEOUT_MS:
                    self._mbc_win.pop(port_num, None)
                    self._mbc_warn(port_num)
                    return None
                self._time.sleep(0.01)
        v = r[port_num - 1] & 0xFFFF
        return v & 0xFF, v >> 8

    def _mbc_warn(self, port_num):
        now = self._time.ticks_ms()
        last = self._mbc_warn_ms.get(port_num)
        if last is None or self._time.ticks_diff(now, last) >= _MBC_WARN_MS:
            print("[EXP6] 孔{n} 讀不到 MBC 感應器（確認已插好、已切到 SPIKE 模式）/ No MBC sensor on EXP6 port {n} (check cable and SPIKE mode)".format(n=port_num))
            self._mbc_warn_ms[port_num] = now


    def _mbc_frame(self):
        try:
            r = self._port_obj.device.get()
        except Exception:
            return None
        return r if (r and len(r) >= 8) else None

    def get_voltage(self):
        self.update()
        return self.v

    # 跟 Pybricks 版同名，讓兩邊範例寫法一致（exp6.keep_alive_wait(3000)）。
    # 官方 App 路徑沒有看門狗，不需要心跳：keep_alive() 什麼都不做，keep_alive_wait(ms) 就是等 ms 毫秒。
    def keep_alive(self):
        pass

    def keep_alive_wait(self, ms):
        self._time.sleep(ms / 1000.0)

# ==========================
# 程式導向 API
# ==========================
# ==========================
# v2：MBC 感應器物件（由 exp.line8(port) 這類方法建立）
# ==========================
# 函式名稱與回傳值跟各感應器直插 Hub 的函式庫相同（一次回傳整組資料的函式除外）。
# 每個函式讀 1 次「2 bytes 視窗」；同一個視窗的函式（例如 pos8 與 width）連續呼叫最快，
# 換到別的視窗第一次約多 2~3 個 Hub 輪詢週期。讀不到感應器時回傳 None 並印提示。
_DEV_MBC        = 6     # EXP6 回報「MBC 感應器視窗已生效」的裝置碼
_FMT_MBC_WINDOW = 100   # EXP6 fmt=100：L3 = 感應器 mode、L4 = 起始 byte
_MBC_TIMEOUT_MS = 400
_MBC_WARN_MS    = 2000

def _mbc_check_port(port_num):
    if isinstance(port_num, bool) or not isinstance(port_num, int) or not (1 <= port_num <= 6):
        raise ValueError("port=%r 不是有效孔位，必須是 1~6 的整數 / must be an integer 1~6" % (port_num,))

def _s8(b):
    return b - 256 if b >= 128 else b

def _check_ch_range(ch, n):
    if isinstance(ch, bool) or not isinstance(ch, int) or not (1 <= ch <= n):
        raise ValueError("ch must be 1~{}, got {}".format(n, ch))

_JUNCTION_NAMES = {0: "none", 1: "line", 2: "junction"}

class _EXP6_SENSOR:
    _MODE = 9   # MBC 感應器在 SPIKE 模式的完整資料 mode

    def __init__(self, exp, port_num):
        _mbc_check_port(port_num)
        self._exp = exp
        self._port = port_num

    def _get(self, ofs, fn):
        b = self._exp._mbc_read(self._port, self._MODE, ofs)
        return None if b is None else fn(b[0], b[1])


# 循行者 8 路：pos8() -8~+8、width() 0~8、pos100() -100~+100、junction() 0~2+、
# junction_name() "none"/"line"/"junction"、bin_raw() 0~255、on_sensors() [int]、ir_ch(ch) 0~100
class EXP6_LINE8(_EXP6_SENSOR):
    def pos8(self):          return self._get(8,  lambda lo, hi: lo - 8)
    def width(self):         return self._get(8,  lambda lo, hi: hi)
    def pos100(self):        return self._get(10, lambda lo, hi: lo - 100)
    def junction(self):      return self._get(10, lambda lo, hi: hi)
    def junction_name(self): return self._get(10, lambda lo, hi: _JUNCTION_NAMES.get(min(hi, 2), "junction"))
    def bin_raw(self):       return self._get(12, lambda lo, hi: lo)
    def on_sensors(self):
        return self._get(12, lambda lo, hi: [i + 1 for i in range(8) if lo & (1 << i)])
    def ir_ch(self, ch):
        _check_ch_range(ch, 8)
        idx = ch - 1
        return self._get(idx & ~1, lambda lo, hi: hi if idx & 1 else lo)


# 循行者 16 路：pos16() -16~+16、width()、pos100()、junction()、junction_name()、
# bin_raw() 0~65535、on_sensors()、ir_ch(ch) 0~15（ch = 1~16）
class EXP6_LINE16(_EXP6_SENSOR):
    def pos16(self):         return self._get(8,  lambda lo, hi: lo - 16)
    def width(self):         return self._get(8,  lambda lo, hi: hi)
    def pos100(self):        return self._get(10, lambda lo, hi: lo - 100)
    def junction(self):      return self._get(10, lambda lo, hi: hi)
    def junction_name(self): return self._get(10, lambda lo, hi: _JUNCTION_NAMES.get(min(hi, 2), "junction"))
    def bin_raw(self):       return self._get(12, lambda lo, hi: lo | (hi << 8))
    def on_sensors(self):
        return self._get(12, lambda lo, hi: [i + 1 for i in range(16) if (lo | (hi << 8)) & (1 << i)])
    def ir_ch(self, ch):
        _check_ch_range(ch, 16)
        idx = ch - 1
        byte_i = idx >> 1
        shift = 4 if idx & 1 else 0
        return self._get(byte_i & ~1, lambda lo, hi: ((hi if byte_i & 1 else lo) >> shift) & 0x0F)


# 兩路雷射 TOF2：left() right() average() min_distance()（0~120 cm，120 = 沒目標）、
# min_side()（-1 左較近、+1 右較近、0 相等）、diff()（左 - 右）、ch(ch)、is_ok(ch)
class EXP6_LASER2(_EXP6_SENSOR):
    def left(self):         return self._get(0, lambda lo, hi: lo)
    def right(self):        return self._get(0, lambda lo, hi: hi)
    def average(self):      return self._get(0, lambda lo, hi: (lo + hi) >> 1)
    def min_distance(self): return self._get(0, lambda lo, hi: min(lo, hi))
    def min_side(self):     return self._get(0, lambda lo, hi: -1 if lo < hi else (1 if hi < lo else 0))
    def diff(self):         return self._get(0, lambda lo, hi: lo - hi)
    def ch(self, ch):
        _check_ch_range(ch, 2)
        return self._get(0, lambda lo, hi: hi if ch == 2 else lo)
    def is_ok(self, ch):
        _check_ch_range(ch, 2)
        bit = 1 << (ch - 1)
        return self._get(2, lambda lo, hi: (lo & bit) != 0 and (hi & bit) == 0)


# 八方位雷射 TOF8：ch(ch) 0~120（ch = 1~8）、min_direction() -8~+8、min_distance()、
# max_direction()、max_distance()、init_status() [bool]*8、fault_status() [bool]*8、is_ok(ch)
class EXP6_LASER8(_EXP6_SENSOR):
    def ch(self, ch):
        _check_ch_range(ch, 8)
        idx = ch - 1
        return self._get(idx & ~1, lambda lo, hi: hi if idx & 1 else lo)
    def min_direction(self): return self._get(8,  lambda lo, hi: lo - 8)
    def min_distance(self):  return self._get(8,  lambda lo, hi: hi)
    def max_direction(self): return self._get(10, lambda lo, hi: lo - 8)
    def max_distance(self):  return self._get(10, lambda lo, hi: hi)
    def init_status(self):   return self._get(12, lambda lo, hi: [(lo & (1 << i)) != 0 for i in range(8)])
    def fault_status(self):  return self._get(12, lambda lo, hi: [(hi & (1 << i)) != 0 for i in range(8)])
    def is_ok(self, ch):
        _check_ch_range(ch, 8)
        bit = 1 << (ch - 1)
        return self._get(12, lambda lo, hi: (lo & bit) != 0 and (hi & bit) == 0)


# PS2 遙控接收器 / PS4 藍牙遙控：buttons() 16-bit（PSX 排列：b15 ■ b14 Ⅹ b13 ● b12 ▲ b11 R1
# b10 L1 b9 R2 b8 L2 b7 左 b6 下 b5 右 b4 上 b3 START b2 R3 b1 L3 b0 SELECT）、
# pressed(name)、pressed_buttons()、lx() ly() rx() ry() 1~9（5 = 中心）
_PS_BUTTONS = {
    "square": 15, "cross": 14, "circle": 13, "triangle": 12,
    "r1": 11, "l1": 10, "r2": 9, "l2": 8,
    "left": 7, "down": 6, "right": 5, "up": 4,
    "start": 3, "r3": 2, "l3": 1, "select": 0,
}

def _ps_word(lo, hi):
    return ((hi >> 4) << 12) | ((lo & 0x0F) << 8) | ((hi & 0x0F) << 4) | (lo >> 4)

class EXP6_PS(_EXP6_SENSOR):
    _MODE = 0
    def buttons(self): return self._get(0, _ps_word)
    def pressed(self, name):
        key = str(name).strip().lower()
        if key not in _PS_BUTTONS:
            raise ValueError("unknown button {!r}, use one of {}".format(name, sorted(_PS_BUTTONS)))
        bit = 1 << _PS_BUTTONS[key]
        return self._get(0, lambda lo, hi: (_ps_word(lo, hi) & bit) != 0)
    def pressed_buttons(self):
        return self._get(0, lambda lo, hi: [k for k, b in _PS_BUTTONS.items() if _ps_word(lo, hi) & (1 << b)])
    def lx(self): return self._get(2, lambda lo, hi: (lo | (hi << 8)) // 10)
    def ly(self): return self._get(2, lambda lo, hi: (lo | (hi << 8)) % 10)
    def rx(self): return self._get(4, lambda lo, hi: (lo | (hi << 8)) // 10)
    def ry(self): return self._get(4, lambda lo, hi: (lo | (hi << 8)) % 10)


# 神攝手（韌體 v1）/ Sharpshooter Vision：cam = exp.unicam(port, mode=13)，函式同 Pybricks 版 UniCam
#   mode＝相機模式 ×10＋子選項，要跟相機選單切的一樣（SPIKE 讀不到相機目前的模式）
#   11 顏色追蹤 最多色  12 多色  13 標準 XY＋面積  14 精細 XYWH   21 座標取色 色相  22 色相＋飽和
#   23 色相＋飽和＋明度   30 照順序給色號   41 循線 黑線  42 白線  43 色線   51 物體清單  52 物體詳細
#   每個函式只讀它要的 byte（相鄰 2 個一次）；hsv()／device_id() 讀 2 次，order() 讀 7 次（較慢）。
#   座標像素 X 0~159、Y 0~119（上＝小），(0, 0)＝沒找到；色相碼 0~255；循線偏移線在左＝負。
_UC_MODES = (11, 12, 13, 14, 21, 22, 23, 30, 41, 42, 43, 51, 52)
_UC_NCOL = {11: 14, 12: 7, 13: 4, 14: 2}
_UC_NPT = {21: 14, 22: 7, 23: 4}
_UC_NOBJ = {51: 4, 52: 2}
_UC_LINE = (41, 42, 43)
SHAPES = ('other', 'circle', 'ellipse', 'triangle', 'square', 'rectangle', 'pentagon', 'hexagon', 'star', 'trapezoid')
SHAPES_ZH = ('其他', '圓', '橢圓', '三角', '正方', '長方', '五邊', '六邊', '星', '梯形')

# 色相碼 → 'red' 'orange' 'yellow' 'green' 'cyan' 'blue' 'purple' 'white' 'black'（None＝沒有）
def color_name(h):
    if h is None:
        return None
    if h > 248:
        return 'black'
    if h > 240:
        return 'white'
    if h < 12 or h >= 220:
        return 'red'
    if h < 28:
        return 'orange'
    if h < 56:
        return 'yellow'
    if h < 100:
        return 'green'
    if h < 140:
        return 'cyan'
    if h < 180:
        return 'blue'
    return 'purple'

# 形狀編號 0~9 → 名稱；zh=True 回中文
def shape_name(s, zh=False):
    if s is None or not 0 <= s <= 9:
        return None
    return SHAPES_ZH[s] if zh else SHAPES[s]

def _uc_windows(idxs):
    ks = []
    for i in sorted(set(idxs)):
        if not ks or i > ks[-1] + 1:
            ks.append(i)
    return ks

def _uc_xy_idx(m, c):
    if m == 11:
        return (c - 1,)
    k = {12: 2, 13: 3, 14: 6}[m] * (c - 1)
    return (k, k + 1)

def _uc_xy(b, m, c):
    if m == 11:
        g = b[c - 1]
        if not g:
            return (0, 0)
        return (((g - 1) % 16) * 10 + 5, ((g - 1) // 16) * 10 + 5)
    k = {12: 2, 13: 3, 14: 6}[m] * (c - 1)
    return (b[k], b[k + 1])

def _uc_count6_idx(m, c):
    if m == 11:
        bit = 42 if c == 0 else 3 * (c - 1)
        return (bit // 8, (bit + 3) // 8) if c == 0 else (bit // 8, (bit + 2) // 8)
    return (3,) if c == 0 else ((c - 1) // 2,)

def _uc_count6(b, m, c):
    if m == 11:
        bits = 0
        for i in range(6):
            bits |= b[i] << (8 * i)
        return (bits >> (3 * (c - 1))) & 7 if c else (bits >> 42) & 15
    if c == 0:
        return b[3] & 15
    x = b[(c - 1) // 2]
    return x >> 4 if c % 2 else x & 15

def _uc_hsv_idx(m, i):
    if m == 21:
        return (i - 1,)
    if m == 22:
        return (2 * i - 2, 2 * i - 1)
    return (3 * i - 3, 3 * i - 2, 3 * i - 1)

def _uc_hsv(b, m, i):
    if m == 21:
        return (b[i - 1], None, None)
    if m == 22:
        return (b[2 * i - 2], b[2 * i - 1], None)
    return (b[3 * i - 3], b[3 * i - 2], b[3 * i - 1])

def _uc_ob_code(b, m, k):
    if m == 51:
        return b[k]
    return b[k] * 10 + b[k + 1] if b[k] else 0

class EXP6_UNICAM(_EXP6_SENSOR):
    def __init__(self, exp, port_num, mode=13):
        if mode not in _UC_MODES:
            raise ValueError('mode 要填 %s / mode must be one of %s' % (_UC_MODES, _UC_MODES))
        _EXP6_SENSOR.__init__(self, exp, port_num)
        self._m = mode

    # 讀感應器 smode 的 idxs 這些 byte，湊成 16 bytes 交給 fn(b)；任何一次讀不到回傳 None
    def _uc(self, smode, idxs, fn):
        b = [0] * 16
        for k in _uc_windows(idxs):
            r = self._exp._mbc_read(self._port, smode, k)
            if r is None:
                return None
            b[k], b[k + 1] = r
        return fn(b)

    def _need(self, name, ok):
        if self._m not in ok:
            raise ValueError('%s(): 模式 %d 沒有這個值，要用模式 %s / not available in mode %d, use mode %s'
                             % (name, self._m, ok, self._m, ok))

    def _col(self, c, n):
        if not 1 <= c <= n:
            raise ValueError('第幾色／第幾點要填 1~%d / colour or spot must be 1~%d' % (n, n))

    def _obj(self, name, i, ok=(51, 52)):
        self._need(name, ok)
        n = _UC_NOBJ[self._m]
        if not 1 <= i <= n:
            raise ValueError('第幾個物體要填 1~%d / object must be 1~%d' % (n, n))
        return 3 * i - 2 if self._m == 51 else 7 * (i - 1)

    # 共用：mode_number() sensor_ok() device_id()→(0x4C, hw0, 韌體版字) is_unicam() firmware_version()→(主, 次)
    def mode_number(self):
        return self._m

    def sensor_ok(self):
        return self._uc(9, (0,), lambda b: True) is not None

    def device_id(self):
        return self._uc(8, (0, 1, 4, 5), lambda b: (b[0], b[1], b[4] | (b[5] << 8)))

    def is_unicam(self):
        return self._uc(8, (0, 1), lambda b: (b[0] | (b[1] << 8)) == 0x034C)

    def firmware_version(self):
        return self._uc(8, (4, 5), lambda b: ((b[4] | (b[5] << 8)) // 100, (b[4] | (b[5] << 8)) % 100))

    # 相機模式 1 顏色追蹤（11~14）：max_color() xy(c) x(c) y(c) found(c) cell(c) area(c) size(c) count(c) colors_found()
    def max_color(self):
        self._need('max_color', (11, 12, 13, 14))
        return _UC_NCOL[self._m]

    def _cxy(self, name, color, j):
        self._need(name, (11, 12, 13, 14))
        self._col(color, _UC_NCOL[self._m])
        m = self._m
        return self._uc(9, _uc_xy_idx(m, color), lambda b: j(_uc_xy(b, m, color)))

    def xy(self, color):
        return self._cxy('xy', color, lambda p: p)

    def x(self, color):
        return self._cxy('x', color, lambda p: p[0])

    def y(self, color):
        return self._cxy('y', color, lambda p: p[1])

    def found(self, color):
        return self._cxy('found', color, lambda p: p[0] > 0)

    def cell(self, color):
        self._need('cell', (11,))
        self._col(color, 14)
        i = color - 1
        return self._uc(9, (i,), lambda b: (0, 0) if not b[i] else ((b[i] - 1) % 16 + 1, (b[i] - 1) // 16 + 1))

    def area(self, color):
        self._need('area', (13, 14))
        self._col(color, _UC_NCOL[self._m])
        i = 3 * color - 1 if self._m == 13 else 6 * color - 1
        return self._uc(9, (i,), lambda b: b[i])

    def size(self, color):
        self._need('size', (14,))
        self._col(color, 2)
        i = 6 * color - 4
        return self._uc(9, (i, i + 1), lambda b: (b[i], b[i + 1]))

    def count(self, color):
        self._need('count', (11, 12, 13, 14))
        self._col(color, _UC_NCOL[self._m])
        m = self._m
        if m in (11, 12):
            return self._uc(6, _uc_count6_idx(m, color), lambda b: _uc_count6(b, m, color))
        if m == 13:
            i = 12 + (color - 1) // 2
            return self._uc(9, (i,), lambda b: b[i] >> 4 if color % 2 else b[i] & 15)
        i = 6 * color - 2
        return self._uc(9, (i,), lambda b: b[i])

    def colors_found(self):
        self._need('colors_found', (11, 12, 14))
        m = self._m
        if m == 14:
            return self._uc(9, (12,), lambda b: b[12])
        return self._uc(6, _uc_count6_idx(m, 0), lambda b: _uc_count6(b, m, 0))

    # 相機模式 2 座標取色（21~23）：max_point() hue(i) sat(i) val(i) hsv(i) color(i)
    def max_point(self):
        self._need('max_point', (21, 22, 23))
        return _UC_NPT[self._m]

    def _pt(self, name, ok, point, sel, j):
        self._need(name, ok)
        self._col(point, _UC_NPT[self._m])
        m = self._m
        return self._uc(9, sel(_uc_hsv_idx(m, point)), lambda b: j(_uc_hsv(b, m, point)))

    def hue(self, point):
        return self._pt('hue', (21, 22, 23), point, lambda t: t[:1], lambda h: h[0])

    def sat(self, point):
        return self._pt('sat', (22, 23), point, lambda t: t[1:2], lambda h: h[1])

    def val(self, point):
        return self._pt('val', (23,), point, lambda t: t[2:3], lambda h: h[2])

    def hsv(self, point):
        return self._pt('hsv', (21, 22, 23), point, lambda t: t, lambda h: h)

    def color(self, point):
        return self._pt('color', (21, 22, 23), point, lambda t: t[:1], lambda h: color_name(h[0]))

    # 相機模式 3 照順序給色號（30）：order() 由左到右的色相碼（最多 13 塊，讀 7 次）、total() 總塊數
    def order(self):
        self._need('order', (30,))
        return self._uc(9, range(14), lambda b: b[:min(13, b[13])])

    def total(self):
        self._need('total', (30,))
        return self._uc(9, (13,), lambda b: b[13])

    # 相機模式 4 循線（41~43）：near() mid() far() angle() width() flags() junction() junction_dist()
    #   edges() far_width() marker() lost()（line_all() 拿掉，每個值都有自己的函式）
    def _li(self, name, i, signed=False):
        self._need(name, _UC_LINE)
        return self._uc(9, (i,), lambda b: _s8(b[i]) if signed else b[i])

    def near(self):
        return self._li('near', 0, True)

    def mid(self):
        return self._li('mid', 1, True)

    def far(self):
        return self._li('far', 2, True)

    def angle(self):
        return self._li('angle', 3, True)

    def width(self):
        return self._li('width', 4)

    def flags(self):
        return self._li('flags', 5)

    def junction(self):
        return self._li('junction', 6)

    def junction_dist(self):
        return self._li('junction_dist', 7)

    def edges(self):
        self._need('edges', _UC_LINE)
        return self._uc(9, (8, 9), lambda b: (_s8(b[8]), _s8(b[9])))

    def far_width(self):
        return self._li('far_width', 10)

    def marker(self):
        self._need('marker', _UC_LINE)
        return self._uc(9, (11, 12), lambda b: (b[11], b[12]))

    def lost(self):
        return self._li('lost', 13)

    # 相機模式 5 物體偵測（51、52）：max_object() object_count() object(i) object_found(i) object_color(i)
    #   object_shape(i) object_xy(i) object_size(i) object_area(i)；物體 1＝面積最大，只看目標色 1~8
    def max_object(self):
        self._need('max_object', (51, 52))
        return _UC_NOBJ[self._m]

    def object_count(self):
        self._need('object_count', (51,))
        return self._uc(9, (0,), lambda b: b[0])

    def _code(self, name, i, j):
        k = self._obj(name, i)
        m = self._m
        return self._uc(9, (k,) if m == 51 else (k, k + 1), lambda b: j(_uc_ob_code(b, m, k)))

    def object(self, i):
        return self._code('object', i, lambda c: c)

    def object_found(self, i):
        return self._code('object_found', i, lambda c: c > 0)

    def object_color(self, i):
        return self._code('object_color', i, lambda c: c // 10)

    def object_shape(self, i):
        return self._code('object_shape', i, lambda c: c % 10)

    def object_xy(self, i):
        k = self._obj('object_xy', i) + (1 if self._m == 51 else 2)
        return self._uc(9, (k, k + 1), lambda b: (b[k], b[k + 1]))

    def object_size(self, i):
        k = self._obj('object_size', i, (52,)) + 4
        return self._uc(9, (k, k + 1), lambda b: (b[k], b[k + 1]))

    def object_area(self, i):
        k = self._obj('object_area', i, (52,)) + 6
        return self._uc(9, (k,), lambda b: b[k])


def exp_motor_run(*a):         return _default_instance().motor_run(*a)
def exp_motor_power(*a):       return _default_instance().motor_power(*a)
def exp_motor_stop(*a):        return _default_instance().motor_stop(*a)
def exp_motor_brake(*a):       return _default_instance().motor_brake(*a)
def exp_motor_set_pid(*a):     return _default_instance().motor_set_pid(*a)
def exp_motor_run_degrees(*a): return _default_instance().motor_run_degrees(*a)
def exp_motor_run_target(*a):  return _default_instance().motor_run_target(*a)
def exp_set_port_mode(*a):     return _default_instance().set_port_mode(*a)
def exp_drive(*a):             return _default_instance().drive(*a)
def exp_drive_stop(*a):        return _default_instance().drive_stop(*a)
def exp_stop_all(*a):          return _default_instance().stop_all(*a)
def exp_reset_angle(*a):       return _default_instance().reset_angle(*a)

def exp_get_port_raw(*a):            return _default_instance().get_port_raw(*a)
def exp_get_ultrasonic_distance(*a): return _default_instance().get_ultrasonic_distance(*a)
def exp_get_touch_force(*a):         return _default_instance().get_touch_force(*a)

def exp_get_motor_angle(*a):     return _default_instance().get_motor_angle(*a)
def exp_get_motor_abs_angle(*a): return _default_instance().get_motor_abs_angle(*a)
def exp_get_motor_speed(*a):     return _default_instance().get_motor_speed(*a)

def exp_get_color_color(*a):      return _default_instance().get_color_color(*a)
def exp_get_color_reflection(*a): return _default_instance().get_color_reflection(*a)
def exp_get_color_rgb(*a):        return _default_instance().get_color_rgb(*a)
def exp_get_color_hsv(*a):        return _default_instance().get_color_hsv(*a)
def exp_get_color_hue(*a):        return _default_instance().get_color_hue(*a)
def exp_get_color_sat(*a):        return _default_instance().get_color_sat(*a)
def exp_get_color_val(*a):        return _default_instance().get_color_val(*a)
def exp_get_color_red(*a):        return _default_instance().get_color_red(*a)
def exp_get_color_green(*a):      return _default_instance().get_color_green(*a)
def exp_get_color_blue(*a):       return _default_instance().get_color_blue(*a)

def exp_get_device_id(*a): return _default_instance().get_device_id(*a)
def exp_get_voltage():     return _default_instance().get_voltage()

def exp_run_task(coro): pass
def run_task(coro): pass
def keep_alive(): pass
def keep_alive_wait(ms): utime.sleep(ms / 1000.0)

__all__ = [
    "exp_run_task", "run_task", "keep_alive", "keep_alive_wait",
    "DEV_NONE", "DEV_FORCE", "DEV_COLOR", "DEV_ULTRASONIC", "DEV_MOTOR",
    "DIR_HOLD", "DIR_CW", "DIR_CCW", "DIR_COAST", "DIR_BRAKE",
    "MODE_SPEED", "MODE_ANGLE", "MODE_ABS_ANGLE", "MODE_RESET",
    "MODE_COLOR", "MODE_RGB", "MODE_HSV", "MODE_DISTANCE", "MODE_FORCE",
    "exp_motor_run", "exp_motor_power", "exp_motor_stop", "exp_motor_brake",
    "exp_motor_set_pid", "exp_motor_run_degrees", "exp_motor_run_target",
    "exp_drive", "exp_drive_stop", "exp_stop_all", "exp_reset_angle",
    "exp_get_port_raw", "exp_get_motor_angle", "exp_get_motor_abs_angle", "exp_get_motor_speed",
    "exp_get_ultrasonic_distance", "exp_get_touch_force",
    "exp_get_color_color", "exp_get_color_reflection",
    "exp_get_color_rgb", "exp_get_color_hsv", "exp_get_color_hue",
    "exp_get_color_sat", "exp_get_color_val", "exp_get_color_red",
    "exp_get_color_green", "exp_get_color_blue", "exp_get_device_id",
    "exp_get_voltage", "exp_set_port_mode", "MBC_EXP6",
]
"""

try:
    with open(filename, "w") as f:
        f.write(source_code)
    print("安裝成功！(Installation Successful!)")
except Exception as e:
    print("安裝失敗 (Installation Failed):", repr(e))
print("=========================================")
