# MBC EXP6 MINDSTORMS 51515 Library Installer (玩具版專用)
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式專門適用於 LEGO MINDSTORMS 10.x / SPIKE App 2.x
# [EN] This program is designed for MINDSTORMS 10.x / SPIKE App 2.x
#
# 請在官方 App 中執行此程式，即可將函數庫安裝到主機中。

import sys

import os

# 在 SPIKE 2.x / MINDSTORMS 中，/lib 是預設會在 sys.path 裡面的全域路徑
# 把它裝在 /lib 就不需要去改範例程式的 sys.path 了！
try:
    os.mkdir('/lib')
except:
    pass

filename = "/lib/MBC_exp6_SPIKE_App_Lib.py"

print("=========================================")
print("開始安裝 " + filename + " (玩具版/SPIKE 2.x 專用)...")

source_code = """\
# Python Library for EXP6 Smart Expansion Board for MINDSTORMS 51515
# Author : MBC robotics
# Date   : 2026.07
#
# !! 此函式庫專供 LEGO MINDSTORMS 10.x / SPIKE App 2.x 使用 !!
# !! This library is designed for MINDSTORMS 10.x / SPIKE App 2.x !!

import hub, utime

_instances = []

def _default_instance():
    if not _instances:
        raise RuntimeError("請先建立擴充板物件 (例: exp = MBC_EXP6('F'))")
    return _instances[-1]

DEV_NONE = 0
DEV_FORCE = 1
DEV_COLOR = 3          # 跟韌體／Pybricks 庫一致（get_device_id 回傳的顏色感應器代碼）
DEV_ULTRASONIC = 4
DEV_MOTOR = 5

DIR_HOLD = 0
DIR_CW = 1
DIR_CCW = 2
DIR_COAST = 3
DIR_BRAKE = 4

MODE_SPEED = 0
MODE_ANGLE = 1
MODE_ABS_ANGLE = 2
MODE_RESET = 3
MODE_COLOR = 10
MODE_RGB = 11
MODE_HSV = 12
MODE_DISTANCE = 20
MODE_FORCE = 30

class MBC_EXP6:
    DEV_NONE = DEV_NONE
    DEV_FORCE = DEV_FORCE
    DEV_COLOR = DEV_COLOR
    DEV_ULTRASONIC = DEV_ULTRASONIC
    DEV_MOTOR = DEV_MOTOR

    DIR_HOLD = DIR_HOLD
    DIR_CW = DIR_CW
    DIR_CCW = DIR_CCW
    DIR_COAST = DIR_COAST
    DIR_BRAKE = DIR_BRAKE

    MODE_SPEED = MODE_SPEED
    MODE_ANGLE = MODE_ANGLE
    MODE_ABS_ANGLE = MODE_ABS_ANGLE
    MODE_RESET = MODE_RESET
    MODE_COLOR = MODE_COLOR
    MODE_RGB = MODE_RGB
    MODE_HSV = MODE_HSV
    MODE_DISTANCE = MODE_DISTANCE
    MODE_FORCE = MODE_FORCE

    def __init__(self, port_var, multitask=False):
        if type(port_var) == str:
            self._port_obj = getattr(hub.port, port_var)
        elif type(port_var) == int:
            self._port_obj = getattr(hub.port, ['A','B','C','D','E','F'][port_var])
        else:
            self._port_obj = port_var
            
        self.v = 0
        self.d = [0] * 6
        self._la = [0] * 6
        self._aa = [0] * 6
        self._port_mode_cache = {}
        
        self._time = utime
        self._last_send_time = self._time.ticks_ms()
        self._last_cmd = None
        self._throttle_ms = 20

        for _ in range(100):
            try:
                r = self._port_obj.device.get()
                if r and len(r) >= 8 and r[6] != 0:
                    break
            except Exception:
                pass
            self._time.sleep(0.02)
            
        # 校準輪詢週期：最多等 2 秒，資料一直沒更新就改用預設 25 ms，不會卡住
        try:
            last_tick = self._time.ticks_ms()
            last_d = self._port_obj.device.get()
            timed_out = False
            for _ in range(10):
                while True:
                    cur = self._port_obj.device.get()
                    if cur != last_d:
                        break
                    if self._time.ticks_diff(self._time.ticks_ms(), last_tick) > 2000:
                        timed_out = True
                        break
                    self._time.sleep(0.001)
                if timed_out:
                    break
                last_d = cur
            if timed_out:
                print("[EXP6] 讀不到擴充板資料更新，改用預設通訊週期 25 ms（請確認 EXP6 接在這個孔且已開電）")
                self._throttle_ms = 25
            else:
                period = self._time.ticks_diff(self._time.ticks_ms(), last_tick) / 10
                self._throttle_ms = max(20, int(period * 2))
        except Exception:
            self._throttle_ms = 25
            
        self._send(0, 0, 0, 0)
        self._time.sleep(0.1)
        self.update() 
        
        for i in range(1, 7):
            self.set_port_mode(i, self.MODE_ANGLE)
            
        self._time.sleep(0.05)
        self.update()
        for i in range(1, 7):
            self._la[i-1] = self.d[i-1]
            self._aa[i-1] = 0

        _instances.append(self)

    def update(self):
        try:
            r = self._port_obj.device.get()
            if r and len(r) >= 8:
                new_d = []
                for x in r[:6]:
                    val = x & 0xFFFF
                    if val >= 32768:
                        val -= 65536
                    new_d.append(val)
                
                for i in range(6):
                    if self._port_mode_cache.get(i+1) == self.MODE_ANGLE:
                        c = new_d[i]
                        d = (c - self._la[i]) & 0xFFFF
                        if d > 32767:
                            d -= 65536
                        self._aa[i] += d
                        self._la[i] = c
                        
                self.d = new_d
                self.v = (r[6] & 0xFFF) / 100.0
        except Exception:
            pass
        return self.d

    def _send(self, l1, l2, l3, l4):
        cmd = [max(0, min(100, int(x))) for x in (l1, l2, l3, l4)]
        if cmd == self._last_cmd:
            return 

        now = self._time.ticks_ms()
        try:
            elapsed = self._time.ticks_diff(now, self._last_send_time)
        except AttributeError:
            self._last_send_time = now
            elapsed = self._throttle_ms
            
        if elapsed < self._throttle_ms:
            self._time.sleep((self._throttle_ms - elapsed) / 1000.0)
            
        try:
            self._port_obj.device.mode(5, bytes(cmd))
        except Exception:
            pass
        
        self._last_cmd = cmd
        self._last_send_time = self._time.ticks_ms()

    def _send_oneshot(self, l1, l2, l3, l4):
        self._send(l1, l2, l3, l4)
        self._time.sleep(self._throttle_ms * 2.5 / 1000.0)
        self._send(100, 0, 0, 0)

    # ==========================
    # 核心控制指令
    # ==========================
    def motor_run(self, port_num, speed):
        op = 1 if speed >= 0 else 2
        self._send(port_num * 11, op, abs(int(speed)), 0)

    def motor_power(self, port_num, power):
        op = 1 if power >= 0 else 2
        self._send(port_num * 10, op, abs(int(power)), 0)

    def motor_stop(self, port_num):
        self._send(port_num * 10, self.DIR_COAST, 0, 0)

    def motor_brake(self, port_num):
        self._send(port_num * 11, self.DIR_BRAKE, 0, 0)

    def motor_set_pid(self, port_num, p, i, d):
        self._send(80 + port_num, p, i, d)

    def motor_run_degrees(self, port_num, speed, degrees):
        deg = min(abs(int(degrees)), 9999)
        # 方向 = 速度正負 × 角度正負（跟 Pybricks 庫一致）：兩者符號相同→正轉(8)，相異→反轉(9)
        op = 9 if (speed < 0) != (degrees < 0) else 8
        self._send_oneshot(port_num * 10 + op, abs(int(speed)), deg // 100, deg % 100)

    def motor_run_target(self, port_num, speed, angle):
        t = int(angle) % 360
        self._send_oneshot(port_num * 10 + 7, abs(int(speed)), t // 100, t % 100)

    def set_port_mode(self, port_num, mode):
        if mode == self.MODE_RESET:
            self._send(69 + port_num, mode, 0, 0)
            self._time.sleep(0.05)
            self._send(100, 0, 0, 0) # Oneshot
            self._port_mode_cache[port_num] = self.MODE_ANGLE
        else:
            self._send(69 + port_num, mode, 0, 0)
            self._port_mode_cache[port_num] = mode
            self._time.sleep(0.02)

    def drive(self, left_port, right_port, left_speed, right_speed):
        l2 = (0 if left_speed >= 0 else 2) | (0 if right_speed >= 0 else 1)
        self._send(left_port * 10 + right_port, l2, abs(int(left_speed)), abs(int(right_speed)))

    def drive_stop(self, left_port, right_port):
        self._send(left_port * 10 + right_port, self.DIR_COAST, 0, 0)

    def stop_all(self):
        self._send(0, 0, 0, 0)

    def reset_angle(self, port_num):
        self.set_port_mode(port_num, self.MODE_RESET)
        self.set_port_mode(port_num, self.MODE_ANGLE)
        
        for _ in range(20):
            self.update()
            if abs(self.d[port_num - 1]) < 5:
                break
            self._time.sleep(0.02)
            
        self.update()
        self._la[port_num - 1] = self.d[port_num - 1]
        self._aa[port_num - 1] = 0

    # ==========================
    # 狀態讀取指令
    # ==========================
    def _ensure_mode(self, port_num, mode):
        if self._port_mode_cache.get(port_num) != mode:
            self.set_port_mode(port_num, mode)
            self._time.sleep(0.05)

    def get_port_raw(self, port_num):
        self.update()
        return self.d[port_num - 1]

    def get_ultrasonic_distance(self, port_num):
        self._ensure_mode(port_num, self.MODE_DISTANCE)
        return self.get_port_raw(port_num)

    def get_touch_force(self, port_num):
        self._ensure_mode(port_num, self.MODE_FORCE)
        return self.get_port_raw(port_num)

    def get_motor_angle(self, port_num):
        self._ensure_mode(port_num, self.MODE_ANGLE)
        self.update()
        return self._aa[port_num - 1]

    def get_motor_abs_angle(self, port_num):
        # 韌體送的是 -180~179；% 360 換成 0~359（跟 Pybricks 庫一致）
        self._ensure_mode(port_num, self.MODE_ABS_ANGLE)
        return self.get_port_raw(port_num) % 360

    def get_motor_speed(self, port_num):
        self._ensure_mode(port_num, self.MODE_SPEED)
        return self.get_port_raw(port_num)

    def _get_rgb(self, port_num):
        self._ensure_mode(port_num, self.MODE_COLOR)
        val = self.get_port_raw(port_num)
        r = ((val >> 11) & 0x1F) * 100 // 31
        g = ((val >> 5) & 0x3F) * 100 // 63
        b = (val & 0x1F) * 100 // 31
        return (r, g, b)

    def get_color_color(self, port_num):
        h, s, v = self.get_color_hsv(port_num)
        if v < 15: return 0
        if s < 25:
            if v > 60: return 10
            else: return 0
        if h < 20 or h > 340: return 9
        elif 30 <= h <= 80: return 7
        elif 100 <= h <= 150: return 5
        elif 160 <= h <= 200: return 4
        elif 210 <= h <= 270: return 3
        elif 280 <= h <= 330: return 1
        return 0

    def get_color_reflection(self, port_num):
        r, g, b = self._get_rgb(port_num)
        return max(r, g, b)

    def get_color_rgb(self, port_num):
        return self._get_rgb(port_num)

    def get_color_hsv(self, port_num):
        r, g, b = self._get_rgb(port_num)
        cmax = max(r, g, b)
        cmin = min(r, g, b)
        delta = cmax - cmin
        h = 0
        if delta == 0: h = 0
        elif cmax == r: h = 60 * (((g - b) / delta) % 6)
        elif cmax == g: h = 60 * (((b - r) / delta) + 2)
        elif cmax == b: h = 60 * (((r - g) / delta) + 4)
        s = 0 if cmax == 0 else (delta / cmax) * 100
        v = cmax
        return (int(h), int(s), int(v))

    def get_color_hue(self, port_num): return self.get_color_hsv(port_num)[0]
    def get_color_sat(self, port_num): return self.get_color_hsv(port_num)[1]
    def get_color_val(self, port_num): return self.get_color_hsv(port_num)[2]
    def get_color_red(self, port_num): return self._get_rgb(port_num)[0]
    def get_color_green(self, port_num): return self._get_rgb(port_num)[1]
    def get_color_blue(self, port_num): return self._get_rgb(port_num)[2]

    def get_device_id(self, port_num):
        # 從上行第 7、8 筆取裝置代碼：R7 = 電壓 12-bit + 孔1 代碼；R8 = 孔2~6 代碼各 3-bit。
        # 0 無、1 力量、3 顏色、4 超音波、5 馬達、7 其他（跟 Pybricks 庫一致）。讀不到資料回 0。
        try:
            r = self._port_obj.device.get()
        except Exception:
            return self.DEV_NONE
        if not r or len(r) < 8:
            return self.DEV_NONE
        if port_num == 1:
            return ((r[6] & 0xFFFF) >> 12) & 0x7
        return ((r[7] & 0xFFFF) >> ((port_num - 2) * 3)) & 0x7
    def get_voltage(self):
        self.update()
        return self.v

    # 跟 Pybricks 版同名，讓兩邊範例寫法一致（exp6.keep_alive_wait(3000)）。
    # 官方 App 路徑沒有看門狗，不需要心跳：keep_alive() 什麼都不做，keep_alive_wait(ms) 就是等 ms 毫秒。
    def keep_alive(self):
        pass

    def keep_alive_wait(self, ms):
        self._time.sleep(ms / 1000.0)

# ==========================
# 程式導向 API
# ==========================
def exp_motor_run(*a):         return _default_instance().motor_run(*a)
def exp_motor_power(*a):       return _default_instance().motor_power(*a)
def exp_motor_stop(*a):        return _default_instance().motor_stop(*a)
def exp_motor_brake(*a):       return _default_instance().motor_brake(*a)
def exp_motor_set_pid(*a):     return _default_instance().motor_set_pid(*a)
def exp_motor_run_degrees(*a): return _default_instance().motor_run_degrees(*a)
def exp_motor_run_target(*a):  return _default_instance().motor_run_target(*a)
def exp_set_port_mode(*a):     return _default_instance().set_port_mode(*a)
def exp_drive(*a):             return _default_instance().drive(*a)
def exp_drive_stop(*a):        return _default_instance().drive_stop(*a)
def exp_stop_all(*a):          return _default_instance().stop_all(*a)
def exp_reset_angle(*a):       return _default_instance().reset_angle(*a)

def exp_get_port_raw(*a):            return _default_instance().get_port_raw(*a)
def exp_get_ultrasonic_distance(*a): return _default_instance().get_ultrasonic_distance(*a)
def exp_get_touch_force(*a):         return _default_instance().get_touch_force(*a)

def exp_get_motor_angle(*a):     return _default_instance().get_motor_angle(*a)
def exp_get_motor_abs_angle(*a): return _default_instance().get_motor_abs_angle(*a)
def exp_get_motor_speed(*a):     return _default_instance().get_motor_speed(*a)

def exp_get_color_color(*a):      return _default_instance().get_color_color(*a)
def exp_get_color_reflection(*a): return _default_instance().get_color_reflection(*a)
def exp_get_color_rgb(*a):        return _default_instance().get_color_rgb(*a)
def exp_get_color_hsv(*a):        return _default_instance().get_color_hsv(*a)
def exp_get_color_hue(*a):        return _default_instance().get_color_hue(*a)
def exp_get_color_sat(*a):        return _default_instance().get_color_sat(*a)
def exp_get_color_val(*a):        return _default_instance().get_color_val(*a)
def exp_get_color_red(*a):        return _default_instance().get_color_red(*a)
def exp_get_color_green(*a):      return _default_instance().get_color_green(*a)
def exp_get_color_blue(*a):       return _default_instance().get_color_blue(*a)

def exp_get_device_id(*a): return _default_instance().get_device_id(*a)
def exp_get_voltage():     return _default_instance().get_voltage()

def exp_run_task(coro): pass
def run_task(coro): pass
def keep_alive(): pass
def keep_alive_wait(ms): utime.sleep(ms / 1000.0)

__all__ = [
    "exp_run_task", "run_task", "keep_alive", "keep_alive_wait",
    "DEV_NONE", "DEV_FORCE", "DEV_COLOR", "DEV_ULTRASONIC", "DEV_MOTOR",
    "DIR_HOLD", "DIR_CW", "DIR_CCW", "DIR_COAST", "DIR_BRAKE",
    "MODE_SPEED", "MODE_ANGLE", "MODE_ABS_ANGLE", "MODE_RESET",
    "MODE_COLOR", "MODE_RGB", "MODE_HSV", "MODE_DISTANCE", "MODE_FORCE",
    "exp_motor_run", "exp_motor_power", "exp_motor_stop", "exp_motor_brake",
    "exp_motor_set_pid", "exp_motor_run_degrees", "exp_motor_run_target",
    "exp_drive", "exp_drive_stop", "exp_stop_all", "exp_reset_angle",
    "exp_get_port_raw", "exp_get_motor_angle", "exp_get_motor_abs_angle", "exp_get_motor_speed",
    "exp_get_ultrasonic_distance", "exp_get_touch_force",
    "exp_get_color_color", "exp_get_color_reflection",
    "exp_get_color_rgb", "exp_get_color_hsv", "exp_get_color_hue",
    "exp_get_color_sat", "exp_get_color_val", "exp_get_color_red",
    "exp_get_color_green", "exp_get_color_blue", "exp_get_device_id",
    "exp_get_voltage", "exp_set_port_mode", "MBC_EXP6",
]
"""

try:
    with open(filename, "w") as f:
        f.write(source_code)
    print("安裝成功！(Installation Successful!)")
except Exception as e:
    print("安裝失敗 (Installation Failed):", repr(e))
print("=========================================")
