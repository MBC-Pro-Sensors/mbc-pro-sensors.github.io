# 範例 09：MBC 感應器插在 EXP6 上 (MBC Sensors on EXP6)（v2）
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式適用於 Lego Education SPIKE App 版本 3.4.3，需要 EXP6 韌體 Exp6_v2
# [EN] For Lego Education SPIKE App 3.4.3; needs EXP6 firmware Exp6_v2
#
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請先在主機中執行過 `Install_MBC_exp6_Lib_v2.py`。感應器要先切到 SPIKE 模式。
#      官方 App 每次「換讀別的欄位」約多 40~100 ms；同一組欄位（例如 pos8 與 width）連續讀最快。
# [EN] Run `Install_MBC_exp6_Lib_v2.py` on the hub first. Switch each sensor to SPIKE mode.

from hub import port
import time
from MBC_exp6_SPIKE_App_Lib_v2 import MBC_EXP6

print("==============================")
print(" 範例 09：MBC 感應器（v2）")
print("==============================")

exp = MBC_EXP6(port.F)   # EXP6 插在 Hub 的 F 孔
time.sleep(1)

line8  = exp.line8(2)    # 循行者 8 路插在 EXP6 的 2 號孔
laser2 = exp.laser2(3)   # 兩路雷射插在 3 號孔
ps     = exp.ps4(4)      # PS4 藍牙遙控插在 4 號孔（PS2 用 exp.ps2(4)）

# [展示 1] 循行者 8 路
print("\n[展示 1] 循行者 8 路")
for i in range(5):
    print("  pos8={}  width={}  pos100={}".format(line8.pos8(), line8.width(), line8.pos100()))
    time.sleep(0.2)

# [展示 2] 兩路雷射：left/right/average/min_side/diff 都在同一組欄位
print("\n[展示 2] 兩路雷射")
for i in range(5):
    print("  左={} 右={} 較近的一邊={}".format(laser2.left(), laser2.right(), laser2.min_side()))
    time.sleep(0.2)

# [展示 3] 遙控器：按 ✕ 結束
print("\n[展示 3] 遙控器（按 ✕ 結束）")
while not ps.pressed("cross"):
    print("  按下:", ps.pressed_buttons())
    time.sleep(0.2)

print("\n測試結束！")
