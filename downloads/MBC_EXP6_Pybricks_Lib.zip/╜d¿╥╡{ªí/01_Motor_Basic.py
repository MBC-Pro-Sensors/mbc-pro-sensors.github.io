# 範例 01：馬達基礎控制 (Motor Basic Control) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3   # EXP6 擴充板插在 Hub 的哪個孔位 (1~6，對應 Port.A~F)
PORT = 1       # 馬達接在擴充板的哪個孔位

# Set up.
exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 01：馬達基礎控制測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：motor_run(port, speed)
    # ---------------------------------------------------------
    print("\n[展示 1] motor_run() - 以速度模式持續轉動")
    print("{} 號孔馬達以速度 50 正轉...".format(PORT))
    await exp6.motor_run(PORT, 50)
    await wait(2000)

    print("{} 號孔馬達以速度 -80 反轉...".format(PORT))
    await exp6.motor_run(PORT, -80)
    await wait(2000)

    # ---------------------------------------------------------
    # API 展示：motor_stop(port, stop) - stop 必填，三種狀態比較
    # ---------------------------------------------------------
    print("\n[展示 2] motor_stop() - stop 參數決定滑行/煞車/鎖死")
    await exp6.motor_run(PORT, 100)
    await wait(1000)
    print("stop=1(coast) -> 馬達會滑行一段距離才停")
    await exp6.motor_stop(PORT, 1)
    await wait(2000)

    await exp6.motor_run(PORT, 100)
    await wait(1000)
    print("stop=2(brake) -> 馬達會瞬間被動煞車")
    await exp6.motor_stop(PORT, 2)
    await wait(2000)

    await exp6.motor_run(PORT, 100)
    await wait(1000)
    print("stop=3(hold) -> 馬達會主動鎖死")
    await exp6.motor_stop(PORT, 3)
    await wait(2000)

    # ---------------------------------------------------------
    # API 展示：motor_power(port, power)
    # ---------------------------------------------------------
    print("\n[展示 3] motor_power() - 原始電力輸出 (無速度閉迴圈控制)")
    print("這與 motor_run 不同，是不帶 PID 速度鎖定的純電壓輸出")
    print("{} 號孔馬達以 40% 電力運轉...".format(PORT))
    await exp6.motor_power(PORT, 40)
    await wait(2000)
    await exp6.motor_stop(PORT, 1)

    # ---------------------------------------------------------
    # API 展示：motor_set_pid(port, p, i, d) - 0~100，50=原廠值
    # ---------------------------------------------------------
    print("\n[展示 4] motor_set_pid() - 自訂 PID 倍率")
    print("設定 {} 號馬達的 PID 倍率 (P=80, I=30, D=60)".format(PORT))
    await exp6.motor_set_pid(PORT, 80, 30, 60)
    await exp6.motor_run(PORT, 60)
    await wait(1500)
    await exp6.motor_stop(PORT, 2)

    print("\n測試結束！")

run_task(main())
