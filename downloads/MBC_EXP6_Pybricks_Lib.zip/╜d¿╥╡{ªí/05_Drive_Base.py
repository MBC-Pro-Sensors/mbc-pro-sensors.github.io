# 範例 05：底盤運動控制 (Drive Base Control) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
LEFT = 1
RIGHT = 2

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 05：底盤雙輪驅動測試")
    print("==============================")
    print("假設您的車子：左輪接在擴充板 {} 號孔，右輪接在 {} 號孔".format(LEFT, RIGHT))

    # ---------------------------------------------------------
    # API 展示：drive(left_port, right_port, left_speed, right_speed)
    # ---------------------------------------------------------
    print("\n[展示 1] drive() - 雙輪同步前進")
    print("左右輪都以 50 速度前進 (直走)...")
    await exp6.drive(LEFT, RIGHT, 50, 50)
    await wait(2000)

    print("\n[展示 2] drive() - 雙輪同步後退")
    print("左右輪都以 -40 速度後退...")
    await exp6.drive(LEFT, RIGHT, -40, -40)
    await wait(2000)

    print("\n[展示 3] drive() - 原地旋轉 (坦克轉)")
    print("左輪後退 (-50)，右輪前進 (50)，車子會原地左轉...")
    await exp6.drive(LEFT, RIGHT, -50, 50)
    await wait(1500)

    print("\n[展示 4] drive() - 大彎弧線 (差速轉向)")
    print("左輪慢 (20)，右輪快 (80)，車子會向左畫大圓弧...")
    await exp6.drive(LEFT, RIGHT, 20, 80)
    await wait(2000)

    # ---------------------------------------------------------
    # API 展示：drive_stop(left_port, right_port, stop) - stop 必填
    # ---------------------------------------------------------
    print("\n[展示 5] drive_stop() - 停止雙輪 (stop=1，滑行)")
    await exp6.drive_stop(LEFT, RIGHT, 1)
    await wait(1000)

    print("\n[展示 6] drive_stop() - 停止雙輪 (stop=3，兩輪協同鎖死)")
    print("兩輪同步中直接下 hold，車體會維持朝向、不會一邊鎖死一邊被推著轉...")
    await exp6.drive(LEFT, RIGHT, 50, 50)
    await wait(1000)
    await exp6.drive_stop(LEFT, RIGHT, 3)
    await wait(2000)

    await exp6.drive_stop(LEFT, RIGHT, 1)
    print("\n測試結束！")

run_task(main())
