# 範例 08：進階色彩分析 (Color Sensor) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT_COLOR = 5   # 請將顏色感測器接在 5 號孔

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 08：進階色彩分析測試")
    print("==============================")
    print("請將顏色感測器接在擴充板 {} 號孔".format(PORT_COLOR))

    for i in range(5):
        print("\n--- 第 {} 次取樣 ---".format(i + 1))

        # ---------------------------------------------------------
        # API 展示：官方色碼與反射光
        # ---------------------------------------------------------
        color_id = await exp6.get_color_color(PORT_COLOR)
        reflection = await exp6.get_color_reflection(PORT_COLOR)
        print("官方色碼 (0~10): {}".format(color_id))
        print("反射光強度 (0~100): {}".format(reflection))

        # ---------------------------------------------------------
        # API 展示：RGB 三原色讀取
        # ---------------------------------------------------------
        r, g, b = await exp6.get_color_rgb(PORT_COLOR)
        red = await exp6.get_color_red(PORT_COLOR)
        green = await exp6.get_color_green(PORT_COLOR)
        blue = await exp6.get_color_blue(PORT_COLOR)
        print("RGB 陣列: ({}, {}, {})".format(r, g, b))

        # ---------------------------------------------------------
        # API 展示：HSV 色彩空間 (可用於精細的循線或顏色辨識演算法)
        # ---------------------------------------------------------
        h, s, v = await exp6.get_color_hsv(PORT_COLOR)
        hue = await exp6.get_color_hue(PORT_COLOR)
        sat = await exp6.get_color_sat(PORT_COLOR)
        val = await exp6.get_color_val(PORT_COLOR)
        print("HSV 色彩: H={}°, S={}%, V={}%".format(hue, sat, val))

        await wait(1000)

    print("\n測試結束！")

run_task(main())
