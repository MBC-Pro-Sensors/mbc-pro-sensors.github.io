# 範例 10：多工併行與保活機制 (multitask / keep_alive) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.
#
# 本範例展示 Pybricks 版專屬、官方 SPIKE App 版不支援的能力：
# async 多工併行 (multitask)、長時間等待/運算時的保活機制 (keep_alive)。

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT = 1

exp6 = MBC_EXP6(HUB_PORT, True)

async def watch_speed():
    # 背景任務：每 200ms 印一次目前速度，跟主任務同時執行
    for _ in range(15):
        print("  [背景任務] 目前速度: {}".format(await exp6.get_motor_speed(PORT)))
        await wait(200)

async def drive_sequence():
    # 主任務：跑一段馬達動作
    print("[主任務] 開始轉動...")
    await exp6.motor_run(PORT, 60)
    await wait(2500)
    await exp6.motor_stop(PORT, 2)
    print("[主任務] 停止。")

async def main():
    print("==============================")
    print(" 範例 10：多工併行與保活機制測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：multitask() - 多個 async 任務同時執行
    # ---------------------------------------------------------
    print("\n[展示 1] multitask() - 背景讀速度 + 主任務轉馬達同時執行")
    await multitask(drive_sequence(), watch_speed())

    # ---------------------------------------------------------
    # API 展示：keep_alive_wait(ms) - 取代 wait()，長時間等待自動保活
    # ---------------------------------------------------------
    print("\n[展示 2] keep_alive_wait(ms) - 取代 wait()，長時間等待自動保活")
    print("等待 3 秒（背景自動送心跳，不會被看門狗誤判斷線）...")
    await exp6.keep_alive_wait(3000)

    # ---------------------------------------------------------
    # API 展示：keep_alive() - 長運算中間手動補心跳
    # ---------------------------------------------------------
    print("\n[展示 3] keep_alive() - 長運算中手動補心跳")
    total = 0
    for i in range(50000):
        total += i
        if i % 10000 == 0:
            await exp6.keep_alive()
    print("長運算完成，總和: {}".format(total))

    print("\n測試結束！multitask=True 模式下，背景已自動持續保活，")
    print("結束時也會自動停止所有馬達，不需要手動呼叫 stop_all()。")

run_task(main())
