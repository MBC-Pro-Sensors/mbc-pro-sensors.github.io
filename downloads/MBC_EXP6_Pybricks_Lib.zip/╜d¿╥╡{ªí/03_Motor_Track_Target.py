# 範例 03：絕對角度控制 (motor_track_target) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT = 1

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 03：motor_track_target() 絕對角度測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：motor_track_target(port, speed, angle, stop) - 走最短路徑
    # ---------------------------------------------------------
    print("\n[展示 1] motor_track_target() - 走最短路徑轉到絕對位置 90 度，鎖死")
    await exp6.motor_track_target(PORT, 50, 90, 3)
    await wait(200)
    while abs(await exp6.get_motor_speed(PORT)) > 0:
        await wait(50)
    print("到達目標！目前絕對角度: {}".format(await exp6.get_motor_abs_angle(PORT)))

    # ---------------------------------------------------------
    # API 展示：motor_run_target(...) - 舊名相容別名
    # ---------------------------------------------------------
    print("\n[展示 2] motor_run_target() - 舊名仍可用，走到絕對位置 270 度")
    await exp6.motor_run_target(PORT, 50, 270, 3)
    await wait(200)
    while abs(await exp6.get_motor_speed(PORT)) > 0:
        await wait(50)
    print("到達目標！目前絕對角度: {}".format(await exp6.get_motor_abs_angle(PORT)))

    # ---------------------------------------------------------
    # API 展示：stop=4(continue) - 到位後續轉，不會停
    # ---------------------------------------------------------
    print("\n[展示 3] stop=4(continue)：到位後續轉，不會停")
    await exp6.motor_track_target(PORT, 50, 90, 4)
    await wait(1000)
    print("到位後速度應該還在: {}（沒有變 0，代表真的沒停）".format(await exp6.get_motor_speed(PORT)))
    await wait(500)
    print("示範結束，手動用 motor_stop(stop=2) 停下馬達...")
    await exp6.motor_stop(PORT, 2)

    print("\n測試結束！")

run_task(main())
