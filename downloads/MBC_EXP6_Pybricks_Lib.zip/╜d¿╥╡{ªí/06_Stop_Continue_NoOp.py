# 範例 06：stop=4(continue)「維持現狀」測試 - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.
#
# 本範例展示：對 motor_stop/drive_stop/stop_all 這類「純停止指令」而言，
# stop=4(continue) 代表「維持現狀、不送任何指令」，馬達還在轉就繼續轉、
# 已經停了就繼續停著——不是拋錯，也不是 fallback 成某個預設狀態。
# (stop：1=coast 2=brake 3=hold 4=continue)

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT = 1
LEFT = 1
RIGHT = 2

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 06：stop=4(continue) 維持現狀測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：motor_stop(port, stop=4)
    # ---------------------------------------------------------
    print("\n[展示 1] motor_stop(port, stop=4) - 維持馬達現狀，不送任何指令")
    print("馬達以速度 60 持續轉動中...")
    await exp6.motor_run(PORT, 60)
    await wait(1000)
    print("呼叫 motor_stop(PORT, 4)（不會送出封包）...")
    await exp6.motor_stop(PORT, 4)
    await wait(1000)
    print("馬達應該還在轉，目前速度: {}（沒有被停下來）".format(await exp6.get_motor_speed(PORT)))
    await exp6.motor_stop(PORT, 2)
    print("示範結束，手動用 stop=2(brake) 停下馬達。")
    await wait(1000)

    # ---------------------------------------------------------
    # API 展示：drive_stop(left, right, stop=4)
    # ---------------------------------------------------------
    print("\n[展示 2] drive_stop(left, right, stop=4) - 雙馬達版維持現狀")
    print("請將另一顆馬達接在擴充板 {} 號孔".format(RIGHT))
    await exp6.drive(LEFT, RIGHT, 50, 50)
    await wait(1000)
    await exp6.drive_stop(LEFT, RIGHT, 4)
    await wait(1000)
    print("兩輪應該還在轉，左輪速度: {}（沒有被停下來）".format(await exp6.get_motor_speed(LEFT)))
    await exp6.drive_stop(LEFT, RIGHT, 1)
    print("示範結束，手動滑行停止。")
    await wait(1000)

    # ---------------------------------------------------------
    # API 展示：stop_all(stop=4)
    # ---------------------------------------------------------
    print("\n[展示 3] stop_all(stop=4) - 全域版維持現狀")
    await exp6.motor_run(PORT, 50)
    await wait(1000)
    await exp6.stop_all(4)
    await wait(1000)
    print("馬達應該還在轉，目前速度: {}（stop_all(4) 完全沒有動作）".format(await exp6.get_motor_speed(PORT)))
    await exp6.stop_all(1)
    print("示範結束，全部滑行停止。")

    print("\n測試結束！")

run_task(main())
