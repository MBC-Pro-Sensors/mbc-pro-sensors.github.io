# 範例 07：超音波與力量感測器 (Ultrasonic & Force Sensors) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT_US = 3      # 請將超音波接在 3 號孔
PORT_FORCE = 4   # 請將觸碰感測器接在 4 號孔

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 07：超音波與力量感測器測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：get_ultrasonic_distance(port)
    # ---------------------------------------------------------
    print("\n[展示 1] get_ultrasonic_distance() - 讀取 {} 號孔距離".format(PORT_US))
    print("開始連續讀取超音波數值 5 次 (單位: mm)...")
    for i in range(5):
        dist = await exp6.get_ultrasonic_distance(PORT_US)
        print("  距離: {} mm".format(dist))
        await wait(500)

    # ---------------------------------------------------------
    # API 展示：get_touch_force(port)
    # ---------------------------------------------------------
    print("\n[展示 2] get_touch_force() - 讀取 {} 號孔按壓力量".format(PORT_FORCE))
    print("請試著按壓觸碰感測器，連續讀取 5 次...")
    for i in range(5):
        # force 是 0~100 的百分比數值
        force = await exp6.get_touch_force(PORT_FORCE)
        if force > 0:
            print("  狀態: 被按下了！力量: {}%".format(force))
        else:
            print("  狀態: 未按下 (力量: {}%)".format(force))
        await wait(500)

    print("\n測試結束！")

run_task(main())
