# 範例 04：馬達正裝與反裝 (set_motor_inverted) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT = 1

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 04：馬達正裝/反裝測試")
    print("==============================")
    print("請將馬達接在擴充板 {} 號孔，觀察馬達實際轉動方向".format(PORT))

    # ---------------------------------------------------------
    # 展示：預設狀態（正裝，inverted=False）下 speed 正值的實際轉向
    # ---------------------------------------------------------
    print("\n[展示 1] 預設狀態（正裝）下，speed=50 的角度變化方向")
    await exp6.reset_angle(PORT)
    await exp6.motor_run(PORT, 50)
    await wait(1000)
    print("正裝時角度變化: {}".format(await exp6.get_motor_angle(PORT)))
    await exp6.motor_stop(PORT, 2)
    await wait(500)

    # ---------------------------------------------------------
    # API 展示：set_motor_inverted(port, inverted=True) - 設為反裝
    # ---------------------------------------------------------
    print("\n[展示 2] set_motor_inverted(port, True) - 設為反裝")
    print("反裝後，指令方向與角度讀值都會自動反過來，寫程式時完全不用改 speed 正負號")
    await exp6.set_motor_inverted(PORT, True)
    await exp6.reset_angle(PORT)
    await exp6.motor_run(PORT, 50)
    await wait(1000)
    print("反裝時角度變化: {}（應該跟展示 1 方向相反）".format(await exp6.get_motor_angle(PORT)))
    await exp6.motor_stop(PORT, 2)
    await wait(500)

    # ---------------------------------------------------------
    # API 展示：set_motor_inverted(port, inverted=False) - 改回正裝
    # ---------------------------------------------------------
    print("\n[展示 3] set_motor_inverted(port, False) - 改回正裝")
    await exp6.set_motor_inverted(PORT, False)
    await exp6.reset_angle(PORT)
    await exp6.motor_run(PORT, 50)
    await wait(1000)
    print("改回正裝後角度變化: {}（應該恢復跟展示 1 一致）".format(await exp6.get_motor_angle(PORT)))
    await exp6.motor_stop(PORT, 2)

    print("\n測試結束！適合用在馬達實際裝反、但不想每次下指令都手動加負號的情境。")

run_task(main())
