# 範例 09：系統與底層數據 (System & Misc) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT = 1

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 09：系統與底層數據測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：get_voltage()
    # ---------------------------------------------------------
    print("\n[展示 1] get_voltage() - 讀取擴充板電池電壓")
    voltage = await exp6.get_voltage()
    print("目前擴充板電池電壓: {} V".format(voltage))
    if voltage < 7.0:
        print("警告：電池電壓過低，請盡快充電！")

    # ---------------------------------------------------------
    # API 展示：get_device_id(port)
    # ---------------------------------------------------------
    print("\n[展示 2] get_device_id() - 讀取感測器裝置代碼")
    # 為了相容架構，馬達孔位通常會回報 5 (DEV_MOTOR)
    dev_id = await exp6.get_device_id(PORT)
    print("{} 號孔裝置代碼: {}".format(PORT, dev_id))

    # ---------------------------------------------------------
    # API 展示：set_port_mode(port, mode) 與 get_port_raw(port)
    # ---------------------------------------------------------
    print("\n[展示 3] 底層模式切換與原始數據讀取")
    print("這通常由高階 API 自動處理，但您可以手動覆寫。")

    print("將 6 號孔強制設定為距離模式 (MODE_DISTANCE)...")
    await exp6.set_port_mode(6, exp6.MODE_DISTANCE)
    await wait(100)

    print("直接讀取 6 號孔從底層傳來的 raw data:")
    raw_data = await exp6.get_port_raw(6)
    print("Raw Data: {}".format(raw_data))

    # ---------------------------------------------------------
    # 展示：connected 屬性 - 監控擴充板連線狀態
    # ---------------------------------------------------------
    print("\n[展示 4] connected 屬性 - 監控擴充板連線狀態")
    print("目前連線狀態 (True=已連線): {}".format(exp6.connected))
    print("拔掉/插上擴充板時，這個屬性會自動更新，並在主控台印出提示。")

    print("\n全部 API 測試結束！")

run_task(main())
