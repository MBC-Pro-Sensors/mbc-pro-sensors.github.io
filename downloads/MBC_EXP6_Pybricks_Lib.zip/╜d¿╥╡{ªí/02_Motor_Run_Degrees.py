# 範例 02：相對角度控制 (motor_run_degrees) - Pybricks 版
# ⚠️ 測試提醒 (Testing Reminder):
# [ZH] 執行前請確保 MBC_exp6_obj_Lib.py 已跟本檔放在同一個 Pybricks 專案內。
# [EN] Make sure MBC_exp6_obj_Lib.py is uploaded alongside this file in the same Pybricks project.

from pybricks.tools import multitask, run_task, wait
from MBC_exp6_obj_Lib import MBC_EXP6, run_task

HUB_PORT = 3
PORT = 1

exp6 = MBC_EXP6(HUB_PORT, True)

async def main():
    print("==============================")
    print(" 範例 02：motor_run_degrees() 相對角度測試")
    print("==============================")

    # ---------------------------------------------------------
    # API 展示：reset_angle(port) 與 get_motor_angle(port)
    # ---------------------------------------------------------
    print("\n[展示 1] reset_angle() 與 get_motor_angle() - 角度歸零與讀取")
    await exp6.reset_angle(PORT)
    print("已將 {} 號馬達角度歸零，目前角度: {}".format(PORT, await exp6.get_motor_angle(PORT)))

    # ---------------------------------------------------------
    # API 展示：motor_run_degrees(port, speed, degrees, stop) - 四種 stop 狀態比較
    # ---------------------------------------------------------
    print("\n[展示 2] motor_run_degrees() - 轉動 360 度後，四種 stop 狀態的差異")

    print("\n(a) stop=1(coast)：到位後滑行，會因慣性多滑一點才真正停下")
    await exp6.reset_angle(PORT)
    await exp6.motor_run_degrees(PORT, 60, 360, 1)
    await wait(200)
    while abs(await exp6.get_motor_speed(PORT)) > 0:
        await wait(50)
    await wait(300)
    print("停止後角度: {}".format(await exp6.get_motor_angle(PORT)))

    print("\n(b) stop=2(brake)：到位後被動煞車，比滑行更快停住")
    await exp6.reset_angle(PORT)
    await exp6.motor_run_degrees(PORT, 60, 360, 2)
    await wait(200)
    while abs(await exp6.get_motor_speed(PORT)) > 0:
        await wait(50)
    await wait(300)
    print("停止後角度: {}".format(await exp6.get_motor_angle(PORT)))

    print("\n(c) stop=3(hold)：到位後主動鎖死，外力推它會自動頂回目標角度")
    await exp6.reset_angle(PORT)
    await exp6.motor_run_degrees(PORT, 60, 360, 3)
    await wait(500)
    print("試著用手轉動馬達，應該會感覺到它主動抵抗、頂回原位...")
    await wait(2000)
    print("鎖死中的角度: {}".format(await exp6.get_motor_angle(PORT)))

    print("\n(d) stop=4(continue)：到位後『不停』，直接以原速度繼續轉動")
    await exp6.reset_angle(PORT)
    await exp6.motor_run_degrees(PORT, 60, 360, 4)
    await wait(500)
    print("到達 360 度後速度應該還在: {}（沒有變 0，代表真的沒停）".format(await exp6.get_motor_speed(PORT)))
    await wait(1000)

    # continue 會讓馬達持續轉動，示範完務必手動停止，否則會一直轉下去
    print("示範結束，手動用 motor_stop(stop=2) 停下馬達...")
    await exp6.motor_stop(PORT, 2)

    print("\n測試結束！")

run_task(main())
