# MBC_exp6_pad.py ── EXP6 六路馬達擴充器（Pybricks 4.x）：掌控者 PS2／PS4 接收器
#  2026-11-03 從 MBC_exp6_obj_Lib.py 分出來：主機程式上限 52 KB（程式＋所有函式庫），用到哪款才載入哪款。
#  需要 EXP6 韌體 2026-11-03 以後（組模式＋命令轉送）。函式名稱、回傳值跟直插 SPIKE 主機一樣。
#  用法 / usage（PS2、PS4）：
#    from MBC_exp6_obj_Lib import MBC_EXP6
#    from MBC_exp6_pad import *
#    exp6 = MBC_EXP6(3, False, p5=PS2)    # 3＝EXP6 插主機 C 孔（1～6＝A～F，寫數字）；宣告接在幾號孔：開始時讀產品碼核對，插錯直接說
#    s = exp6.sensor(5)                       # 照宣告拿物件（多工寫法也不用 await）
#    s = exp6.ps2(5)                           # 舊寫法也可以（不核對）
#    多工寫法（MBC_EXP6(3, True)）宣告時不核對；物件的每個函式都要 await。
from MBC_exp6_obj_Lib import (MBC_EXP6)
from MBC_exp6_mbc_common import (_EXP6_SENSOR, _MODE8, _f8, _gen, _id8, _kind, _lo, _mknm, _u)


# ── 掌控者 PS2／PS4（對應 MBC_sensors.py 的 MBC_GAMEPAD）──
#  模式 9：b0 方向鍵＋圖形鍵、b2 肩鍵＋功能鍵、b4／6／8／10 LX／LY／RX／RY 1~9、b12~13 PSX 排列
#  主要組（每 10 ms）：b0、b2 原樣＋4 支搖桿各 4 bit；PSX 排列照接收器韌體 psxButtons 的公式從 b0、b2 算
#  模式 3：[已連線, 電量]（呼叫 connected()／battery() 時）
#  每一圈先 pad.update() 讀一次，之後 pressed()／stick() 都用這一次的資料（同直插）
_BUTTONS = {
    'UP': 0, 'RIGHT': 1, 'DOWN': 2, 'LEFT': 3,
    'TRIANGLE': 4, 'CIRCLE': 5, 'CROSS': 6, 'SQUARE': 7,
    'L2': 8, 'R2': 9, 'L1': 10, 'R1': 11,
    'SELECT': 12, 'L3': 13, 'R3': 14, 'START': 15,
    'SHARE': 12, 'CREATE': 12, 'OPTIONS': 15,
}
_STICKS = {'LX': 2, 'LY': 3, 'RX': 4, 'RY': 5}
PSX_BITS = {
    'SELECT': 0, 'L3': 1, 'R3': 2, 'START': 3,
    'UP': 4, 'RIGHT': 5, 'DOWN': 6, 'LEFT': 7,
    'L2': 8, 'R2': 9, 'L1': 10, 'R1': 11,
    'TRIANGLE': 12, 'CIRCLE': 13, 'CROSS': 14, 'SQUARE': 15,
    'SHARE': 0, 'CREATE': 0, 'OPTIONS': 3,
}
PSX_SELECT, PSX_L3, PSX_R3, PSX_START = 1 << 0, 1 << 1, 1 << 2, 1 << 3
PSX_UP, PSX_RIGHT, PSX_DOWN, PSX_LEFT = 1 << 4, 1 << 5, 1 << 6, 1 << 7
PSX_L2, PSX_R2, PSX_L1, PSX_R1 = 1 << 8, 1 << 9, 1 << 10, 1 << 11
PSX_TRIANGLE, PSX_CIRCLE, PSX_CROSS, PSX_SQUARE = 1 << 12, 1 << 13, 1 << 14, 1 << 15
_KIND = {1: 'PS2', 2: 'PS4'}

def _pad_bt(v):
    return _lo(v[0]) | (_lo(v[1]) << 8)

def _pad_st(v, n):
    return _lo(v[_STICKS[n]])

class EXP6_PS(_EXP6_SENSOR):
    """掌控者 PS2／PS4：pad = exp6.ps2(port) 或 exp6.ps4(port)"""
    _SETS = {'main': ((9, ((0, 8), (2, 8), (4, 4), (6, 4), (8, 4), (10, 4))),),
             'conn': ((3, _f8(0, 1)),), 'm8': _MODE8}
    _S = {
        'update': ('main', lambda v: None, 1),
        'buttons': ('main', _pad_bt, 2),
        'pressed': ('main', lambda v, n: (_pad_bt(v) >> _BUTTONS[n]) & 1 == 1, 2),
        'any_pressed': ('main', lambda v: _pad_bt(v) != 0, 2),
        'stick': ('main', _pad_st, 2),
        'stick_centered': ('main', lambda v, n: _pad_st(v, n) - 5, 2),
        'buttons_psx': ('main', lambda v: _u(v[6]), 2),
        'pressed_psx': ('main', lambda v, n: (_u(v[6]) >> PSX_BITS[n]) & 1 == 1, 2),
        'connected': ('conn', lambda v: int(v[0]) == 1),
        'battery': ('conn', lambda v: int(v[1])),
        'kind': ('m8', lambda v: _KIND.get(_id8(v)[1], 'UNKNOWN')),
    }

    def _derive(self, mode, b):
        # PSX 排列沒送：照接收器韌體 psxButtons = (圖形<<12)|(肩<<8)|(方向<<4)|功能 從 b0、b2 算
        if mode == 9:
            psx = ((b[0] >> 4) << 12) | ((b[2] & 15) << 8) | ((b[0] & 15) << 4) | (b[2] >> 4)
            b[12] = psx & 0xFF
            b[13] = psx >> 8

    # EXP6 早期寫法（保留相容）/ legacy EXP6 names
    def pressed_buttons(self):
        """目前按下的按鍵名稱 list（小寫，舊寫法）"""
        if self._a():
            return self._pb_a()
        b = self.buttons()
        return None if b is None else [k.lower() for k, i in _BUTTONS.items()
                                       if k not in ('SHARE', 'CREATE', 'OPTIONS') and b & (1 << i)]

    async def _pb_a(self):
        b = await self.buttons()
        return None if b is None else [k.lower() for k, i in _BUTTONS.items()
                                       if k not in ('SHARE', 'CREATE', 'OPTIONS') and b & (1 << i)]

    def lx(self): return self.stick('LX')
    def ly(self): return self.stick('LY')
    def rx(self): return self.stick('RX')
    def ry(self): return self.stick('RY')

# update() 每一圈開頭讀一次，之後的值都用這一次的；buttons() 全部按鍵合成一個數字（排法同直插 MBC_GAMEPAD，
# 2026-11-03 起；以前的 PSX 排列改叫 buttons_psx()）；pressed(name)（'CROSS'、'UP'… 大小寫都可以）；
# any_pressed()；stick(name) 1~9（LX、LY、RX、RY）；stick_centered(name) -4~4；pressed_psx(name)；
# connected()；battery() 0~100（PS2 一直 0）；kind() 'PS2'／'PS4'／'UNKNOWN'
_gen(EXP6_PS, ('update', 'buttons', 'any_pressed', 'buttons_psx', 'connected', 'battery', 'kind'))
_gen(EXP6_PS, ('pressed',), _mknm(_BUTTONS, '按鍵'))
_gen(EXP6_PS, ('stick', 'stick_centered'), _mknm(_STICKS, '搖桿'))
_gen(EXP6_PS, ('pressed_psx',), _mknm(PSX_BITS, '按鍵'))


class EXP6_PS2(EXP6_PS):
    """PS2 接收器"""

class EXP6_PS4(EXP6_PS):
    """PS4 接收器"""

PS2 = _kind(EXP6_PS2, (0x42, 1))
PS4 = _kind(EXP6_PS4, (0x42, 2))
MBC_EXP6.ps2 = lambda self, port_num: EXP6_PS2(self, port_num)
MBC_EXP6.ps4 = lambda self, port_num: EXP6_PS4(self, port_num)
