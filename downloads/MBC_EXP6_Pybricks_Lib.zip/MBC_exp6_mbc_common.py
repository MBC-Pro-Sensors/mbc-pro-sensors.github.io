# MBC_exp6_mbc_common.py ── EXP6 六路馬達擴充器（Pybricks 4.x）：MBC 產品共用（組模式、命令轉送、宣告核對）
#  2026-11-03 從 MBC_exp6_obj_Lib.py 分出來：主機程式上限 52 KB（程式＋所有函式庫），用到哪款才載入哪款。
#  需要 EXP6 韌體 2026-11-03 以後（組模式＋命令轉送）。函式名稱、回傳值跟直插 SPIKE 主機一樣。
#  使用者不用 import 這個檔：MBC_exp6_line／laser／pad／unicam 會自動載入。
from MBC_exp6_obj_Lib import (MBC_EXP6, _CACHE_MS, _FMT_MBC_GROUP, _GRP_TIMEOUT_MS, _MBC_WARN_MS, _check_port, _watch)


# 讀第 port_num 孔感應器 mode 的第 ofs、ofs+1 個 byte，回傳 (lo, hi)；讀不到回傳 None。
# 上行回應的 mode / 起始 byte 不符（剛換欄位、感應器剛插上）就送視窗指令、等到符合為止。
def _mbc_warn(self, port_num):
    # 讀不到感應器的提示，每孔限流 _MBC_WARN_MS 印一次
    now = _watch.time()
    if now - self._mbc_warn_ms.get(port_num, -_MBC_WARN_MS) >= _MBC_WARN_MS:
        print("[EXP6] 孔{n} 讀不到 MBC 感應器（確認已插好）/ "
              "No MBC sensor on EXP6 port {n} (check the cable)".format(n=port_num))
        self._mbc_warn_ms[port_num] = now

# ── 2026-11-03 組模式（EXP6 韌體 L1=87／88／89；設計：05_開發紀錄\EXP6_功能補齊設計_20261103.md §3.1）──
#  組 = (模式, ((第幾 byte, 幾 bit), …))：第一次用到才在 EXP6 定義（組編號 1~31，這個物件自己管）；
#  每孔的輪流清單（1～2 組、同一個模式）跟上次不一樣才重送。2 組時只收「同一輪」的兩組（同一筆感應器資料）。
def _grp_plan(self, port, specs):
    out = []
    gids = []
    for sp in specs:
        g = self._grp_ids.get(sp)
        if g is None:
            if len(self._grp_ids) >= 31:
                raise RuntimeError("EXP6 組編號用完（同時用太多種讀法）/ too many EXP6 groups")
            g = len(self._grp_ids) + 1
            self._grp_ids[sp] = g
            out.append((87, g, sp[0], len(sp[1])))
            for i, (k, nb) in enumerate(sp[1]):
                out.append((88, g, k, i * 16 + nb - 1))
        gids.append(g)
    key = (gids[0], gids[1] if len(gids) > 1 else 0)
    if self._grp_act.get(port) != key:
        out.append((89, port, key[0], key[1]))
        self._grp_act[port] = key
        self._port_mode_cache[port] = _FMT_MBC_GROUP   # 這孔原本的樂高讀值格式作廢，get_motor_* 之類下次會重送自己的格式
    return out, gids

def _grp_fetch_sync(self, port, specs):
    # 回傳每組的 4 bytes（list）；讀不到回傳 None
    if not self.connected and not self._try_reconnect_sync():
        self._warn_no_board()
        return None
    for attempt in (0, 1):
        pk, gids = self._grp_plan(port, specs)
        for p in pk:
            self._send_sync(*p)
        got = {}
        raw = None if pk else self._read_sync()
        t0 = _watch.time()
        while True:
            r = _grp_take(raw, port, gids, got)
            if r is not None:
                return r
            if _watch.time() - t0 >= _GRP_TIMEOUT_MS:
                break
            self._fresh_sync()
            self._last_drain_ms = _watch.time()
            self._maybe_heartbeat_sync()
            raw = self._cache
        self._grp_act.pop(port, None)    # EXP6 那邊可能清掉了（感應器拔插、改用別的格式）：重送清單再試一次
    self._mbc_warn(port)
    return None

async def _grp_fetch_async(self, port, specs):
    if not self.connected and not await self._try_reconnect_async():
        self._warn_no_board()
        return None
    for attempt in (0, 1):
        pk, gids = self._grp_plan(port, specs)
        for p in pk:
            await self._send(*p)
        got = {}
        raw = None if pk else await self._read_async()
        t0 = _watch.time()
        while True:
            r = _grp_take(raw, port, gids, got)
            if r is not None:
                return r
            if _watch.time() - t0 >= _GRP_TIMEOUT_MS:
                break
            await self._fresh_async()
            self._last_drain_ms = _watch.time()
            await self._maybe_heartbeat_async()
            raw = self._cache
        self._grp_act.pop(port, None)
    self._mbc_warn(port)
    return None

# ════════════════════════════════════════════════════════════════
#  MBC 感應器物件（由 exp6.line8(port) 這類方法建立，不要直接 new）
#  MBC sensor objects (create them via exp6.line8(port) etc.)
#
#  2026-11-03 起改用 EXP6 韌體的「組模式」：每孔每 10 ms 送 4 bytes 的「組」（感應器資料裡挑好的欄位），
#  主要的值不用切換就一直更新；循行者光值、測距者 8 路 8 顆距離這類分成 2 組輪流、保證是同一筆資料。
#  函式名稱、回傳值跟直插 SPIKE 主機的函式庫一樣（MBC_sensors.py、MBC_UniCam.py）：收到的欄位放回
#  原本的位置，用同一套換算。讀不到感應器時回傳 None 並印提示。
#  需要 EXP6 韌體 2026-11-03 以後（組模式＋命令轉送）。
#  Since 2026-11-03 these use the EXP6 firmware "group" mode: each port sends 4 bytes of chosen fields
#  every 10 ms. Method names and values match the direct-connect libraries. Returns None if unreadable.
#  multitask=True 時每個函式都要 await / In multitask mode, await every call.
# ════════════════════════════════════════════════════════════════

def _s8(b):
    return b - 256 if b > 127 else b

def _check_ch_range(ch, n):
    if isinstance(ch, bool) or not isinstance(ch, int) or not (1 <= ch <= n):
        raise ValueError("ch must be 1~{}, got {}".format(n, ch))

# ── 跟直插函式庫 MBC_sensors.py 同一套的小工具 / same helpers as MBC_sensors.py ──
def _lo(w):
    return int(w) & 0xFF

def _hi(w):
    return (int(w) >> 8) & 0xFF

def _u(w):
    return int(w) & 0xFFFF

def _bits(m, n):
    return [(m >> i) & 1 == 1 for i in range(n)]

def _jn(j):
    return ('none', 'line', 'junction')[min(j, 2)]

def _id8(v):
    w = _u(v[0])
    return (w & 0xFF, w >> 8, _u(v[2]))

def _fw8(v):
    f = _u(v[2])
    return (f // 100, f % 100)

def _name(d, name, what):
    if name not in d:
        raise ValueError('沒有這個' + what + '名稱 / unknown name: ' + str(name))

async def _aw(x):
    return x

def _f8(*ks):
    # 一組欄位：每個 byte 原樣 8 bit / fields: whole bytes
    return tuple((k, 8) for k in ks)

# 每個模式讀回來的值是幾 bit 一個（照感應器描述表；跟 Pybricks PUPDevice.read() 一樣）
_VAL_BITS = {3: 8}          # 其他模式都是 int16 / other modes are int16
_MODE8 = ((8, _f8(0, 1, 2, 3)), (8, _f8(4, 5, 6, 7)))   # 識別＋命令回覆：模式 8 的 8 bytes（2 組同一筆）

def _vals(mode, b):
    # 原始 bytes → 跟 PUPDevice.read(mode) 一樣的有號整數 tuple（Pybricks 主機沒有大整數，逐 byte 拼）
    if _VAL_BITS.get(mode, 16) == 8:
        return tuple(_s8(x) for x in b[:8])
    r = []
    for i in range(0, 16, 2):
        w = b[i] | (b[i + 1] << 8)
        r.append(w - 65536 if w > 32767 else w)
    return tuple(r)

def _unpack(d, fields, mir):
    # 4 bytes 的組資料 → 照欄位表放回 mir 原本的位置（欄位從 bit0 往上擠）
    pos = 0
    for k, nb in fields:
        v = 0
        got = 0
        while got < nb and pos < 32:
            i = pos >> 3
            bit = pos & 7
            take = min(8 - bit, nb - got)
            v |= ((d[i] >> bit) & ((1 << take) - 1)) << got
            got += take
            pos += take
        mir[k] = v & 0xFF
        if nb > 8:
            mir[k + 1] = (v >> 8) & 0xFF

def _popcount(x):
    c = 0
    while x:
        c += x & 1
        x >>= 1
    return c

def _runs(x, n):
    # 位元圖裡有幾段連續的 1（＝循行者韌體的線段數 groupCount）
    c = p = 0
    for i in range(n):
        b = (x >> i) & 1
        if b and not p:
            c += 1
        p = b
    return c


class _EXP6_SENSOR:
    # _SETS：組集合名稱 → (組, …)；組 = (模式, ((第幾 byte, 幾 bit), …))；同一個集合 1～2 組要同一個模式
    # _S   ：函式名稱 → (組集合名稱, 解碼函式 f(v, *參數), 讀法 0 = 10 ms 快取、1 = 一定重讀、2 = 有舊的就用)
    _SETS = {}
    _S = {}

    def __init__(self, exp6, port_num):
        _check_port(port_num)
        self._exp6 = exp6
        self._port = port_num
        self._mir = {}      # 模式 → bytearray(32)：收到的欄位放回原本的位置
        self._t = {}        # 組集合名稱 → 上次讀到的時間
        self._ok = False    # 最近一次有沒有讀到
        self._sq = None     # 下命令：最後一個序號（1～99）
        self._unsent = False  # 第一個命令因為讀不到感應器沒送出（wait_done 要回 False）
        self._ck = None     # 　　　　最後一個 (命令碼, 參數…)
        self._pk = None     # 　　　　最後送出的封包（重送用）
        self._ct = 0        # 　　　　最後送出的時間

    def _a(self):
        self._exp6._check_init()
        return self._exp6._async_mode

    def _r(self, x):
        return _aw(x) if self._exp6._async_mode else x

    def _derive(self, mode, b):
        # 子類別：用韌體的公式補上沒送的欄位（例：16 路線寬＝黑白圖有幾個 1）
        pass

    def _sets(self, sname):
        return self._SETS[sname]

    def _cached(self, sname, rt):
        t = self._t.get(sname)
        if t is None or rt == 1:
            return False
        return rt == 2 or _watch.time() - t < _CACHE_MS

    def _store(self, sname, specs, ds):
        mode = specs[0][0]
        b = self._mir.get(mode)
        if b is None:
            b = self._mir[mode] = bytearray(32)
        for d, s in zip(ds, specs):
            _unpack(d, s[1], b)
        self._derive(mode, b)
        self._t[sname] = _watch.time()
        self._ok = True

    def _fetch(self, sname, rt):
        if self._cached(sname, rt):
            return True
        specs = self._sets(sname)
        for i in range(0, len(specs), 2):          # 超過 2 組（整組讀）：每 2 組讀一次
            part = specs[i:i + 2]
            ds = self._exp6._grp_fetch_sync(self._port, part)
            if ds is None:
                self._ok = False
                return False
            self._store(sname, part, ds)
        return True

    async def _fetch_a(self, sname, rt):
        if self._cached(sname, rt):
            return True
        specs = self._sets(sname)
        for i in range(0, len(specs), 2):
            part = specs[i:i + 2]
            ds = await self._exp6._grp_fetch_async(self._port, part)
            if ds is None:
                self._ok = False
                return False
            self._store(sname, part, ds)
        return True

    def _g(self, sname, f, a=(), rt=0):
        if self._a():
            return self._ga(sname, f, a, rt)
        if not self._fetch(sname, rt):
            return None
        mode = self._sets(sname)[0][0]
        return f(_vals(mode, self._mir[mode]), *a)

    async def _ga(self, sname, f, a, rt):
        if not await self._fetch_a(sname, rt):
            return None
        mode = self._sets(sname)[0][0]
        return f(_vals(mode, self._mir[mode]), *a)

    def _q(self, name, *a):
        x = self._S.get(name)
        if x is None:
            raise ValueError(name + '(): EXP6 讀不到這個值 / cannot read this value')
        return self._g(x[0], x[1], a, x[2] if len(x) > 2 else 0)

    # ───── 共用 / common ─────
    def sensor_ok(self):
        """最近一次有沒有讀到感應器：True／False"""
        return self._r(self._ok)

    def device_id(self):
        """(id, hw0, 韌體版字)，例如 (22, 8, 100)"""
        return self._g('m8', _id8)

    def firmware_version(self):
        """感應器韌體版本 (主版, 次版)，例如 (1, 0)"""
        return self._g('m8', _fw8)

    # ───── 下命令（感應器韌體要支援命令：模式 8 第 2 個值的 bit 8 = 1）─────
    #  上位機 → EXP6：L1=90+孔 寫參數（L2 欄位、值 = L3×100＋L4，＋10 = 負數），L1=97 送出；
    #  EXP6 → 感應器：跟 SPIKE 主機 PUPDevice.write(9, (序號, 命令碼, p1~p5)) 一樣的 byte。
    #  序號 1～99（EXP6 命令的 L 值上限 100）；同一個命令＋同樣參數再呼叫不會重做，要再做一次寫 again=True。
    #  參數 -9999～9999。cmd_state()／busy()／wait_done() 要讀模式 8（感應器暫時切過去），只在迴圈外用。
    def _cmd_pkts(self, code, p, seq):
        L1 = 90 + self._port
        out = [(L1, 0, 0, code - 0xE0)]
        for i, x in enumerate(p):
            x = int(x)
            ax = -x if x < 0 else x
            out.append((L1, i + 1 + (10 if x < 0 else 0), ax // 100, ax % 100))
        out.append((97, self._port, seq, 0))
        return out

    def _cpk(self, code, p, again, v):
        # 算出要送的封包；None = 不用送（同命令同參數，或還讀不到感應器）
        if isinstance(code, bool) or not isinstance(code, int) or not 0xE0 <= code <= 0xEE:
            raise ValueError('cmd(): 命令碼要 0xE0~0xEE / code must be 0xE0~0xEE')
        if len(p) > 5:
            raise ValueError('cmd(): 參數最多 5 個 / at most 5 parameters')
        for x in p:
            if not -9999 <= int(x) <= 9999:
                raise ValueError('cmd(): EXP6 參數要 -9999~9999 / parameters must be -9999~9999')
        k = (code,) + tuple(int(x) for x in p)
        if k == self._ck and not again:
            return None
        if self._sq is None:
            if v is None:
                self._unsent = True
                return None
            if not (_u(v[1]) & 0x100):
                raise ValueError('cmd(): 感應器韌體太舊，不支援命令，請更新韌體 / sensor firmware too old for commands')
            self._sq = _hi(v[3])        # 從感應器最後收下的序號 +1 開始，才不會跟上一個程式撞號
        self._sq = self._sq % 99 + 1
        self._ck = k
        self._pk = self._cmd_pkts(code, p, self._sq)
        self._ct = _watch.time()
        return self._pk

    def _m8(self):
        if not self._fetch('m8', 1):
            return None
        return _vals(8, self._mir[8])

    async def _m8_a(self):
        if not await self._fetch_a('m8', 1):
            return None
        return _vals(8, self._mir[8])

    def _send_pk(self, pk):
        for x in pk:
            self._exp6._send_sync(*x)
        self._t = {}                    # 下過命令：讀值快取作廢

    async def _send_pk_a(self, pk):
        for x in pk:
            await self._exp6._send(*x)
        self._t = {}

    def cmd(self, code, *p, again=False):
        """下命令：code = 命令碼（例 0xE2），p = 參數（最多 5 個）。回傳這次的序號"""
        if self._a():
            return self._cmd_a(code, p, again)
        pk = self._cpk(code, p, again, self._m8() if self._sq is None else None)
        if pk is not None:
            self._send_pk(pk)
        return self._sq

    async def _cmd_a(self, code, p, again):
        pk = self._cpk(code, p, again, (await self._m8_a()) if self._sq is None else None)
        if pk is not None:
            await self._send_pk_a(pk)
        return self._sq

    def _cs(self, v):
        if v is None or self._sq is None or _hi(v[3]) != self._sq:
            return None
        return _lo(v[3])

    def cmd_state(self):
        """最後一個命令的狀態：0 完成、1 執行中、2 失敗、3 拒絕；感應器還沒收到 = None"""
        if self._a():
            return self._cs_a()
        return self._cs(self._m8())

    async def _cs_a(self):
        return self._cs(await self._m8_a())

    def _bz(self, v):
        if self._sq is None:
            return False
        s = self._cs(v)
        return s is None or s == 1

    def busy(self):
        """最後一個命令還沒做完（或感應器還沒收到）= True"""
        if self._a():
            return self._bz_a()
        return self._bz(self._m8())

    async def _bz_a(self):
        return self._bz(await self._m8_a())

    def _wd(self, v, t0, to):
        # wait_done 的一步：True／False = 結束；None = 繼續等；第 2 個值 = 要不要重送
        if self._sq is None:
            return (not self._unsent), False   # 沒下過命令＝True；命令沒送出（讀不到感應器）＝False
        s = self._cs(v)
        t = _watch.time()
        if s is not None and s != 1:
            return s == 0, False
        if t - t0 >= to:
            return False, False
        if s is None and t - self._ct >= 300:   # 300 ms 還沒收到：同一個序號重送（感應器不會重做）
            self._ct = t
            return None, True
        return None, False

    def wait_done(self, timeout=10000):
        """等最後一個命令做完：True = 完成；False = 失敗、拒絕或等超過 timeout 毫秒"""
        if self._a():
            return self._wd_a(timeout)
        t0 = _watch.time()
        while True:
            r, again = self._wd(self._m8(), t0, timeout)
            if r is not None:
                return r
            if again and self._pk:
                self._send_pk(self._pk)
            self._exp6.keep_alive_wait(20)

    async def _wd_a(self, timeout):
        t0 = _watch.time()
        while True:
            r, again = self._wd(await self._m8_a(), t0, timeout)
            if r is not None:
                return r
            if again and self._pk:
                await self._send_pk_a(self._pk)
            await self._exp6.keep_alive_wait(20)


def _grp_take(raw, port, gids, got):
    # 從一包上行串流取這孔的組資料（2026-11-03 組模式；Pybricks 主機沒有大整數，逐 byte 拆）
    #   R7／R8 高 16 bit：孔 1～3／4～6 的組編號各 5 bit；R7 bit15＝相位；R8 bit15、R7 bit31、R8 bit31＝輪次計數
    if raw is None or len(raw) < 32:
        return None
    o = 24 if port <= 3 else 28
    g = ((raw[o + 2] | (raw[o + 3] << 8)) >> (((port - 1) % 3) * 5)) & 0x1F
    if g == 0 or g not in gids:
        return None
    k = (port - 1) * 4
    d = bytes(raw[k:k + 4])
    if len(gids) == 1:
        return [d]
    got[g] = ((raw[29] >> 7) | ((raw[27] >> 7) << 1) | ((raw[31] >> 7) << 2), raw[25] >> 7, d)
    a = got.get(gids[0])
    b = got.get(gids[1])
    if a is not None and b is not None and a[0] == b[0] and a[1] == 0 and b[1] == 1:
        return [a[2], b[2]]
    return None

_IR_SETS = ((9, _f8(0, 1, 2, 3)), (9, _f8(4, 5, 6, 7)))

# 「讀一個值」的函式用查表產生（2026-11-03 瘦身：主機程式上限 52 KB，每個 def 都佔空間）。
#  名稱、參數、回傳值跟直插一樣；_S 表就是函式清單。
def _mk0(key):
    def f(self):
        return self._q(key)
    return f

def _mkch(key):
    def f(self, ch):
        _check_ch_range(ch, self._N)
        return self._q(key, ch)
    return f

def _mknm(d, what):
    def mk(key):
        def f(self, name):
            k = _pad_key(name)
            _name(d, k, what)
            return self._q(key, k)
        return f
    return mk

def _gen(cls, names, mk=_mk0):
    for n in names:
        setattr(cls, n, mk(n))

def _pad_key(name):
    # 直插用大寫名稱；EXP6 早期寫法是小寫（'cross'），一起收
    return str(name).strip().upper()

# ── MBC_EXP6 的 MBC 方法掛上去 ──
for _n in ('_mbc_warn', '_grp_plan', '_grp_fetch_sync', '_grp_fetch_async'):
    setattr(MBC_EXP6, _n, globals()[_n])


# ── 宣告式初始化：MBC_EXP6(3, False, p5=LINE16)、exp6.sensor(5) ──
class _EXP6_ID(_EXP6_SENSOR):
    _SETS = {'m8': _MODE8}

# 模式 8 產品碼（裝置 ID 字低 byte＝出廠位址、高 byte＝hw0）→ 名稱
_NAMES = {(0x16, 8): '循行者 8 路 / Line8', (0x16, 16): '循行者 16 路 / Line16', (0x29, 2): '測距者 2 路 / Laser2',
          (0x29, 8): '測距者 8 路 / Laser8', (0x42, 1): 'PS2 接收器 / PS2', (0x42, 2): 'PS4 接收器 / PS4',
          (0x4C, 3): '神攝手 / UniCam'}

def _declare(cls, exp6, port, *a):
    # 同步寫法：先用模式 8 產品碼核對（神攝手建立時會送命令，核對過才建立），最多等 3 秒（感應器剛通電要握手）
    if not exp6._async_mode and exp6.connected:
        probe = _EXP6_ID(exp6, port)
        t0 = _watch.time()
        d = None
        while d is None and _watch.time() - t0 < 3000:
            d = probe.device_id()
            if d is None:
                exp6.keep_alive_wait(100)
        want = _NAMES.get(cls._ID)
        if d is None:
            raise ValueError('[EXP6] %d 號孔讀不到「%s」（確認已插好）/ port %d: sensor not found'
                             % (port, want, port))
        if (d[0], d[1]) != cls._ID and cls._ID[0] == 0x42 and (d[0], d[1]) not in _NAMES:
            # 2026-10-21 以前出貨的 PS2／PS4 接收器：模式 8 是搖桿（中間＝05 05），沒有產品碼 → 照常用、提醒一次
            print('[EXP6] %d 號孔的接收器沒有產品碼（舊韌體），照常使用；connected()、battery()、命令要新韌體 / '
                  'port %d: old receiver firmware' % (port, port))
        elif (d[0], d[1]) != cls._ID:
            raise ValueError('[EXP6] %d 號孔要接「%s」，讀到的是「%s」/ port %d: wrong sensor'
                             % (port, want, _NAMES.get((d[0], d[1]), '%02X/%d' % (d[0], d[1])), port))
    return cls(exp6, port, *a)

def _kind(cls, pid):
    # 產品檔用：設定產品碼、可以宣告
    cls._ID = pid
    cls._declare = classmethod(_declare)
    return cls

def _sensor(self, port_num):
    """照宣告拿感應器物件：MBC_EXP6(..., p5=LINE16) 之後 exp6.sensor(5)（多工寫法也不用 await）"""
    s = self._decl.get(port_num)
    if s is None:
        raise ValueError('[EXP6] %s 號孔沒有宣告感應器，建立 MBC_EXP6 時寫 p%s=LINE16 這類 / port %s: no sensor declared'
                         % (port_num, port_num, port_num))
    return s         # 不用 await（多工寫法也一樣）：只是拿物件，跟 exp6.line8(5) 一樣

MBC_EXP6.sensor = _sensor
