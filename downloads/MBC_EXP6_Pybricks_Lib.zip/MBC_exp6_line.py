# MBC_exp6_line.py ── EXP6 六路馬達擴充器（Pybricks 4.x）：循行者 8／16 路
#  2026-11-03 從 MBC_exp6_obj_Lib.py 分出來：主機程式上限 52 KB（程式＋所有函式庫），用到哪款才載入哪款。
#  需要 EXP6 韌體 2026-11-03 以後（組模式＋命令轉送）。函式名稱、回傳值跟直插 SPIKE 主機一樣。
#  用法 / usage（LINE8、LINE16）：
#    from MBC_exp6_obj_Lib import MBC_EXP6
#    from MBC_exp6_line import *
#    exp6 = MBC_EXP6(3, False, p5=LINE16)    # 3＝EXP6 插主機 C 孔（1～6＝A～F，寫數字）；宣告接在幾號孔：開始時讀產品碼核對，插錯直接說
#    s = exp6.sensor(5)                       # 照宣告拿物件（多工寫法也不用 await）
#    s = exp6.line16(5)                           # 舊寫法也可以（不核對）
#    多工寫法（MBC_EXP6(3, True)）宣告時不核對；物件的每個函式都要 await。
from MBC_exp6_obj_Lib import (MBC_EXP6)
from MBC_exp6_mbc_common import (_EXP6_SENSOR, _IR_SETS, _MODE8, _gen, _hi, _jn, _kind, _lo, _mk0, _mkch, _popcount, _runs, _u)


# ── 循行者 8／16 路（對應 MBC_sensors.py 的 MBC_LINE8／MBC_LINE16）──
#  模式 9：b0~7 光值（8 路每路 1 byte 0~100；16 路每路 4 bit 0~15）、b8 粗位置+N、b9 線寬、
#          b10 細位置+100、b11 線段數、b12(~13) 黑白位元圖
#  主要組（每 10 ms，不用切換）：8 路＝細位置、粗位置、線寬、線段數、黑白；
#                              16 路＝細位置、粗位置、16 路黑白（線寬＝黑白有幾個 1、線段數＝幾段連續的 1，
#                              跟 16 路韌體 IR_getWidth(binRaw)、groupCount 的算法一樣）
#  光值（ir_ch／ir_calibration／edge_l／edge_r）：第 1～4 路＋第 5～8 路（16 路：1～8＋9～16）兩組輪流、同一筆資料
def _line(n):
    def ir(v):
        r = []
        for i in range(4):
            lo, hi = _lo(v[i]), _hi(v[i])
            r += [lo, hi] if n == 8 else [lo & 15, lo >> 4, hi & 15, hi >> 4]
        return r

    def bs(v):
        return _lo(v[6]) if n == 8 else _u(v[6])

    def on(b):
        return [i + 1 for i in range(n) if b & (1 << i)]

    return {
        'pos': ('main', lambda v: _lo(v[4]) - n),
        'width': ('main', lambda v: _hi(v[4])),
        'pos100': ('main', lambda v: _lo(v[5]) - 100),
        'junction': ('main', lambda v: _hi(v[5])),
        'junction_name': ('main', lambda v: _jn(_hi(v[5]))),
        'bin_raw': ('main', bs),
        'bitmap': ('main', bs),
        'on_sensors': ('main', lambda v: on(bs(v))),
        'ir_calibration': ('ir', ir),
        'ir_ch': ('ir', lambda v, c: ir(v)[c - 1]),
        'edge_l': ('ir', lambda v: ir(v)[0]),
        'edge_r': ('ir', lambda v: ir(v)[n - 1]),
    }

class _EXP6_LINE(_EXP6_SENSOR):
    _N = 8

# pos100 細位置 -100~+100、width 線寬（幾路在線上）、bin_raw／bitmap 黑白位元圖（第 1 路＝bit0）、
# on_sensors 在線上的是哪幾路、junction 線段數（0 沒線、1 一條、2 以上路口）、junction_name、
# ir_calibration 每路光值、edge_l／edge_r 最左／最右的光值、ir_ch(ch) 第 ch 路光值
_gen(_EXP6_LINE, ('pos100', 'width', 'bin_raw', 'bitmap', 'on_sensors', 'junction', 'junction_name',
                  'ir_calibration', 'edge_l', 'edge_r'))
_gen(_EXP6_LINE, ('ir_ch',), _mkch)


class EXP6_LINE8(_EXP6_LINE):
    """循行者 8 路：line8 = exp6.line8(port)"""
    _SETS = {'main': ((9, ((10, 8), (8, 5), (9, 4), (11, 3), (12, 8))),), 'ir': _IR_SETS, 'm8': _MODE8}
    _S = _line(8)
    pos8 = _mk0('pos')         # 粗位置 -8~+8（0 = 中間，負 = 線在左）

class EXP6_LINE16(_EXP6_LINE):
    """循行者 16 路：line16 = exp6.line16(port)"""
    _N = 16
    _SETS = {'main': ((9, ((10, 8), (8, 6), (12, 16))),), 'ir': _IR_SETS, 'm8': _MODE8}
    _S = _line(16)

    def _derive(self, mode, b):
        # 線寬、線段數沒送：照 16 路韌體的算法從黑白位元圖（binRaw）算
        if mode == 9:
            bm = b[12] | (b[13] << 8)
            b[9] = _popcount(bm)
            b[11] = _runs(bm, 16)

    pos16 = _mk0('pos')        # 粗位置 -16~+16


LINE8 = _kind(EXP6_LINE8, (0x16, 8))
LINE16 = _kind(EXP6_LINE16, (0x16, 16))
MBC_EXP6.line8 = lambda self, port_num: EXP6_LINE8(self, port_num)
MBC_EXP6.line16 = lambda self, port_num: EXP6_LINE16(self, port_num)
