# MBC_exp6_laser.py ── EXP6 六路馬達擴充器（Pybricks 4.x）：測距者 2／8 路
#  2026-11-03 從 MBC_exp6_obj_Lib.py 分出來：主機程式上限 52 KB（程式＋所有函式庫），用到哪款才載入哪款。
#  需要 EXP6 韌體 2026-11-03 以後（組模式＋命令轉送）。函式名稱、回傳值跟直插 SPIKE 主機一樣。
#  用法 / usage（LASER2、LASER8）：
#    from MBC_exp6_obj_Lib import MBC_EXP6
#    from MBC_exp6_laser import *
#    exp6 = MBC_EXP6(3, False, p5=LASER2)    # 3＝EXP6 插主機 C 孔（1～6＝A～F，寫數字）；宣告接在幾號孔：開始時讀產品碼核對，插錯直接說
#    s = exp6.sensor(5)                       # 照宣告拿物件（多工寫法也不用 await）
#    s = exp6.laser2(5)                           # 舊寫法也可以（不核對）
#    多工寫法（MBC_EXP6(3, True)）宣告時不核對；物件的每個函式都要 await。
from MBC_exp6_obj_Lib import (MBC_EXP6)
from MBC_exp6_mbc_common import (_EXP6_SENSOR, _IR_SETS, _MODE8, _bits, _f8, _gen, _hi, _kind, _lo, _mkch)


# ── 測距者共用 ──
def _side(a, b):
    return -1 if a < b else (1 if b < a else 0)

def _ok2(m, c):
    return (_lo(m) >> (c - 1)) & 1 == 1 and (_hi(m) >> (c - 1)) & 1 == 0

_MM_SETS = ((6, ((0, 16), (2, 16))), (6, ((4, 16),)))   # 模式 6 的 3 個 int16（2 組同一筆）


# ── 測距者 2 路（對應 MBC_sensors.py 的 MBC_LASER2）──
#  模式 9：b0 左 cm、b1 右 cm、b2 初始化位元、b3 故障位元（主要組，每 10 ms）
#  模式 6：[左 mm, 右 mm, 平均 mm]（呼叫 *_mm() 時感應器暫時切過去）
class EXP6_LASER2(_EXP6_SENSOR):
    """測距者 2 路：laser2 = exp6.laser2(port)。CH1 = 左、CH2 = 右"""
    _SETS = {'main': ((9, _f8(0, 1, 2, 3)),), 'mm': _MM_SETS, 'm8': _MODE8}

    _S = {
        'left': ('main', lambda v: _lo(v[0])),
        'right': ('main', lambda v: _hi(v[0])),
        'ch': ('main', lambda v, c: (_lo(v[0]), _hi(v[0]))[c - 1]),
        'average': ('main', lambda v: (_lo(v[0]) + _hi(v[0])) >> 1),
        'min_distance': ('main', lambda v: min(_lo(v[0]), _hi(v[0]))),
        'min_side': ('main', lambda v: _side(_lo(v[0]), _hi(v[0]))),
        'diff': ('main', lambda v: _lo(v[0]) - _hi(v[0])),
        'init_status': ('main', lambda v: _bits(_lo(v[1]), 2)),
        'fault_status': ('main', lambda v: _bits(_hi(v[1]), 2)),
        'is_ok': ('main', lambda v, c: _ok2(v[1], c)),
        'left_mm': ('mm', lambda v: int(v[0])),
        'right_mm': ('mm', lambda v: int(v[1])),
        'average_mm': ('mm', lambda v: int(v[2])),
    }
    _N = 2

# left／right 左右 cm（0~120，遠距離 0~200）、average、min_distance 比較近的、min_side（-1 左近、+1 右近）、
# diff 左減右、init_status／fault_status [左, 右]、*_mm 毫米、ch(ch)、is_ok(ch) 開機成功且沒故障
_gen(EXP6_LASER2, ('left', 'right', 'average', 'min_distance', 'min_side', 'diff', 'init_status', 'fault_status',
                   'left_mm', 'right_mm', 'average_mm'))
_gen(EXP6_LASER2, ('ch', 'is_ok'), _mkch)

# ── 測距者 8 路（對應 MBC_sensors.py 的 MBC_LASER8）──
#  模式 9：b0~7 八顆 cm、b8 最近方向+8、b9 最近 cm、b10 最空曠方向+8、b11 最空曠 cm、b12 初始化、b13 故障
#  主要組（每 10 ms）：b8~b11；8 顆距離：b0~3＋b4~7 兩組同一筆；狀態：b12~13；毫米：模式 6
def _d8(v):
    return [_lo(v[i // 2]) if i % 2 == 0 else _hi(v[i // 2]) for i in range(8)]

class EXP6_LASER8(_EXP6_SENSOR):
    """測距者 8 路：laser8 = exp6.laser8(port)"""
    _SETS = {'main': ((9, _f8(8, 9, 10, 11)),), 'dist': _IR_SETS, 'st': ((9, _f8(12, 13)),),
             'mm': _MM_SETS, 'm8': _MODE8}
    _S = {
        'distances': ('dist', _d8),
        'ch': ('dist', lambda v, c: _d8(v)[c - 1]),
        'min_direction': ('main', lambda v: _lo(v[4]) - 8),
        'min_distance': ('main', lambda v: _hi(v[4])),
        'max_direction': ('main', lambda v: _lo(v[5]) - 8),
        'max_distance': ('main', lambda v: _hi(v[5])),
        'init_status': ('st', lambda v: _bits(_lo(v[6]), 8)),
        'fault_status': ('st', lambda v: _bits(_hi(v[6]), 8)),
        'is_ok': ('st', lambda v, c: _ok2(v[6], c)),
        'nearest_mm': ('mm', lambda v: int(v[0])),
        'front_mm': ('mm', lambda v: int(v[1])),
        'nearest_dir': ('mm', lambda v: int(v[2])),
    }
    _N = 8

# distances 8 顆 cm、min_direction／min_distance 最近的方向 -8~+8／距離、max_direction／max_distance 最空曠的、
# init_status／fault_status [bool]*8、nearest_mm、front_mm（第 4、5 顆平均）、nearest_dir、ch(ch)、is_ok(ch)
_gen(EXP6_LASER8, ('distances', 'min_direction', 'min_distance', 'max_direction', 'max_distance', 'init_status',
                   'fault_status', 'nearest_mm', 'front_mm', 'nearest_dir'))
_gen(EXP6_LASER8, ('ch', 'is_ok'), _mkch)


LASER2 = _kind(EXP6_LASER2, (0x29, 2))
LASER8 = _kind(EXP6_LASER8, (0x29, 8))
MBC_EXP6.laser2 = lambda self, port_num: EXP6_LASER2(self, port_num)
MBC_EXP6.laser8 = lambda self, port_num: EXP6_LASER8(self, port_num)
