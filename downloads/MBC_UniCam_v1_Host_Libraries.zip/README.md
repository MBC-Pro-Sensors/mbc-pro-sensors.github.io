# 神攝手（韌體 v1）：上位機函式庫（正本）
# Sharpshooter Vision (firmware v1): host libraries (master copy)

v1.0，2026-10-28。**v1 尚未上機驗證**：數值排法已定案並通過電腦端測試，實機數值（fps、循線門檻、I2C 腳位）上機後可能調整。
v1.0, 2026-10-28. **v1 not yet hardware-verified**: the value layout is final and passed computer tests; real-hardware numbers may change.

依據 Source：`..\規格定案_通用版v1.md` 第 1～7 節、`..\tests\spec_layout.json`。不含任何韌體原始碼 / contains no firmware source.

## 模式編號 Mode number
相機模式 ×10 ＋ 子選項 / camera mode × 10 + option：11 12 13 14（顏色追蹤 tracking ①～④）、21 22 23（座標取色 spot ①～③）、30（照順序給色號 colour order）、41 42 43（循線 line 黑 black／白 white／色 colour）。
SPIKE 讀不到相機的模式，建構時要自己填；EV3 讀模式 0、I2C 讀 0x01 拿得到。座標一律像素 X 0~159、Y 0~119（上＝小），(0, 0)＝沒找到；色相碼 0~255；循線偏移線在左＝負。

## 資料夾 Folders

| 資料夾 | 內容 | 網站副本 |
|---|---|---|
| `pybricks\` | `MBC_UniCam.py`（SPIKE Pybricks v4：讀模式 9／6／8）＋ `examples\` 5 支 | `examples/unicam/pybricks/` |
| `ev3\` | `MBC_UniCam_EV3.py`（Pybricks v4 與 EV3 MicroPython v2：紅外線模式 0／1／2／5）＋ `examples\` 3 支 | `examples/unicam/ev3/` |
| `spike_app\` | `MBC_UniCam_App_helper.py`（官方 SPIKE App 3 教育版 Python，byte 0～7）＋ `examples\` 2 支 | `examples/unicam/spike_app/` |
| `arduino\` | `MBC_UniCam.h`（I2C 0x4C 小幫手，兩段 TOP／HELPERS 原封不動貼進每支範例） | `examples/unicam/arduino(-en)/`（範例正本在網站，`_build/sync-arduino-examples.mjs` 管） |
| `microbit\` | `MBC_UniCam_microbit.ts`（pins.i2c* 小幫手，不用擴充） | `examples/unicam/microbit/`（範例正本在網站） |
| `matrix\` | `MBC_UniCam_MATRIX.h`（mVision 10 格解碼） | `examples/unicam/matrix/`（範例正本在網站） |
| `tests\` | 驗證（不打包） | — |
| `tools\` | `gen_pages.py`＋`pages\`：產生網站 SPIKE／EV3 範例頁、複製 Python 副本（不打包） | — |

Arduino／micro:bit／MATRIX 的範例裡的小幫手段落必須跟這裡的正本逐字相同（標記行 `==== MBC_UNICAM_..._BEGIN/END ====`）。改正本後：重跑測試 → 把段落換進每支範例 → 網站跑 sync／編譯。

## 驗證 Tests（改了任何一個檔都要全跑）
```
py -3 -I -X utf8 tests\test_libs.py 330        # 隨機畫面 → oracle.py 打包 → 6 種解碼 → 比對真值（21546 項）
py -3 -I -X utf8 tests\mutation_test.py        # 17 處故意改錯，都要抓到
py -3 -I -X utf8 tests\run_examples.py         # Python 範例情境（33 項：方向、停車、讀不到）
py -3 -I -X utf8 tests\mp_vectors.py && node tests\run_mp.mjs   # MicroPython 1.29 跟 CPython 同結果＋mpy-cross
py -3 -I -X utf8 tools\gen_pages.py [--check]  # 網站副本與頁面
```

## 公開 API

### Pybricks（SPIKE）`MBC_UniCam.py`：`cam = UniCam(port, mode=13, multitask=False)`
| 方法 | 回傳 | 模式 |
|---|---|---|
| `xy(c)`／`x(c)`／`y(c)`／`found(c)` | (X, Y) 像素（11 是 16×12 格中心 ±5）／bool | 11～14（c：14／7／4／2 色） |
| `cell(c)` | 16×12 格 (1～16, 1～12) | 11 |
| `area(c)` | 面積 % | 13、14 |
| `size(c)` | (寬, 高) 像素 | 14 |
| `count(c)` | 塊數（11：0～7 讀模式 6；12：讀模式 6；13、14：0～15） | 11～14 |
| `colors_found()` | 16 色找到幾色（11、12 讀模式 6，上限 15） | 11、12、14 |
| `max_color()`／`max_point()` | 這個模式給幾色／幾點 | 1x／2x |
| `hue(i)` `sat(i)` `val(i)` `hsv(i)` `color(i)` | 色相碼 0～255、飽和、明度 0～100、名稱 | 21～23（i：14／7／4 點） |
| `order()`／`total()` | 左起色相碼（≤13）／總塊數 | 30 |
| `line_all()` | 14 值 (near, mid, far, angle, width, flags, junction, junction_dist, left, right, far_width, marker, marker_count, lost) | 41～43 |
| `near()` `mid()` `far()` `angle()` `width()` `flags()` `junction()` `junction_dist()` `edges()` `far_width()` `marker()` `lost()` | 單一值（edges、marker 是 tuple） | 41～43 |
| `device_id()`／`is_unicam()`／`firmware_version()` | 模式 8：(0x4C, 3, 100)／True／(1, 0) | 全部 |
| `sensor_ok()`／`mode_number()` | 最近有沒有讀到／建構時的 mode | 全部 |
| `color_name(h)`（模組函式） | `'red' 'orange' 'yellow' 'green' 'cyan' 'blue' 'purple' 'white' 'black'` | — |

模式不對、色號超出 → `ValueError`（中英訊息）。拔線回上一次的值，從沒讀到回 `None`。多工：每個方法 `await`。

### EV3 `MBC_UniCam_EV3.py`：`cam = UniCam(port, mode=None)`（None＝讀模式 0）
同名方法：`mode_number` `sensor_ok` `device_id`（模式 5）`is_unicam` `max_color` `xy` `x` `y` `found` `area`（13、14）`size` `count`（只有 14）`max_point` `hsv` `hue` `sat` `val` `color` `order`（≤11）`total` `near` `mid` `far` `angle` `width` `junction` `flags` `junction_dist`（以上模式 1）`edges` `far_width` `marker` `line_all`（要讀模式 2，＋0.5 s；line_all 13 值、沒有 lost）。EV3 專有 `grid(c)`＝原始 8×6 格（Y 下＝小）。
色數：11→12、12→8、13→4、14→2；點數：21→12、22→4、23→2。精度：位置／寬高 ±10 像素；21、30 色相 ±2；22 飽和、明度取到十位；23 原始值。

### SPIKE App 教育版 `UniCamApp(port, mode)`（貼在範例最上面）
`update()`、`cell(c)`（13／14：16×12 格色 1～4／1～2；11／12：8×6 格色 1～7）、`size_cell(c)`（14）、`colors_found()`（11、12）、`hue(i)`（21：1～6；22、23：1～3）、`sat(i)`（22：1～4；23：1～3）、`val(1)`（23）、`order()`→(前 6 塊, 總塊數)、`line()`→(near, far, angle, junction, width)；模組函式 `color_name(h)`。只用 byte 0～7（byte 8～15 待上機 #77）。

### Arduino `MBC_UniCam.h`（I2C 0x4C）
`mbcBegin()` `mbcReadMany(addr,id,k,out)` `mbcRead(addr,id)` `mbcWrite(addr,id,p,n)` `mbcWaitReady(addr,ms)`；
`ucSetMode(camMode, sub)`（E0）`ucSetPoint(n, x, y)`（E1）`ucModeNumber()`（0x01）`ucStride(mode)` `ucReadBlob(mode, c, UcBlob&)`（c 1～16；沒給的欄位 −1）`ucColorsFound(mode)` `ucReadSpot(mode, i, UcSpot&)`（i 1～16）`ucReadOrder(int16_t* hues, maxN, int16_t& total)`（≤16）`ucReadLine(UcLine&)`（14 值）`ucColorCode(h)`（1 紅 2 橙 3 黃 4 綠 5 青 6 藍 7 紫 8 白灰 9 黑）。
結構：`UcBlob {x, y, w, h, count, area}`、`UcSpot {h, s, v}`、`UcLine {nearOff, midOff, farOff, angle, width, flags, junction, junctionDist, leftEdge, rightEdge, farWidth, marker, markerCount, lost}`。

### micro:bit `MBC_UniCam_microbit.ts`
`ucReadMany(id, k)` `ucWrite(id, params)` `ucReady()` `ucSetMode(camMode, sub)` `ucSetPoint(n, x, y)` `ucModeNumber()` `ucStride(mode)` `ucReadBlob(mode, c)`→[x, y, w, h, count, area] `ucColorsFound(mode)` `ucReadSpot(mode, i)`→[h, s, v] `ucReadOrder()`→hues[] `ucOrderTotal()` `ucReadLine()`→14 值 `ucColorCode(h)`；常數 `UC_ADDR`、`UC_NONE`。

### MATRIX Mini R4 `MBC_UniCam_MATRIX.h`（mVision `CamData[10]`）
`ucLo(i)` `ucHi(i)` `ucByte(k)` `ucMaxColor(mode)`（16／10／5／3）`ucBlob(mode, c, UcBlob&)`（11 是 8×6 格中心 ±10）`ucColorsFound(mode)`（11、14）`ucMaxPoint(mode)`（20／10／6）`ucSpot(mode, i, UcSpot&)` `ucOrder(int* hues, maxN, int& total)`（≤18）`ucLine(UcLine&)`（14 值，＋100 已減回）`ucColorCode(h)`；全域 `CamData[10]`、`CamStatus`。

## 決定與限制
- 沒有併進 `85_共用資源\MBC_Pybricks\MBC_sensors.py`（v1 未上機、模式表跟其他產品差很多，併進去會讓每個產品的共用檔都變大）；上機確認後再照技能 `mbc-pybricks-shared-lib` 併入。
- SPIKE App 家用版 Python 沒做（只在網站列積木拆值表）。
- 尚待上機：I2C 腳位、E0 換模式後要等多久（小幫手等 50 ms）、EV3 MicroPython v2 的 Ev3devSensor 模式名稱、SPIKE App byte 8～15（#77）、所有範例的 KP／KD 與門檻。
