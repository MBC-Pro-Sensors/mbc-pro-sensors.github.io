# MBC EXP6 SPIKE App Library Installer（2026.11，需搭配 EXP6 韌體 2026-11-03 以後）
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式適用於 Lego Education SPIKE App 版本 3.4.3
# [EN] This program is designed for Lego Education SPIKE App version 3.4.3
#
# 請在 SPIKE App 中執行此程式，即可將函數庫安裝到主機內部的儲存空間中。

import sys

# 教育版 (SPIKE 3.x) 的全域儲存路徑固定為 /flash
filename = "/flash/MBC_exp6_SPIKE_App_Lib.py"
print("=========================================")
print("系統環境路徑 / sys.path:", sys.path)
print("開始安裝 / Installing " + filename + " ...")

source_code = """\
import device, distance_sensor, time
from hub import port
_instances = []
def _default_instance():
    if not _instances:
        raise RuntimeError("請先建立擴充板物件 (例: exp = MBC_EXP6(port.F)) / Create the board first, e.g. exp = MBC_EXP6(port.F)")
    return _instances[-1]
DEV_NONE = 0
DEV_FORCE = 1
DEV_COLOR = 3
DEV_ULTRASONIC = 4
DEV_MOTOR = 5
DIR_HOLD = 0
DIR_CW = 1
DIR_CCW = 2
DIR_COAST = 3
DIR_BRAKE = 4
STOP_COAST    = "coast"
STOP_BRAKE    = "brake"
STOP_HOLD     = "hold"
STOP_CONTINUE = "continue"
_STOP_L2         = {"coast": 3, "hold": 4, "brake": 5}
_STOP_COMPLETION = {"coast": 0, "brake": 1, "hold": 2, "continue": 3}
_STOP_INT        = {1: "coast", 2: "brake", 3: "hold", 4: "continue"}
_VALID_STOP_NAMES = ("coast", "brake", "hold", "continue")
def _norm_stop(stop):
    if isinstance(stop, bool):
        stop = int(stop)
    if isinstance(stop, int):
        if stop in _STOP_INT:
            return _STOP_INT[stop]
    else:
        s = str(stop).strip().lower()
        if s == "break":
            s = "brake"
        if s in ("1", "2", "3", "4"):
            return _STOP_INT[int(s)]
        if s in _VALID_STOP_NAMES:
            return s
    print("[EXP6] stop=%r 不符合定義範圍(1:coast, 2:brake, 3:hold, 4:continue)，"
          "已改用 brake 模式 / invalid stop value, using brake" % (stop,))
    return "brake"
def _stop_to_l2(stop):
    name = _norm_stop(stop)
    if name == "continue":
        return None
    return _STOP_L2[name]
def _stop_to_completion(stop):
    return _STOP_COMPLETION[_norm_stop(stop)]
MODE_SPEED = 0
MODE_ANGLE = 1
MODE_ABS_ANGLE = 2
MODE_RESET = 3
MODE_COLOR = 10
MODE_RGB = 11
MODE_HSV = 12
MODE_DISTANCE = 20
MODE_FORCE = 30
def _check_port(port_num, name="port"):
    if isinstance(port_num, bool) or not isinstance(port_num, int) or not (1 <= port_num <= 6):
        raise ValueError("%s=%r 不是有效孔位，必須是 1~6 的整數 / must be an integer 1~6" % (name, port_num))
def _check_distinct_ports(port_a, port_b):
    if port_a == port_b:
        raise ValueError(
            "left_port 與 right_port 不能是同一孔位(%r)，會被協議的 left*10+right 算式"
            "誤解成單馬達 PID 指令(port*11) / left_port and right_port must be different ports" % (port_a,))
_VALID_MODES = (MODE_SPEED, MODE_ANGLE, MODE_ABS_ANGLE, MODE_RESET,
                MODE_COLOR, MODE_RGB, MODE_HSV, MODE_DISTANCE, MODE_FORCE)
def _check_mode(mode):
    if mode not in _VALID_MODES:
        raise ValueError("mode=%r 不是合法的 MODE_* 常數 / is not a valid MODE_* constant" % (mode,))
def _clamp(v, lo, hi, name):
    v = int(v)
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v
def _clamp_warn(v, lo, hi, name):
    v = int(v)
    if v < lo or v > hi:
        c = lo if v < lo else hi
        print("[EXP6] %s=%d 超出範圍，已限制在 %d~%d 之間 / out of range, clamped" % (name, v, lo, hi))
        return c
    return v
def _cache_validated(build_fn):
    cache = [None, None]
    def wrapper(*args):
        if cache[0] == args:
            return cache[1]
        result = build_fn(*args)
        cache[0], cache[1] = args, result
        return result
    return wrapper
def _build_motor_run(port_num, speed):
    _check_port(port_num)
    speed = _clamp(speed, -100, 100, "speed")
    return (port_num * 11, DIR_CW if speed >= 0 else DIR_CCW, abs(speed), 0)
def _build_motor_power(port_num, power):
    _check_port(port_num)
    power = _clamp(power, -100, 100, "power")
    return (port_num * 10, DIR_CW if power >= 0 else DIR_CCW, abs(power), 0)
def _build_motor_stop(port_num, stop):
    _check_port(port_num)
    l2 = _stop_to_l2(stop)
    if l2 is None:
        return None
    return (port_num * 10, l2, 0, 0)
def _build_motor_set_pid(port_num, p, i, d):
    _check_port(port_num)
    p = _clamp(p, 0, 100, "p")
    i = _clamp(i, 0, 100, "i")
    d = _clamp(d, 0, 100, "d")
    return (80 + port_num, p, i, d)
def _build_motor_run_degrees(port_num, speed, degrees, stop):
    _check_port(port_num)
    speed = _clamp(speed, -100, 100, "speed")
    degrees = _clamp_warn(degrees, -2499, 2499, "degrees")
    deg = abs(int(degrees))
    op = 9 if (speed < 0) != (degrees < 0) else 8
    l3 = _stop_to_completion(stop) * 25 + deg // 100
    return (port_num * 10 + op, abs(int(speed)), l3, deg % 100)
def _build_motor_track_target(port_num, speed, angle, stop):
    _check_port(port_num)
    speed = _clamp(speed, -100, 100, "speed")
    t = int(angle) % 360
    l3 = _stop_to_completion(stop) * 4 + t // 100
    return (port_num * 10 + 7, abs(int(speed)), l3, t % 100)
def _build_set_inverted(port_num, inverted):
    _check_port(port_num)
    return (76, port_num, 1 if inverted else 0, 0)
def _build_drive(left_port, right_port, left_speed, right_speed):
    _check_port(left_port, "left_port")
    _check_port(right_port, "right_port")
    _check_distinct_ports(left_port, right_port)
    left_speed = _clamp(left_speed, -100, 100, "left_speed")
    right_speed = _clamp(right_speed, -100, 100, "right_speed")
    l2 = (0 if left_speed >= 0 else 2) | (0 if right_speed >= 0 else 1)
    return (left_port * 10 + right_port, l2, abs(left_speed), abs(right_speed))
def _build_drive_stop(left_port, right_port, stop):
    _check_port(left_port, "left_port")
    _check_port(right_port, "right_port")
    _check_distinct_ports(left_port, right_port)
    l2 = _stop_to_l2(stop)
    if l2 is None:
        return None
    return (left_port * 10 + right_port, l2, 0, 0)
_build_motor_run          = _cache_validated(_build_motor_run)
_build_motor_power        = _cache_validated(_build_motor_power)
_build_motor_stop         = _cache_validated(_build_motor_stop)
_build_motor_set_pid      = _cache_validated(_build_motor_set_pid)
_build_motor_run_degrees  = _cache_validated(_build_motor_run_degrees)
_build_motor_track_target = _cache_validated(_build_motor_track_target)
_build_set_inverted       = _cache_validated(_build_set_inverted)
_build_drive              = _cache_validated(_build_drive)
_build_drive_stop         = _cache_validated(_build_drive_stop)
_SENSOR_CUT_V = 9.0
class MBC_EXP6:
    DEV_NONE = DEV_NONE
    DEV_FORCE = DEV_FORCE
    DEV_COLOR = DEV_COLOR
    DEV_ULTRASONIC = DEV_ULTRASONIC
    DEV_MOTOR = DEV_MOTOR
    DIR_HOLD = DIR_HOLD
    DIR_CW = DIR_CW
    DIR_CCW = DIR_CCW
    DIR_COAST = DIR_COAST
    DIR_BRAKE = DIR_BRAKE
    STOP_COAST = STOP_COAST
    STOP_BRAKE = STOP_BRAKE
    STOP_HOLD = STOP_HOLD
    STOP_CONTINUE = STOP_CONTINUE
    MODE_SPEED = MODE_SPEED
    MODE_ANGLE = MODE_ANGLE
    MODE_ABS_ANGLE = MODE_ABS_ANGLE
    MODE_RESET = MODE_RESET
    MODE_COLOR = MODE_COLOR
    MODE_RGB = MODE_RGB
    MODE_HSV = MODE_HSV
    MODE_DISTANCE = MODE_DISTANCE
    MODE_FORCE = MODE_FORCE
    def __init__(self, port_num, multitask=False):
        self._port = port_num
        self.v = 0
        self.d = [0] * 6
        self._la = [0] * 6
        self._aa = [0] * 6
        self._port_mode_cache = {}
        self._mbc_win = {}
        self._mbc_warn_ms = {}
        self._batt_warned = False
        self._inverted = {i: False for i in range(1, 7)}
        self._last_send_time = time.ticks_ms()
        self._last_cmd = None
        self._throttle_ms = 20
        for _ in range(100):
            r = device.data(self._port)
            if r and len(r) >= 8 and r[6] != 0:
                break
            time.sleep(0.02)
        if r and len(r) >= 8 and r[6] != 0:
            self.v = (r[6] & 0xFFF) / 100.0
            self._check_battery()
        try:
            last_tick = time.ticks_ms()
            last_d = device.data(self._port)
            timed_out = False
            for _ in range(10):
                while True:
                    cur = device.data(self._port)
                    if cur != last_d:
                        break
                    if time.ticks_diff(time.ticks_ms(), last_tick) > 2000:
                        timed_out = True
                        break
                    time.sleep(0.001)
                if timed_out:
                    break
                last_d = cur
            if timed_out:
                print("[EXP6] 讀不到擴充板資料更新，改用預設通訊週期 25 ms（請確認 EXP6 接在這個孔且已開電）/ No data from EXP6, using the default 25 ms period (check the port and power)")
                self._throttle_ms = 25
            else:
                period = time.ticks_diff(time.ticks_ms(), last_tick) / 10
                self._throttle_ms = max(20, int(period * 2))
        except Exception:
            self._throttle_ms = 25
        self._send(0, 0, 0, 0)
        time.sleep(0.1)
        self.update()
        for i in range(1, 7):
            self.set_port_mode(i, self.MODE_ANGLE)
        time.sleep(0.05)
        self.update()
        for i in range(1, 7):
            self._la[i-1] = self.d[i-1]
            self._aa[i-1] = 0
        _instances.append(self)
    def update(self):
        r = device.data(self._port)
        if r and len(r) >= 8:
            new_d = []
            for x in r[:6]:
                val = x & 0xFFFF
                if val >= 32768:
                    val -= 65536
                new_d.append(val)
            for i in range(6):
                if self._port_mode_cache.get(i+1) == self.MODE_ANGLE:
                    c = new_d[i]
                    d = (c - self._la[i]) & 0xFFFF
                    if d > 32767:
                        d -= 65536
                    self._aa[i] += d
                    self._la[i] = c
            self.d = new_d
            self.v = (r[6] & 0xFFF) / 100.0
            self._check_battery()
        return self.d
    def _send(self, l1, l2, l3, l4):
        cmd = [max(0, min(100, int(x))) for x in (l1, l2, l3, l4)]
        if cmd == self._last_cmd:
            return
        now = time.ticks_ms()
        try:
            elapsed = time.ticks_diff(now, self._last_send_time)
        except AttributeError:
            self._last_send_time = now
            elapsed = self._throttle_ms
        if elapsed < self._throttle_ms:
            time.sleep((self._throttle_ms - elapsed) / 1000.0)
        distance_sensor.show(self._port, cmd)
        self._last_cmd = cmd
        self._last_send_time = time.ticks_ms()
    def _send_oneshot(self, l1, l2, l3, l4):
        self._send(l1, l2, l3, l4)
        time.sleep(self._throttle_ms * 2.5 / 1000.0)
        self._send(100, 0, 0, 0)
    def motor_run(self, port_num, speed):
        self._send(*_build_motor_run(port_num, speed))
    def motor_power(self, port_num, power):
        self._send(*_build_motor_power(port_num, power))
    def motor_stop(self, port_num, stop):
        pkt = _build_motor_stop(port_num, stop)
        if pkt is None:
            return
        self._send(*pkt)
    def motor_set_pid(self, port_num, p, i, d):
        self._send(*_build_motor_set_pid(port_num, p, i, d))
    def motor_run_degrees(self, port_num, speed, degrees, stop):
        self._send_oneshot(*_build_motor_run_degrees(port_num, speed, degrees, stop))
    def motor_track_target(self, port_num, speed, angle, stop):
        self._send_oneshot(*_build_motor_track_target(port_num, speed, angle, stop))
    motor_run_target = motor_track_target
    def set_motor_inverted(self, port_num, inverted=True):
        pkt = _build_set_inverted(port_num, bool(inverted))
        self._inverted[port_num] = bool(inverted)
        self._send(*pkt)
    def set_port_mode(self, port_num, mode):
        _check_port(port_num)
        _check_mode(mode)
        if mode == self.MODE_RESET:
            self._send(69 + port_num, mode, 0, 0)
            time.sleep(0.05)
            self._send(100, 0, 0, 0)
            self._port_mode_cache[port_num] = self.MODE_ANGLE
        else:
            self._send(69 + port_num, mode, 0, 0)
            self._port_mode_cache[port_num] = mode
            time.sleep(0.02)
    def drive(self, left_port, right_port, left_speed, right_speed):
        self._send(*_build_drive(left_port, right_port, left_speed, right_speed))
    def drive_stop(self, left_port, right_port, stop):
        pkt = _build_drive_stop(left_port, right_port, stop)
        if pkt is None:
            return
        self._send(*pkt)
    def stop_all(self, stop):
        l2 = _stop_to_l2(stop)
        if l2 is None:
            return
        for port_num in range(1, 7):
            self._send(port_num * 10, l2, 0, 0)
    def reset_angle(self, port_num):
        self.set_port_mode(port_num, self.MODE_RESET)
        self.set_port_mode(port_num, self.MODE_ANGLE)
        for _ in range(20):
            self.update()
            if abs(self.d[port_num - 1]) < 5:
                break
            time.sleep(0.02)
        self.update()
        self._la[port_num - 1] = self.d[port_num - 1]
        self._aa[port_num - 1] = 0
    def _ensure_mode(self, port_num, mode):
        if self._port_mode_cache.get(port_num) != mode:
            self.set_port_mode(port_num, mode)
            time.sleep(0.05)
    def get_port_raw(self, port_num):
        _check_port(port_num)
        self.update()
        return self.d[port_num - 1]
    def get_ultrasonic_distance(self, port_num):
        self._ensure_mode(port_num, self.MODE_DISTANCE)
        return self.get_port_raw(port_num)
    def get_touch_force(self, port_num):
        self._ensure_mode(port_num, self.MODE_FORCE)
        return self.get_port_raw(port_num)
    def get_motor_angle(self, port_num):
        _check_port(port_num)
        self._ensure_mode(port_num, self.MODE_ANGLE)
        self.update()
        return self._aa[port_num - 1]
    def get_motor_abs_angle(self, port_num):
        self._ensure_mode(port_num, self.MODE_ABS_ANGLE)
        return self.get_port_raw(port_num) % 360
    def get_motor_speed(self, port_num):
        self._ensure_mode(port_num, self.MODE_SPEED)
        return self.get_port_raw(port_num)
    def _get_rgb(self, port_num):
        self._ensure_mode(port_num, self.MODE_COLOR)
        val = self.get_port_raw(port_num)
        r = ((val >> 11) & 0x1F) * 100 // 31
        g = ((val >> 5) & 0x3F) * 100 // 63
        b = (val & 0x1F) * 100 // 31
        return (r, g, b)
    def get_color_color(self, port_num):
        h, s, v = self.get_color_hsv(port_num)
        if v < 15:
            return 0
        if s < 25:
            if v > 60:
                return 10
            else:
                return 0
        if h < 20 or h > 340:
            return 9
        elif 30 <= h <= 80:
            return 7
        elif 100 <= h <= 150:
            return 5
        elif 160 <= h <= 200:
            return 4
        elif 210 <= h <= 270:
            return 3
        elif 280 <= h <= 330:
            return 1
        return 0
    def get_color_reflection(self, port_num):
        r, g, b = self._get_rgb(port_num)
        return max(r, g, b)
    def get_color_rgb(self, port_num):
        return self._get_rgb(port_num)
    def get_color_hsv(self, port_num):
        r, g, b = self._get_rgb(port_num)
        cmax = max(r, g, b)
        cmin = min(r, g, b)
        delta = cmax - cmin
        h = 0
        if delta == 0: h = 0
        elif cmax == r: h = 60 * (((g - b) / delta) % 6)
        elif cmax == g: h = 60 * (((b - r) / delta) + 2)
        elif cmax == b: h = 60 * (((r - g) / delta) + 4)
        s = 0 if cmax == 0 else (delta / cmax) * 100
        v = cmax
        return (int(h), int(s), int(v))
    def get_color_hue(self, port_num): return self.get_color_hsv(port_num)[0]
    def get_color_sat(self, port_num): return self.get_color_hsv(port_num)[1]
    def get_color_val(self, port_num): return self.get_color_hsv(port_num)[2]
    def get_color_red(self, port_num): return self._get_rgb(port_num)[0]
    def get_color_green(self, port_num): return self._get_rgb(port_num)[1]
    def get_color_blue(self, port_num): return self._get_rgb(port_num)[2]
    def get_device_id(self, port_num):
        _check_port(port_num)
        r = device.data(self._port)
        if not r or len(r) < 8:
            return self.DEV_NONE
        if port_num == 1:
            return ((r[6] & 0xFFFF) >> 12) & 0x7
        return ((r[7] & 0xFFFF) >> ((port_num - 2) * 3)) & 0x7
    def line8(self, port_num):      return EXP6_LINE8(self, port_num)
    def line16(self, port_num):     return EXP6_LINE16(self, port_num)
    def laser2(self, port_num):     return EXP6_LASER2(self, port_num)
    def laser8(self, port_num):     return EXP6_LASER8(self, port_num)
    def ps2(self, port_num):        return EXP6_PS(self, port_num)
    def ps4(self, port_num):        return EXP6_PS(self, port_num)
    def unicam(self, port_num, mode=13): return EXP6_UNICAM(self, port_num, mode)
    def _mbc_id(self, r, port_num):
        if port_num == 1:
            return ((r[6] & 0xFFFF) >> 12) & 0x7
        return ((r[7] & 0xFFFF) >> ((port_num - 2) * 3)) & 0x7
    def _mbc_read(self, port_num, mode, ofs):
        _mbc_check_port(port_num)
        r = self._mbc_frame()
        if (r is None or self._mbc_id(r, port_num) != _DEV_MBC
                or self._mbc_win.get(port_num) != (mode, ofs)):
            self._last_cmd = None
            self._send(69 + port_num, _FMT_MBC_WINDOW, mode, ofs)
            self._port_mode_cache[port_num] = _FMT_MBC_WINDOW
            self._mbc_win[port_num] = (mode, ofs)
            t0 = time.ticks_ms()
            time.sleep(self._throttle_ms * 2 / 1000.0)
            while True:
                r = self._mbc_frame()
                if r is not None and self._mbc_id(r, port_num) == _DEV_MBC:
                    break
                if time.ticks_diff(time.ticks_ms(), t0) > _MBC_TIMEOUT_MS:
                    self._mbc_win.pop(port_num, None)
                    self._mbc_warn(port_num)
                    return None
                time.sleep(0.01)
        v = r[port_num - 1] & 0xFFFF
        return v & 0xFF, v >> 8
    def _mbc_warn(self, port_num):
        now = time.ticks_ms()
        last = self._mbc_warn_ms.get(port_num)
        if last is None or time.ticks_diff(now, last) >= _MBC_WARN_MS:
            print("[EXP6] 孔{n} 讀不到 MBC 感應器（確認已插好）/ No MBC sensor on EXP6 port {n} (check the cable)".format(n=port_num))
            self._mbc_warn_ms[port_num] = now
    def _mbc_frame(self):
        r = device.data(self._port)
        return r if (r and len(r) >= 8) else None
    def _check_battery(self):
        if self._batt_warned or self.v <= _SENSOR_CUT_V:
            return
        self._batt_warned = True
        print("[EXP6] 電池電壓 %.1f V 超過 2S 鋰電池的安全電壓（%.0f V）：已停止對樂高顏色／超音波感應器供電，保護感應器（馬達照常）。請改用 2S 鋰電池（7.4 V）。/ Battery %.1f V is above the 2S Li-ion safe voltage (%.0f V): power to LEGO color/ultrasonic sensors is cut to protect them (motors still work). Please use a 2S Li-ion battery (7.4 V)." % (self.v, _SENSOR_CUT_V, self.v, _SENSOR_CUT_V))
    def get_voltage(self):
        self.update()
        return self.v
    def keep_alive(self):
        pass
    def keep_alive_wait(self, ms):
        time.sleep(ms / 1000.0)
_DEV_MBC        = 6
_FMT_MBC_WINDOW = 100
_MBC_TIMEOUT_MS = 400
_MBC_WARN_MS    = 2000
def _mbc_check_port(port_num):
    if isinstance(port_num, bool) or not isinstance(port_num, int) or not (1 <= port_num <= 6):
        raise ValueError("port=%r 不是有效孔位，必須是 1~6 的整數 / must be an integer 1~6" % (port_num,))
def _s8(b):
    return b - 256 if b >= 128 else b
def _check_ch_range(ch, n):
    if isinstance(ch, bool) or not isinstance(ch, int) or not (1 <= ch <= n):
        raise ValueError("ch must be 1~{}, got {}".format(n, ch))
_JUNCTION_NAMES = {0: "none", 1: "line", 2: "junction"}
class _EXP6_SENSOR:
    _MODE = 9
    def __init__(self, exp, port_num):
        _mbc_check_port(port_num)
        self._exp = exp
        self._port = port_num
        self._sq = None
        self._unsent = False
        self._ck = None
        self._pk = None
        self._ct = 0
    def _get(self, ofs, fn):
        b = self._exp._mbc_read(self._port, self._MODE, ofs)
        return None if b is None else fn(b[0], b[1])
    def _cmd_pkts(self, code, p, seq):
        L1 = 90 + self._port
        out = [(L1, 0, 0, code - 0xE0)]
        for i, x in enumerate(p):
            x = int(x)
            ax = -x if x < 0 else x
            out.append((L1, i + 1 + (10 if x < 0 else 0), ax // 100, ax % 100))
        out.append((97, self._port, seq, 0))
        return out
    def _st(self):
        return self._exp._mbc_read(self._port, 8, 6)
    def _send_pk(self, pk):
        for x in pk:
            self._exp._last_cmd = None
            self._exp._send(*x)
        self._exp._mbc_win.pop(self._port, None)
    def cmd(self, code, *p, again=False):
        if isinstance(code, bool) or not isinstance(code, int) or not 0xE0 <= code <= 0xEE:
            raise ValueError('cmd(): 命令碼要 0xE0~0xEE / code must be 0xE0~0xEE')
        if len(p) > 5:
            raise ValueError('cmd(): 參數最多 5 個 / at most 5 parameters')
        for x in p:
            if not -9999 <= int(x) <= 9999:
                raise ValueError('cmd(): EXP6 參數要 -9999~9999 / parameters must be -9999~9999')
        k = (code,) + tuple(int(x) for x in p)
        if k == self._ck and not again:
            return self._sq
        if self._sq is None:
            f = self._exp._mbc_read(self._port, 8, 2)
            if f is None:
                self._unsent = True
                return None
            if not (f[1] & 1):
                raise ValueError('cmd(): 感應器韌體太舊，不支援命令，請更新韌體 / sensor firmware too old for commands')
            s = self._st()
            if s is None:
                self._unsent = True
                return None
            self._sq = s[1]
        self._sq = self._sq % 99 + 1
        self._ck = k
        self._pk = self._cmd_pkts(code, p, self._sq)
        self._ct = time.ticks_ms()
        self._send_pk(self._pk)
        return self._sq
    def cmd_state(self):
        s = self._st()
        if s is None or self._sq is None or s[1] != self._sq:
            return None
        return s[0]
    def busy(self):
        if self._sq is None:
            return False
        s = self.cmd_state()
        return s is None or s == 1
    def wait_done(self, timeout=10000):
        if self._sq is None:
            return not self._unsent
        t0 = time.ticks_ms()
        while True:
            s = self.cmd_state()
            if s is not None and s != 1:
                return s == 0
            if time.ticks_diff(time.ticks_ms(), t0) >= timeout:
                return False
            if s is None and time.ticks_diff(time.ticks_ms(), self._ct) >= 300 and self._pk:
                self._ct = time.ticks_ms()
                self._send_pk(self._pk)
            self._exp.keep_alive_wait(20)
class EXP6_LINE8(_EXP6_SENSOR):
    def pos8(self):          return self._get(8,  lambda lo, hi: lo - 8)
    def width(self):         return self._get(8,  lambda lo, hi: hi)
    def pos100(self):        return self._get(10, lambda lo, hi: lo - 100)
    def junction(self):      return self._get(10, lambda lo, hi: hi)
    def junction_name(self): return self._get(10, lambda lo, hi: _JUNCTION_NAMES.get(min(hi, 2), "junction"))
    def bin_raw(self):       return self._get(12, lambda lo, hi: lo)
    def on_sensors(self):
        return self._get(12, lambda lo, hi: [i + 1 for i in range(8) if lo & (1 << i)])
    def ir_ch(self, ch):
        _check_ch_range(ch, 8)
        idx = ch - 1
        return self._get(idx & ~1, lambda lo, hi: hi if idx & 1 else lo)
class EXP6_LINE16(_EXP6_SENSOR):
    def pos16(self):         return self._get(8,  lambda lo, hi: lo - 16)
    def width(self):         return self._get(8,  lambda lo, hi: hi)
    def pos100(self):        return self._get(10, lambda lo, hi: lo - 100)
    def junction(self):      return self._get(10, lambda lo, hi: hi)
    def junction_name(self): return self._get(10, lambda lo, hi: _JUNCTION_NAMES.get(min(hi, 2), "junction"))
    def bin_raw(self):       return self._get(12, lambda lo, hi: lo | (hi << 8))
    def on_sensors(self):
        return self._get(12, lambda lo, hi: [i + 1 for i in range(16) if (lo | (hi << 8)) & (1 << i)])
    def ir_ch(self, ch):
        _check_ch_range(ch, 16)
        idx = ch - 1
        byte_i = idx >> 1
        shift = 4 if idx & 1 else 0
        return self._get(byte_i & ~1, lambda lo, hi: ((hi if byte_i & 1 else lo) >> shift) & 0x0F)
class EXP6_LASER2(_EXP6_SENSOR):
    def left(self):         return self._get(0, lambda lo, hi: lo)
    def right(self):        return self._get(0, lambda lo, hi: hi)
    def average(self):      return self._get(0, lambda lo, hi: (lo + hi) >> 1)
    def min_distance(self): return self._get(0, lambda lo, hi: min(lo, hi))
    def min_side(self):     return self._get(0, lambda lo, hi: -1 if lo < hi else (1 if hi < lo else 0))
    def diff(self):         return self._get(0, lambda lo, hi: lo - hi)
    def ch(self, ch):
        _check_ch_range(ch, 2)
        return self._get(0, lambda lo, hi: hi if ch == 2 else lo)
    def is_ok(self, ch):
        _check_ch_range(ch, 2)
        bit = 1 << (ch - 1)
        return self._get(2, lambda lo, hi: (lo & bit) != 0 and (hi & bit) == 0)
class EXP6_LASER8(_EXP6_SENSOR):
    def ch(self, ch):
        _check_ch_range(ch, 8)
        idx = ch - 1
        return self._get(idx & ~1, lambda lo, hi: hi if idx & 1 else lo)
    def min_direction(self): return self._get(8,  lambda lo, hi: lo - 8)
    def min_distance(self):  return self._get(8,  lambda lo, hi: hi)
    def max_direction(self): return self._get(10, lambda lo, hi: lo - 8)
    def max_distance(self):  return self._get(10, lambda lo, hi: hi)
    def init_status(self):   return self._get(12, lambda lo, hi: [(lo & (1 << i)) != 0 for i in range(8)])
    def fault_status(self):  return self._get(12, lambda lo, hi: [(hi & (1 << i)) != 0 for i in range(8)])
    def is_ok(self, ch):
        _check_ch_range(ch, 8)
        bit = 1 << (ch - 1)
        return self._get(12, lambda lo, hi: (lo & bit) != 0 and (hi & bit) == 0)
_PS_BUTTONS = {
    "square": 15, "cross": 14, "circle": 13, "triangle": 12,
    "r1": 11, "l1": 10, "r2": 9, "l2": 8,
    "left": 7, "down": 6, "right": 5, "up": 4,
    "start": 3, "r3": 2, "l3": 1, "select": 0,
}
def _ps_word(lo, hi):
    return ((hi >> 4) << 12) | ((lo & 0x0F) << 8) | ((hi & 0x0F) << 4) | (lo >> 4)
class EXP6_PS(_EXP6_SENSOR):
    _MODE = 0
    def buttons(self): return self._get(0, _ps_word)
    def pressed(self, name):
        key = str(name).strip().lower()
        if key not in _PS_BUTTONS:
            raise ValueError("unknown button {!r}, use one of {}".format(name, sorted(_PS_BUTTONS)))
        bit = 1 << _PS_BUTTONS[key]
        return self._get(0, lambda lo, hi: (_ps_word(lo, hi) & bit) != 0)
    def pressed_buttons(self):
        return self._get(0, lambda lo, hi: [k for k, b in _PS_BUTTONS.items() if _ps_word(lo, hi) & (1 << b)])
    def lx(self): return self._get(2, lambda lo, hi: (lo | (hi << 8)) // 10)
    def ly(self): return self._get(2, lambda lo, hi: (lo | (hi << 8)) % 10)
    def rx(self): return self._get(4, lambda lo, hi: (lo | (hi << 8)) // 10)
    def ry(self): return self._get(4, lambda lo, hi: (lo | (hi << 8)) % 10)
_UC_MODES = (11, 12, 13, 14, 21, 22, 23, 30, 41, 42, 43, 51, 52)
_UC_NCOL = {11: 14, 12: 7, 13: 4, 14: 2}
_UC_NPT = {21: 14, 22: 7, 23: 4}
_UC_NOBJ = {51: 4, 52: 2}
_UC_LINE = (41, 42, 43)
SHAPES = ('other', 'circle', 'ellipse', 'triangle', 'square', 'rectangle', 'pentagon', 'hexagon', 'star', 'trapezoid')
SHAPES_ZH = ('其他', '圓', '橢圓', '三角', '正方', '長方', '五邊', '六邊', '星', '梯形')
def color_name(h):
    if h is None:
        return None
    if h > 248:
        return 'black'
    if h > 240:
        return 'white'
    if h < 12 or h >= 220:
        return 'red'
    if h < 28:
        return 'orange'
    if h < 56:
        return 'yellow'
    if h < 100:
        return 'green'
    if h < 140:
        return 'cyan'
    if h < 180:
        return 'blue'
    return 'purple'
def shape_name(s, zh=False):
    if s is None or not 0 <= s <= 9:
        return None
    return SHAPES_ZH[s] if zh else SHAPES[s]
def _uc_windows(idxs):
    ks = []
    for i in sorted(set(idxs)):
        if not ks or i > ks[-1] + 1:
            ks.append(i)
    return ks
def _uc_xy_idx(m, c):
    if m == 11:
        return (c - 1,)
    k = {12: 2, 13: 3, 14: 6}[m] * (c - 1)
    return (k, k + 1)
def _uc_xy(b, m, c):
    if m == 11:
        g = b[c - 1]
        if not g:
            return (0, 0)
        return (((g - 1) % 16) * 10 + 5, ((g - 1) // 16) * 10 + 5)
    k = {12: 2, 13: 3, 14: 6}[m] * (c - 1)
    return (b[k], b[k + 1])
def _uc_count6_idx(m, c):
    if m == 11:
        bit = 42 if c == 0 else 3 * (c - 1)
        return (bit // 8, (bit + 3) // 8) if c == 0 else (bit // 8, (bit + 2) // 8)
    return (3,) if c == 0 else ((c - 1) // 2,)
def _uc_count6(b, m, c):
    if m == 11:
        bits = 0
        for i in range(6):
            bits |= b[i] << (8 * i)
        return (bits >> (3 * (c - 1))) & 7 if c else (bits >> 42) & 15
    if c == 0:
        return b[3] & 15
    x = b[(c - 1) // 2]
    return x >> 4 if c % 2 else x & 15
def _uc_hsv_idx(m, i):
    if m == 21:
        return (i - 1,)
    if m == 22:
        return (2 * i - 2, 2 * i - 1)
    return (3 * i - 3, 3 * i - 2, 3 * i - 1)
def _uc_hsv(b, m, i):
    if m == 21:
        return (b[i - 1], None, None)
    if m == 22:
        return (b[2 * i - 2], b[2 * i - 1], None)
    return (b[3 * i - 3], b[3 * i - 2], b[3 * i - 1])
def _uc_ob_code(b, m, k):
    if m == 51:
        return b[k]
    return b[k] * 10 + b[k + 1] if b[k] else 0
class EXP6_UNICAM(_EXP6_SENSOR):
    def __init__(self, exp, port_num, mode=13):
        if mode not in _UC_MODES:
            raise ValueError('mode 要填 %s / mode must be one of %s' % (_UC_MODES, _UC_MODES))
        _EXP6_SENSOR.__init__(self, exp, port_num)
        self._m = mode
    def _uc(self, smode, idxs, fn):
        b = [0] * 16
        for k in _uc_windows(idxs):
            r = self._exp._mbc_read(self._port, smode, k)
            if r is None:
                return None
            b[k], b[k + 1] = r
        return fn(b)
    def _need(self, name, ok):
        if self._m not in ok:
            raise ValueError('%s(): 模式 %d 沒有這個值，要用模式 %s / not available in mode %d, use mode %s'
                             % (name, self._m, ok, self._m, ok))
    def _col(self, c, n):
        if not 1 <= c <= n:
            raise ValueError('第幾色／第幾點要填 1~%d / colour or spot must be 1~%d' % (n, n))
    def _obj(self, name, i, ok=(51, 52)):
        self._need(name, ok)
        n = _UC_NOBJ[self._m]
        if not 1 <= i <= n:
            raise ValueError('第幾個物體要填 1~%d / object must be 1~%d' % (n, n))
        return 3 * i - 2 if self._m == 51 else 7 * (i - 1)
    def mode_number(self):
        return self._m
    def sensor_ok(self):
        return self._uc(9, (0,), lambda b: True) is not None
    def device_id(self):
        return self._uc(8, (0, 1, 4, 5), lambda b: (b[0], b[1], b[4] | (b[5] << 8)))
    def is_unicam(self):
        return self._uc(8, (0, 1), lambda b: (b[0] | (b[1] << 8)) == 0x034C)
    def firmware_version(self):
        return self._uc(8, (4, 5), lambda b: ((b[4] | (b[5] << 8)) // 100, (b[4] | (b[5] << 8)) % 100))
    def max_color(self):
        self._need('max_color', (11, 12, 13, 14))
        return _UC_NCOL[self._m]
    def _cxy(self, name, color, j):
        self._need(name, (11, 12, 13, 14))
        self._col(color, _UC_NCOL[self._m])
        m = self._m
        return self._uc(9, _uc_xy_idx(m, color), lambda b: j(_uc_xy(b, m, color)))
    def xy(self, color):
        return self._cxy('xy', color, lambda p: p)
    def x(self, color):
        return self._cxy('x', color, lambda p: p[0])
    def y(self, color):
        return self._cxy('y', color, lambda p: p[1])
    def found(self, color):
        return self._cxy('found', color, lambda p: p[0] > 0)
    def cell(self, color):
        self._need('cell', (11,))
        self._col(color, 14)
        i = color - 1
        return self._uc(9, (i,), lambda b: (0, 0) if not b[i] else ((b[i] - 1) % 16 + 1, (b[i] - 1) // 16 + 1))
    def area(self, color):
        self._need('area', (13, 14))
        self._col(color, _UC_NCOL[self._m])
        i = 3 * color - 1 if self._m == 13 else 6 * color - 1
        return self._uc(9, (i,), lambda b: b[i])
    def size(self, color):
        self._need('size', (14,))
        self._col(color, 2)
        i = 6 * color - 4
        return self._uc(9, (i, i + 1), lambda b: (b[i], b[i + 1]))
    def count(self, color):
        self._need('count', (11, 12, 13, 14))
        self._col(color, _UC_NCOL[self._m])
        m = self._m
        if m in (11, 12):
            return self._uc(6, _uc_count6_idx(m, color), lambda b: _uc_count6(b, m, color))
        if m == 13:
            i = 12 + (color - 1) // 2
            return self._uc(9, (i,), lambda b: b[i] >> 4 if color % 2 else b[i] & 15)
        i = 6 * color - 2
        return self._uc(9, (i,), lambda b: b[i])
    def colors_found(self):
        self._need('colors_found', (11, 12, 14))
        m = self._m
        if m == 14:
            return self._uc(9, (12,), lambda b: b[12])
        return self._uc(6, _uc_count6_idx(m, 0), lambda b: _uc_count6(b, m, 0))
    def max_point(self):
        self._need('max_point', (21, 22, 23))
        return _UC_NPT[self._m]
    def _pt(self, name, ok, point, sel, j):
        self._need(name, ok)
        self._col(point, _UC_NPT[self._m])
        m = self._m
        return self._uc(9, sel(_uc_hsv_idx(m, point)), lambda b: j(_uc_hsv(b, m, point)))
    def hue(self, point):
        return self._pt('hue', (21, 22, 23), point, lambda t: t[:1], lambda h: h[0])
    def sat(self, point):
        return self._pt('sat', (22, 23), point, lambda t: t[1:2], lambda h: h[1])
    def val(self, point):
        return self._pt('val', (23,), point, lambda t: t[2:3], lambda h: h[2])
    def hsv(self, point):
        return self._pt('hsv', (21, 22, 23), point, lambda t: t, lambda h: h)
    def color(self, point):
        return self._pt('color', (21, 22, 23), point, lambda t: t[:1], lambda h: color_name(h[0]))
    def order(self):
        self._need('order', (30,))
        return self._uc(9, range(14), lambda b: b[:min(13, b[13])])
    def total(self):
        self._need('total', (30,))
        return self._uc(9, (13,), lambda b: b[13])
    def _li(self, name, i, signed=False):
        self._need(name, _UC_LINE)
        return self._uc(9, (i,), lambda b: _s8(b[i]) if signed else b[i])
    def near(self):
        return self._li('near', 0, True)
    def mid(self):
        return self._li('mid', 1, True)
    def far(self):
        return self._li('far', 2, True)
    def angle(self):
        return self._li('angle', 3, True)
    def width(self):
        return self._li('width', 4)
    def flags(self):
        return self._li('flags', 5)
    def junction(self):
        return self._li('junction', 6)
    def junction_dist(self):
        return self._li('junction_dist', 7)
    def edges(self):
        self._need('edges', _UC_LINE)
        return self._uc(9, (8, 9), lambda b: (_s8(b[8]), _s8(b[9])))
    def far_width(self):
        return self._li('far_width', 10)
    def marker(self):
        self._need('marker', _UC_LINE)
        return self._uc(9, (11, 12), lambda b: (b[11], b[12]))
    def lost(self):
        return self._li('lost', 13)
    def max_object(self):
        self._need('max_object', (51, 52))
        return _UC_NOBJ[self._m]
    def object_count(self):
        self._need('object_count', (51,))
        return self._uc(9, (0,), lambda b: b[0])
    def _code(self, name, i, j):
        k = self._obj(name, i)
        m = self._m
        return self._uc(9, (k,) if m == 51 else (k, k + 1), lambda b: j(_uc_ob_code(b, m, k)))
    def object(self, i):
        return self._code('object', i, lambda c: c)
    def object_found(self, i):
        return self._code('object_found', i, lambda c: c > 0)
    def object_color(self, i):
        return self._code('object_color', i, lambda c: c // 10)
    def object_shape(self, i):
        return self._code('object_shape', i, lambda c: c % 10)
    def object_xy(self, i):
        k = self._obj('object_xy', i) + (1 if self._m == 51 else 2)
        return self._uc(9, (k, k + 1), lambda b: (b[k], b[k + 1]))
    def object_size(self, i):
        k = self._obj('object_size', i, (52,)) + 4
        return self._uc(9, (k, k + 1), lambda b: (b[k], b[k + 1]))
    def object_area(self, i):
        k = self._obj('object_area', i, (52,)) + 6
        return self._uc(9, (k,), lambda b: b[k])
def exp_motor_run(*a):         return _default_instance().motor_run(*a)
def exp_motor_power(*a):       return _default_instance().motor_power(*a)
def exp_motor_stop(*a):         return _default_instance().motor_stop(*a)
def exp_motor_set_pid(*a):      return _default_instance().motor_set_pid(*a)
def exp_motor_run_degrees(*a):  return _default_instance().motor_run_degrees(*a)
def exp_motor_track_target(*a): return _default_instance().motor_track_target(*a)
def exp_motor_run_target(*a):   return _default_instance().motor_run_target(*a)
def exp_set_motor_inverted(*a): return _default_instance().set_motor_inverted(*a)
def exp_set_port_mode(*a):     return _default_instance().set_port_mode(*a)
def exp_drive(*a):             return _default_instance().drive(*a)
def exp_drive_stop(*a):        return _default_instance().drive_stop(*a)
def exp_stop_all(*a):          return _default_instance().stop_all(*a)
def exp_reset_angle(*a):       return _default_instance().reset_angle(*a)
def exp_get_port_raw(*a):            return _default_instance().get_port_raw(*a)
def exp_get_ultrasonic_distance(*a): return _default_instance().get_ultrasonic_distance(*a)
def exp_get_touch_force(*a):         return _default_instance().get_touch_force(*a)
def exp_get_motor_angle(*a):     return _default_instance().get_motor_angle(*a)
def exp_get_motor_abs_angle(*a): return _default_instance().get_motor_abs_angle(*a)
def exp_get_motor_speed(*a):     return _default_instance().get_motor_speed(*a)
def exp_get_color_color(*a):      return _default_instance().get_color_color(*a)
def exp_get_color_reflection(*a): return _default_instance().get_color_reflection(*a)
def exp_get_color_rgb(*a):        return _default_instance().get_color_rgb(*a)
def exp_get_color_hsv(*a):        return _default_instance().get_color_hsv(*a)
def exp_get_color_hue(*a):        return _default_instance().get_color_hue(*a)
def exp_get_color_sat(*a):        return _default_instance().get_color_sat(*a)
def exp_get_color_val(*a):        return _default_instance().get_color_val(*a)
def exp_get_color_red(*a):        return _default_instance().get_color_red(*a)
def exp_get_color_green(*a):      return _default_instance().get_color_green(*a)
def exp_get_color_blue(*a):       return _default_instance().get_color_blue(*a)
def exp_get_device_id(*a): return _default_instance().get_device_id(*a)
def exp_get_voltage():     return _default_instance().get_voltage()
def exp_run_task(coro):
    raise NotImplementedError("SPIKE App 版本不支援 async 任務。/ async tasks are not supported in the SPIKE App version.")
def run_task(coro):
    raise NotImplementedError("SPIKE App 版本不支援 async 任務。/ async tasks are not supported in the SPIKE App version.")
def keep_alive():
    pass
def keep_alive_wait(ms):
    time.sleep(ms / 1000.0)
__all__ = [
    "exp_run_task",
    "run_task", "keep_alive", "keep_alive_wait",
    "DEV_NONE", "DEV_FORCE", "DEV_COLOR", "DEV_ULTRASONIC", "DEV_MOTOR",
    "DIR_HOLD", "DIR_CW", "DIR_CCW", "DIR_COAST", "DIR_BRAKE",
    "STOP_COAST", "STOP_BRAKE", "STOP_HOLD", "STOP_CONTINUE",
    "MODE_SPEED", "MODE_ANGLE", "MODE_ABS_ANGLE", "MODE_RESET",
    "MODE_COLOR", "MODE_RGB", "MODE_HSV", "MODE_DISTANCE", "MODE_FORCE",
    "exp_motor_run", "exp_motor_power",
    "exp_motor_stop",
    "exp_motor_set_pid",
    "exp_motor_run_degrees", "exp_motor_track_target", "exp_motor_run_target",
    "exp_set_motor_inverted",
    "exp_drive", "exp_drive_stop",
    "exp_stop_all", "exp_reset_angle",
    "exp_get_port_raw",
    "exp_get_motor_angle", "exp_get_motor_abs_angle", "exp_get_motor_speed",
    "exp_get_ultrasonic_distance",
    "exp_get_touch_force",
    "exp_get_color_color", "exp_get_color_reflection",
    "exp_get_color_rgb",   "exp_get_color_hsv",
    "exp_get_color_hue",   "exp_get_color_sat",   "exp_get_color_val",
    "exp_get_color_red",   "exp_get_color_green", "exp_get_color_blue",
    "exp_get_device_id",
    "exp_get_voltage",
    "exp_set_port_mode",
    "MBC_EXP6",
]
"""

try:
    with open(filename, "w") as f:
        f.write(source_code)
    print("安裝成功！(Installation Successful!)")
    print("您現在可以在任何新專案中匯入此庫 / You can now import it in any new project:")
    print("from MBC_exp6_SPIKE_App_Lib import MBC_EXP6")
except Exception as e:
    print("安裝失敗 (Installation Failed):", repr(e))
print("=========================================")

# ==============================================================================
# 🌟 物件導向可使用的函數列表 (Available Methods for MBC_EXP6 Object)
# ==============================================================================
#
# 假設您建立的物件為 exp = MBC_EXP6(port)
# 以下函數皆透過該物件呼叫，例如：exp.motor_run(1, 50)
#
# [馬達控制 Motor Control]
# motor_run(port, speed)                          : 以速度模式持續轉動 (-100~100)
# motor_power(port, power)                        : 直接輸出 PWM 力量 (-100~100)
# motor_stop(port, stop)                          : 停止馬達，stop 必填(見下方 stop 參數說明)
# motor_set_pid(port, p, i, d)                    : 設定 PID 倍率參數 (0~100，50=原廠值)
# motor_run_degrees(port, speed, degrees, stop)   : 轉動相對角度 (-2499~2499)，stop 必填
# motor_track_target(port, speed, angle, stop)    : 走最短路徑轉到絕對角度 (0~359)，stop 必填
#                                                    (舊名 motor_run_target 仍可用)
# set_motor_inverted(port, inverted=True)         : 設定馬達正/反裝
# drive(l_port, r_port, l_speed, r_speed)         : 雙馬達同步驅動
# drive_stop(l_port, r_port, stop)                : 雙馬達停止，stop 必填，同 motor_stop 的 4 種狀態
# stop_all(stop)                                  : 全域緊急停止所有馬達，stop 必填
# reset_angle(port)                               : 將該孔馬達累積角度歸零
#
# stop 參數說明：1=coast(滑行) 2=brake(煞車) 3=hold(鎖死) 4=continue(維持現狀/續轉)
#               可傳整數 1~4，或字串常數 STOP_COAST/STOP_BRAKE/STOP_HOLD/STOP_CONTINUE
#               - motor_run_degrees/motor_track_target(走角度)：continue=到位後維持速度續轉
#               - motor_stop/drive_stop/stop_all(純停止指令)：continue=不送任何指令，
#                 馬達維持呼叫前的狀態（還在轉就繼續轉、已停就繼續停著）
#
# [馬達數據讀取 Motor Reading]
# get_motor_angle(port)                  : 讀取馬達相對累積角度
# get_motor_abs_angle(port)              : 讀取馬達硬體絕對角度 (0~359)
# get_motor_speed(port)                  : 讀取馬達目前轉速
#
# [感測器數據讀取 Sensor Reading]
# get_ultrasonic_distance(port)          : 讀取超音波距離 (mm)
# get_touch_force(port)                  : 讀取觸碰/力量感測器數值
# get_color_color(port)                  : 讀取官方顏色代碼 (0~10)
# get_color_reflection(port)             : 讀取反射光強度 (0~100)
# get_color_rgb(port)                    : 讀取 RGB 數值陣列 (R, G, B)
# get_color_hsv(port)                    : 讀取 HSV 數值陣列 (H, S, V)
# get_color_hue(port)                    : 讀取色彩相角 Hue (0~360)
# get_color_sat(port)                    : 讀取色彩飽和度 Saturation (0~100)
# get_color_val(port)                    : 讀取色彩明度 Value (0~100)
# get_color_red(port)                    : 獨立讀取紅色數值
# get_color_green(port)                  : 獨立讀取綠色數值
# get_color_blue(port)                   : 獨立讀取藍色數值
#
# [系統與底層 System & Low-Level]
# get_voltage()                          : 讀取擴充板電池電壓 (V)
# get_device_id(port)                    : 讀取接在該孔的裝置 ID
# get_port_raw(port)                     : 讀取底層原始資料傳輸
# set_port_mode(port, mode)              : 強制設定該孔位的底層通訊模式
# keep_alive()                           : [非同步] 手動發送保活心跳
# keep_alive_wait(ms)                    : [非同步] 附帶保活心跳的延遲等待
# run_task(coro)                         : [非同步] 執行非同步任務
#
# ⚠ 參數驗證規則（超出範圍時的處理方式）：
#   - port_num/left_port/right_port 不是 1~6 的整數，或 drive()/drive_stop() 兩孔位相同
#     → 直接拋出 ValueError（沒有安全的預設值可以猜，必須立刻修正呼叫端）
#   - mode 不是合法的 MODE_* 常數 → 直接拋出 ValueError
#   - speed/power/PID 倍率超出範圍 → 靜默夾到邊界值（不印提示，夾到極值符合直覺）
#   - degrees 超出 -2499~2499 → 夾到邊界值並印一行提示（截斷會讓 stop 動作提早觸發）
#   - stop 是真的無法辨識的值（範圍外整數、亂打字串等）→ 印一行提示、自動改用 brake 模式
#     （stop=continue 本身不是錯誤，見上方 stop 參數說明）
# ==============================================================================
