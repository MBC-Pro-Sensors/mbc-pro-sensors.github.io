# MBC EXP6 SPIKE App Library Installer
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式適用於 Lego Education SPIKE App 版本 3.4.3
# [EN] This program is designed for Lego Education SPIKE App version 3.4.3
#
# 請在 SPIKE App 中執行此程式，即可將函數庫安裝到主機內部的儲存空間中。

import sys

# 教育版 (SPIKE 3.x) 的全域儲存路徑固定為 /flash
filename = "/flash/MBC_exp6_SPIKE_App_Lib.py"
print("=========================================")
print("系統環境路徑:", sys.path)
print("開始安裝 " + filename + " ...")

source_code = """\
# Python Library for EXP6 Smart Expansion Board for Official SPIKE Prime App
# Author : MBC robotics
# Date   : 2026.07
#
# !! 此函式庫專供官方 SPIKE App 使用 (非Pybricks) !!
# !! This library is designed for the official SPIKE App (Not for Pybricks) !!

import device, distance_sensor, time
from hub import port

_instances = []

def _default_instance():
    if not _instances:
        raise RuntimeError("請先建立擴充板物件 (例: exp = MBC_EXP6(port.F))")
    return _instances[-1]

DEV_NONE = 0
DEV_FORCE = 1
DEV_COLOR = 2
DEV_ULTRASONIC = 4
DEV_MOTOR = 5

DIR_HOLD = 0
DIR_CW = 1
DIR_CCW = 2
DIR_COAST = 3
DIR_BRAKE = 4

# 停止狀態（motor_stop / stop_all / motor_run_degrees / motor_track_target 的必填參數；
# 可傳字串常數或整數碼 1~4，大小寫不拘）
# 整數碼(1-based，與 Pybricks 庫一致)：1=coast 滑行、2=brake 煞車、3=hold 鎖死、4=continue 續轉/維持現狀。
# continue 在不同函式家族的意義不同：
#   - motor_run_degrees/motor_track_target(走角度)：到位後不切換停止模式，維持原速度續轉。
#   - motor_stop/drive_stop/stop_all(純停止指令)：不送出任何指令，讓馬達維持呼叫前的狀態
#     (還在轉就繼續轉、已經停了就繼續停著)——這是刻意合法的選項，不是無法辨識的錯誤。
# ⚠ 傳入真的無法辨識的值（範圍外的整數、亂打的字串等）才會印一行提示、自動改用 brake
# 煞車，不會中斷程式──brake 介於「滑行(可能讓機構掉落)」與「鎖死(可能卡住機構)」之間，
# 是誤用時最安全的預設。
STOP_COAST    = "coast"     # 滑行           (= 1)
STOP_BRAKE    = "brake"     # 被動煞車       (= 2)（傳 "break" 亦視為 brake）
STOP_HOLD     = "hold"      # 位置鎖死       (= 3)
STOP_CONTINUE = "continue"  # 走角度：到位後續轉；純停止指令：不送指令、維持現狀 (= 4)

# 停止狀態字串 → 韌體協議碼。兩種情境的編碼不同：
#   motor_stop / stop_all：單馬達指令 L2（coast=3, hold=4, brake=5）
#   motor_run_degrees：走角度 Method C 的 stop 欄位（coast=0, brake=1, hold=2, continue=3）
_STOP_L2         = {"coast": 3, "hold": 4, "brake": 5}
_STOP_COMPLETION = {"coast": 0, "brake": 1, "hold": 2, "continue": 3}
# 整數碼 → 停止狀態名。採 1-based（與 Pybricks 庫一致，跟孔號 1~6 風格相同，較直覺）：
#   1=coast 滑行、2=brake 煞車、3=hold 鎖死、4=continue 續轉（continue 僅走角度可用）。
# （韌體走角度 Method C 內部仍是 0-based，_stop_to_completion 會做轉換，使用者不用管。）
# 讓使用者傳字串或整數皆可；早期只吃字串時，傳整數會被 str() 成 "1" 之類、查無此鍵而
# 靜默退回預設（走角度→hold、停止→coast），造成「四種停止狀態全部沒作用」的假象。
_STOP_INT        = {1: "coast", 2: "brake", 3: "hold", 4: "continue"}
_VALID_STOP_NAMES = ("coast", "brake", "hold", "continue")

def _norm_stop(stop):
    # 接受 STOP_* 字串常數、"coast"/"brake"/"hold"/"continue"（大小寫不拘、"break" 亦當 brake），
    # 或整數碼 1~4（含數字字串 "1"~"4"）。任何無法辨識的值印一行提示、改用 brake 煞車，不拋錯──
    # brake 是誤用時最安全的中間狀態(見上方 STOP_* 常數區塊說明)，讓程式能繼續跑、不因打錯
    # 一個停止碼就整段程式中斷。
    if isinstance(stop, bool):        # True/False 先轉 1/0，避免被 str() 成 "true"/"false"
        stop = int(stop)
    if isinstance(stop, int):
        if stop in _STOP_INT:
            return _STOP_INT[stop]
    else:
        s = str(stop).strip().lower()
        if s == "break":
            s = "brake"
        if s in ("1", "2", "3", "4"):     # 數字字串比照整數碼（1-based）
            return _STOP_INT[int(s)]
        if s in _VALID_STOP_NAMES:
            return s
    print("[EXP6] stop=%r 不符合定義範圍(1:coast, 2:brake, 3:hold, 4:continue)，"
          "已改用 brake 模式" % (stop,))
    return "brake"

def _stop_to_l2(stop):
    # motor_stop / drive_stop / stop_all 共用：continue 代表「維持現狀、不送指令」，回傳
    # None 讓呼叫端跳過整次傳送(不當成無法辨識的錯誤處理，也不印提示)。coast/brake/hold
    # 三個合法名稱 _norm_stop 保證都在 _STOP_L2 裡，不會有 KeyError。
    name = _norm_stop(stop)
    if name == "continue":
        return None
    return _STOP_L2[name]

def _stop_to_completion(stop):
    return _STOP_COMPLETION[_norm_stop(stop)]

MODE_SPEED = 0
MODE_ANGLE = 1
MODE_ABS_ANGLE = 2
MODE_RESET = 3
MODE_COLOR = 10
MODE_RGB = 11
MODE_HSV = 12
MODE_DISTANCE = 20
MODE_FORCE = 30

# ── 參數驗證副程式 / Parameter validation helpers ──────────────────
# 分兩類（與 Pybricks 版邏輯一致）：
#   _check_*  會拋 ValueError──用在「超出範圍就是靜默做錯事」的參數：孔位超界／重複會
#             撞上協議算式，別名成完全不相關的指令；mode 是離散合法值集合，沒有「最接近」
#             可猜。這三種沒有安全的預設值可以退，只能讓呼叫方立刻修正。
#   _clamp*   不拋錯──用在「夾到範圍邊界就是合理結果」的參數（speed/power/PID 倍率夾到
#             極值＝全速/全開，符合直覺）。_clamp_warn 額外印一行提示，只用在「靜默夾範圍
#             會嚴重改變行為」的參數（degrees 被截斷＝提早觸發煞車動作）。
def _check_port(port_num, name="port"):
    if isinstance(port_num, bool) or not isinstance(port_num, int) or not (1 <= port_num <= 6):
        raise ValueError("%s=%r 不是有效孔位，必須是 1~6 的整數" % (name, port_num))

def _check_distinct_ports(port_a, port_b):
    if port_a == port_b:
        raise ValueError(
            "left_port 與 right_port 不能是同一孔位(%r)，會被協議的 left*10+right 算式"
            "誤解成單馬達 PID 指令(port*11)" % (port_a,))

_VALID_MODES = (MODE_SPEED, MODE_ANGLE, MODE_ABS_ANGLE, MODE_RESET,
                MODE_COLOR, MODE_RGB, MODE_HSV, MODE_DISTANCE, MODE_FORCE)

def _check_mode(mode):
    if mode not in _VALID_MODES:
        raise ValueError("mode=%r 不是合法的 MODE_* 常數" % (mode,))

def _clamp(v, lo, hi, name):
    v = int(v)
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v

def _clamp_warn(v, lo, hi, name):
    v = int(v)
    if v < lo or v > hi:
        c = lo if v < lo else hi
        print("[EXP6] %s=%d 超出範圍，已限制在 %d~%d 之間" % (name, v, lo, hi))
        return c
    return v

def _cache_validated(build_fn):
    # 參數暫存器：若本次呼叫參數跟上次完全相同，直接複用上次組好的封包內容，不重新驗證、
    # 不重新做角度/PID 換算。參數不同（或這是第一次呼叫）才真正跑 build_fn；build_fn 內部
    # 驗證失敗會直接拋出，失敗的呼叫不會被寫入快取，下次同樣的錯誤參數仍會重新驗證並報錯。
    cache = [None, None]   # [上次的參數 tuple, 上次的結果]
    def wrapper(*args):
        if cache[0] == args:
            return cache[1]
        result = build_fn(*args)
        cache[0], cache[1] = args, result
        return result
    return wrapper

# ── 封包組建副程式 / Packet-building helpers ──────────────────────
# 純函式：只依參數算出 (l1,l2,l3,l4)，不碰 self、不送封包。跟 Pybricks 版的 _build_* 系列
# 對應，讓兩個庫的驗證/組包邏輯保持一致；實際傳送仍由各 method 呼叫 self._send()。
def _build_motor_run(port_num, speed):
    _check_port(port_num)
    speed = _clamp(speed, -100, 100, "speed")
    return (port_num * 11, DIR_CW if speed >= 0 else DIR_CCW, abs(speed), 0)

def _build_motor_power(port_num, power):
    _check_port(port_num)
    power = _clamp(power, -100, 100, "power")
    return (port_num * 10, DIR_CW if power >= 0 else DIR_CCW, abs(power), 0)

def _build_motor_stop(port_num, stop):
    _check_port(port_num)
    l2 = _stop_to_l2(stop)
    if l2 is None:              # stop=continue：維持現狀，不送任何指令
        return None
    return (port_num * 10, l2, 0, 0)

def _build_motor_set_pid(port_num, p, i, d):
    _check_port(port_num)
    p = _clamp(p, 0, 100, "p")
    i = _clamp(i, 0, 100, "i")
    d = _clamp(d, 0, 100, "d")
    return (80 + port_num, p, i, d)

def _build_motor_run_degrees(port_num, speed, degrees, stop):
    _check_port(port_num)
    speed = _clamp(speed, -100, 100, "speed")
    # degrees 被截斷會讓 stop 動作提早觸發(見上方 _clamp_warn 說明)，所以夾範圍時要印提示；
    # Method C：停止狀態佔用 L3 高位，故最大角度只能到 2499。
    degrees = _clamp_warn(degrees, -2499, 2499, "degrees")
    deg = abs(int(degrees))
    op = 8 if degrees >= 0 else 9
    l3 = _stop_to_completion(stop) * 25 + deg // 100   # L3 = stop*25 + 百位(0~24)
    return (port_num * 10 + op, abs(int(speed)), l3, deg % 100)

def _build_motor_track_target(port_num, speed, angle, stop):
    _check_port(port_num)
    speed = _clamp(speed, -100, 100, "speed")
    # Method C(比照 motor_run_degrees)：目標角度只到 360，百位數只需 0~3，用「除4」
    # 把停止狀態疊進 L3(stop*4 + 百位，最大 3*4+3=15，遠低於 100)。
    # angle 本質上是週期性的(540°等於180°)，直接取模即可，不需要額外驗證/夾範圍。
    t = int(angle) % 360
    l3 = _stop_to_completion(stop) * 4 + t // 100
    return (port_num * 10 + 7, abs(int(speed)), l3, t % 100)

def _build_set_inverted(port_num, inverted):
    _check_port(port_num)
    return (76, port_num, 1 if inverted else 0, 0)

def _build_drive(left_port, right_port, left_speed, right_speed):
    _check_port(left_port, "left_port")
    _check_port(right_port, "right_port")
    _check_distinct_ports(left_port, right_port)
    left_speed = _clamp(left_speed, -100, 100, "left_speed")
    right_speed = _clamp(right_speed, -100, 100, "right_speed")
    l2 = (0 if left_speed >= 0 else 2) | (0 if right_speed >= 0 else 1)
    return (left_port * 10 + right_port, l2, abs(left_speed), abs(right_speed))

def _build_drive_stop(left_port, right_port, stop):
    _check_port(left_port, "left_port")
    _check_port(right_port, "right_port")
    _check_distinct_ports(left_port, right_port)
    l2 = _stop_to_l2(stop)
    if l2 is None:              # stop=continue：維持現狀，不送任何指令
        return None
    return (left_port * 10 + right_port, l2, 0, 0)

# 參數暫存器：對每個 _build_* 分別套用獨立快取，同一指令連續呼叫相同參數時（例如控制
# 迴圈每 tick 都送同樣的 drive(...)），第二次以後直接跳過驗證與組包運算。
_build_motor_run          = _cache_validated(_build_motor_run)
_build_motor_power        = _cache_validated(_build_motor_power)
_build_motor_stop         = _cache_validated(_build_motor_stop)
_build_motor_set_pid      = _cache_validated(_build_motor_set_pid)
_build_motor_run_degrees  = _cache_validated(_build_motor_run_degrees)
_build_motor_track_target = _cache_validated(_build_motor_track_target)
_build_set_inverted       = _cache_validated(_build_set_inverted)
_build_drive              = _cache_validated(_build_drive)
_build_drive_stop         = _cache_validated(_build_drive_stop)

class MBC_EXP6:
    DEV_NONE = DEV_NONE
    DEV_FORCE = DEV_FORCE
    DEV_COLOR = DEV_COLOR
    DEV_ULTRASONIC = DEV_ULTRASONIC
    DEV_MOTOR = DEV_MOTOR

    DIR_HOLD = DIR_HOLD
    DIR_CW = DIR_CW
    DIR_CCW = DIR_CCW
    DIR_COAST = DIR_COAST
    DIR_BRAKE = DIR_BRAKE

    STOP_COAST = STOP_COAST
    STOP_BRAKE = STOP_BRAKE
    STOP_HOLD = STOP_HOLD
    STOP_CONTINUE = STOP_CONTINUE

    MODE_SPEED = MODE_SPEED
    MODE_ANGLE = MODE_ANGLE
    MODE_ABS_ANGLE = MODE_ABS_ANGLE
    MODE_RESET = MODE_RESET
    MODE_COLOR = MODE_COLOR
    MODE_RGB = MODE_RGB
    MODE_HSV = MODE_HSV
    MODE_DISTANCE = MODE_DISTANCE
    MODE_FORCE = MODE_FORCE

    def __init__(self, port_num, multitask=False):
        self._port = port_num
        self.v = 0
        self.d = [0] * 6
        self._la = [0] * 6
        self._aa = [0] * 6
        self._port_mode_cache = {}
        self._inverted = {i: False for i in range(1, 7)}   # 各孔正/反裝，預設全部正裝
        self._last_send_time = time.ticks_ms()
        self._last_cmd = None
        self._throttle_ms = 20

        # 1. 確保 SPIKE 系統已經掛載 LPF2 模擬感測器且收到數據 (利用 R7 判斷)
        for _ in range(100):
            r = device.data(self._port)
            if r and len(r) >= 8 and r[6] != 0:
                break
            time.sleep(0.02)

        # 1.5 動態校準 RTOS 真實輪詢週期
        try:
            last_tick = time.ticks_ms()
            last_d = device.data(self._port)
            for _ in range(10):
                while True:
                    cur = device.data(self._port)
                    if cur != last_d:
                        break
                    time.sleep(0.001)
                last_d = cur
            period = time.ticks_diff(time.ticks_ms(), last_tick) / 10
            # 依據實測要求，將等待時間放寬為真實週期的 2 倍，保證 100% 絕對不掉包
            self._throttle_ms = max(20, int(period * 2))
        except Exception:
            self._throttle_ms = 25

        # 2. 發送首次硬體重置 (L1=0, L2=L3=L4=0)
        self._send(0, 0, 0, 0)
        time.sleep(0.1)
        self.update() # 強制更新一次緩衝區獲取真實電壓

        # 將所有孔位預設切換至角度模式 (1)
        for i in range(1, 7):
            self.set_port_mode(i, self.MODE_ANGLE)

        time.sleep(0.05)
        self.update()
        for i in range(1, 7):
            self._la[i-1] = self.d[i-1]
            self._aa[i-1] = 0

        _instances.append(self)

    def update(self):
        r = device.data(self._port)
        if r and len(r) >= 8:
            new_d = []
            for x in r[:6]:
                val = x & 0xFFFF
                if val >= 32768:
                    val -= 65536
                new_d.append(val)

            # 更新累積角度
            for i in range(6):
                if self._port_mode_cache.get(i+1) == self.MODE_ANGLE:
                    c = new_d[i]
                    d = (c - self._la[i]) & 0xFFFF
                    if d > 32767:
                        d -= 65536
                    self._aa[i] += d
                    self._la[i] = c

            self.d = new_d
            self.v = (r[6] & 0xFFF) / 100.0
        return self.d

    def _send(self, l1, l2, l3, l4):
        # 1. 指令狀態去重 (Deduplication)：相同狀態直接無視，0延遲返回！
        cmd = [max(0, min(100, int(x))) for x in (l1, l2, l3, l4)]
        if cmd == self._last_cmd:
            return

        # 2. 自適應智慧節流閥 (Adaptive Smart Throttle)
        now = time.ticks_ms()
        try:
            elapsed = time.ticks_diff(now, self._last_send_time)
        except AttributeError:
            self._last_send_time = now
            elapsed = self._throttle_ms

        if elapsed < self._throttle_ms:
            time.sleep((self._throttle_ms - elapsed) / 1000.0)

        distance_sensor.show(self._port, cmd)

        # 3. 更新快取與最後發送時間
        self._last_cmd = cmd
        self._last_send_time = time.ticks_ms()

    def _send_oneshot(self, l1, l2, l3, l4):
        self._send(l1, l2, l3, l4)
        # 動態等待，確保指令已發出 (給予 2.5 倍安全餘裕)
        time.sleep(self._throttle_ms * 2.5 / 1000.0)
        # 替換為空包彈，把 STM32 的快取洗掉 (防止最後一個指令被 RTOS 無限重傳)
        self._send(100, 0, 0, 0) # 換成絕對安全的 Dummy Payload，清空 STM32 快取

    # ==========================
    # 核心控制指令
    # ==========================
    def motor_run(self, port_num, speed):
        self._send(*_build_motor_run(port_num, speed))

    def motor_power(self, port_num, power):
        self._send(*_build_motor_power(port_num, power))

    def motor_stop(self, port_num, stop):
        pkt = _build_motor_stop(port_num, stop)
        if pkt is None:   # stop=continue：維持現狀，不送任何指令
            return
        self._send(*pkt)

    def motor_set_pid(self, port_num, p, i, d):
        self._send(*_build_motor_set_pid(port_num, p, i, d))

    def motor_run_degrees(self, port_num, speed, degrees, stop):
        self._send_oneshot(*_build_motor_run_degrees(port_num, speed, degrees, stop))

    def motor_track_target(self, port_num, speed, angle, stop):
        self._send_oneshot(*_build_motor_track_target(port_num, speed, angle, stop))
    motor_run_target = motor_track_target   # 相容別名（舊名）

    def set_motor_inverted(self, port_num, inverted=True):
        pkt = _build_set_inverted(port_num, bool(inverted))   # 先驗證 port_num，通過才更新本地狀態
        self._inverted[port_num] = bool(inverted)
        self._send(*pkt)

    def set_port_mode(self, port_num, mode):
        _check_port(port_num)
        _check_mode(mode)
        if mode == self.MODE_RESET:
            self._send(69 + port_num, mode, 0, 0)
            time.sleep(0.05)
            self._send(100, 0, 0, 0) # Oneshot 防背景重送
            # 歸零指令會自動切回角度模式，這裡更新快取
            self._port_mode_cache[port_num] = self.MODE_ANGLE
        else:
            self._send(69 + port_num, mode, 0, 0)
            self._port_mode_cache[port_num] = mode
            time.sleep(0.02)

    def drive(self, left_port, right_port, left_speed, right_speed):
        self._send(*_build_drive(left_port, right_port, left_speed, right_speed))

    def drive_stop(self, left_port, right_port, stop):
        pkt = _build_drive_stop(left_port, right_port, stop)
        if pkt is None:   # stop=continue：維持現狀，不送任何指令
            return
        self._send(*pkt)

    def stop_all(self, stop):
        # 逐孔送停止指令以支援 coast/brake/hold（不再用 (0,0,0,0) 硬重置，避免歸零角度/重置格式的副作用）。
        l2 = _stop_to_l2(stop)
        if l2 is None:   # stop=continue：維持所有馬達現狀，不送任何指令
            return
        for port_num in range(1, 7):
            self._send(port_num * 10, l2, 0, 0)

    def reset_angle(self, port_num):
        self.set_port_mode(port_num, self.MODE_RESET)
        self.set_port_mode(port_num, self.MODE_ANGLE)

        # 強制等待 LPF2 回傳的真實角度歸零，否則會發生巨大的角度跳變
        for _ in range(20):
            self.update()
            if abs(self.d[port_num - 1]) < 5:
                break
            time.sleep(0.02)

        self.update()
        self._la[port_num - 1] = self.d[port_num - 1]
        self._aa[port_num - 1] = 0

    # ==========================
    # 狀態讀取指令
    # ==========================
    def _ensure_mode(self, port_num, mode):
        if self._port_mode_cache.get(port_num) != mode:
            self.set_port_mode(port_num, mode)
            time.sleep(0.05) # 確保模式切換且資料回傳

    def get_port_raw(self, port_num):
        # 孔位驗證放這裡：get_ultrasonic_distance/get_touch_force/get_motor_abs_angle/
        # get_motor_speed/_get_rgb(顏色系列) 全都經由這裡讀值，一次驗證全部涵蓋。
        _check_port(port_num)
        self.update()
        return self.d[port_num - 1]

    def get_ultrasonic_distance(self, port_num):
        self._ensure_mode(port_num, self.MODE_DISTANCE)
        return self.get_port_raw(port_num)

    def get_touch_force(self, port_num):
        self._ensure_mode(port_num, self.MODE_FORCE)
        return self.get_port_raw(port_num)

    def get_motor_angle(self, port_num):
        _check_port(port_num)
        self._ensure_mode(port_num, self.MODE_ANGLE)
        self.update()
        return self._aa[port_num - 1]

    def get_motor_abs_angle(self, port_num):
        self._ensure_mode(port_num, self.MODE_ABS_ANGLE)
        return self.get_port_raw(port_num)

    def get_motor_speed(self, port_num):
        self._ensure_mode(port_num, self.MODE_SPEED)
        return self.get_port_raw(port_num)

    def _get_rgb(self, port_num):
        self._ensure_mode(port_num, self.MODE_COLOR)
        val = self.get_port_raw(port_num)
        r = ((val >> 11) & 0x1F) * 100 // 31
        g = ((val >> 5) & 0x3F) * 100 // 63
        b = (val & 0x1F) * 100 // 31
        return (r, g, b)

    def get_color_color(self, port_num):
        # 採用 HSV 色相/飽和度/明度 換算來精準匹配樂高官方顏色代碼
        h, s, v = self.get_color_hsv(port_num)

        if v < 15:
            return 0 # 0 = Black

        if s < 25:
            if v > 60:
                return 10 # 10 = White
            else:
                return 0 # 0 = Black (太暗的灰白)

        # 根據 Hue (色相) 0~360 判斷
        if h < 20 or h > 340:
            return 9 # 9 = Red
        elif 30 <= h <= 80:
            return 7 # 7 = Yellow
        elif 100 <= h <= 150:
            return 5 # 5 = Green
        elif 160 <= h <= 200:
            return 4 # 4 = Light Blue (Cyan)
        elif 210 <= h <= 270:
            return 3 # 3 = Blue
        elif 280 <= h <= 330:
            return 1 # 1 = Pink (Magenta)

        return 0

    def get_color_reflection(self, port_num):
        r, g, b = self._get_rgb(port_num)
        return max(r, g, b)

    def get_color_rgb(self, port_num):
        return self._get_rgb(port_num)

    def get_color_hsv(self, port_num):
        r, g, b = self._get_rgb(port_num)
        cmax = max(r, g, b)
        cmin = min(r, g, b)
        delta = cmax - cmin
        h = 0
        if delta == 0: h = 0
        elif cmax == r: h = 60 * (((g - b) / delta) % 6)
        elif cmax == g: h = 60 * (((b - r) / delta) + 2)
        elif cmax == b: h = 60 * (((r - g) / delta) + 4)
        s = 0 if cmax == 0 else (delta / cmax) * 100
        v = cmax
        return (int(h), int(s), int(v))

    def get_color_hue(self, port_num): return self.get_color_hsv(port_num)[0]
    def get_color_sat(self, port_num): return self.get_color_hsv(port_num)[1]
    def get_color_val(self, port_num): return self.get_color_hsv(port_num)[2]
    def get_color_red(self, port_num): return self._get_rgb(port_num)[0]
    def get_color_green(self, port_num): return self._get_rgb(port_num)[1]
    def get_color_blue(self, port_num): return self._get_rgb(port_num)[2]

    def get_device_id(self, port_num):
        # 簡單回傳 5 (馬達) 以維持相容性
        _check_port(port_num)
        return self.DEV_MOTOR

    def get_voltage(self):
        self.update()
        return self.v


# ==========================
# 程式導向 API (與 Pybricks 版 100% 相容)
# ==========================
def exp_motor_run(*a):         return _default_instance().motor_run(*a)
def exp_motor_power(*a):       return _default_instance().motor_power(*a)
def exp_motor_stop(*a):         return _default_instance().motor_stop(*a)
def exp_motor_set_pid(*a):      return _default_instance().motor_set_pid(*a)
def exp_motor_run_degrees(*a):  return _default_instance().motor_run_degrees(*a)
def exp_motor_track_target(*a): return _default_instance().motor_track_target(*a)
def exp_motor_run_target(*a):   return _default_instance().motor_run_target(*a)   # 相容別名 / alias
def exp_set_motor_inverted(*a): return _default_instance().set_motor_inverted(*a)
def exp_set_port_mode(*a):     return _default_instance().set_port_mode(*a)
def exp_drive(*a):             return _default_instance().drive(*a)
def exp_drive_stop(*a):        return _default_instance().drive_stop(*a)
def exp_stop_all(*a):          return _default_instance().stop_all(*a)
def exp_reset_angle(*a):       return _default_instance().reset_angle(*a)

def exp_get_port_raw(*a):            return _default_instance().get_port_raw(*a)
def exp_get_ultrasonic_distance(*a): return _default_instance().get_ultrasonic_distance(*a)
def exp_get_touch_force(*a):         return _default_instance().get_touch_force(*a)

def exp_get_motor_angle(*a):     return _default_instance().get_motor_angle(*a)
def exp_get_motor_abs_angle(*a): return _default_instance().get_motor_abs_angle(*a)
def exp_get_motor_speed(*a):     return _default_instance().get_motor_speed(*a)

def exp_get_color_color(*a):      return _default_instance().get_color_color(*a)
def exp_get_color_reflection(*a): return _default_instance().get_color_reflection(*a)
def exp_get_color_rgb(*a):        return _default_instance().get_color_rgb(*a)
def exp_get_color_hsv(*a):        return _default_instance().get_color_hsv(*a)
def exp_get_color_hue(*a):        return _default_instance().get_color_hue(*a)
def exp_get_color_sat(*a):        return _default_instance().get_color_sat(*a)
def exp_get_color_val(*a):        return _default_instance().get_color_val(*a)
def exp_get_color_red(*a):        return _default_instance().get_color_red(*a)
def exp_get_color_green(*a):      return _default_instance().get_color_green(*a)
def exp_get_color_blue(*a):       return _default_instance().get_color_blue(*a)

def exp_get_device_id(*a): return _default_instance().get_device_id(*a)
def exp_get_voltage():     return _default_instance().get_voltage()

def exp_run_task(coro):
    raise NotImplementedError("SPIKE App 版本不支援 async 任務。")
def run_task(coro):
    raise NotImplementedError("SPIKE App 版本不支援 async 任務。")
def keep_alive():
    pass
def keep_alive_wait(ms):
    time.sleep(ms / 1000.0)

__all__ = [
    "exp_run_task",
    "run_task", "keep_alive", "keep_alive_wait",
    "DEV_NONE", "DEV_FORCE", "DEV_COLOR", "DEV_ULTRASONIC", "DEV_MOTOR",
    "DIR_HOLD", "DIR_CW", "DIR_CCW", "DIR_COAST", "DIR_BRAKE",
    "STOP_COAST", "STOP_BRAKE", "STOP_HOLD", "STOP_CONTINUE",
    "MODE_SPEED", "MODE_ANGLE", "MODE_ABS_ANGLE", "MODE_RESET",
    "MODE_COLOR", "MODE_RGB", "MODE_HSV", "MODE_DISTANCE", "MODE_FORCE",
    "exp_motor_run", "exp_motor_power",
    "exp_motor_stop",
    "exp_motor_set_pid",
    "exp_motor_run_degrees", "exp_motor_track_target", "exp_motor_run_target",
    "exp_set_motor_inverted",
    "exp_drive", "exp_drive_stop",
    "exp_stop_all", "exp_reset_angle",
    "exp_get_port_raw",
    "exp_get_motor_angle", "exp_get_motor_abs_angle", "exp_get_motor_speed",
    "exp_get_ultrasonic_distance",
    "exp_get_touch_force",
    "exp_get_color_color", "exp_get_color_reflection",
    "exp_get_color_rgb",   "exp_get_color_hsv",
    "exp_get_color_hue",   "exp_get_color_sat",   "exp_get_color_val",
    "exp_get_color_red",   "exp_get_color_green", "exp_get_color_blue",
    "exp_get_device_id",
    "exp_get_voltage",
    "exp_set_port_mode",
    "MBC_EXP6",
]
"""

try:
    with open(filename, "w") as f:
        f.write(source_code)
    print("安裝成功！(Installation Successful!)")
    print("您現在可以在任何新專案中匯入此庫：")
    print("from MBC_exp6_SPIKE_App_Lib import MBC_EXP6")
except Exception as e:
    print("安裝失敗 (Installation Failed):", repr(e))
print("=========================================")

# ==============================================================================
# 🌟 物件導向可使用的函數列表 (Available Methods for MBC_EXP6 Object)
# ==============================================================================
#
# 假設您建立的物件為 exp = MBC_EXP6(port)
# 以下函數皆透過該物件呼叫，例如：exp.motor_run(1, 50)
#
# [馬達控制 Motor Control]
# motor_run(port, speed)                          : 以速度模式持續轉動 (-100~100)
# motor_power(port, power)                        : 直接輸出 PWM 力量 (-100~100)
# motor_stop(port, stop)                          : 停止馬達，stop 必填(見下方 stop 參數說明)
# motor_set_pid(port, p, i, d)                    : 設定 PID 倍率參數 (0~100，50=原廠值)
# motor_run_degrees(port, speed, degrees, stop)   : 轉動相對角度 (-2499~2499)，stop 必填
# motor_track_target(port, speed, angle, stop)    : 走最短路徑轉到絕對角度 (0~359)，stop 必填
#                                                    (舊名 motor_run_target 仍可用)
# set_motor_inverted(port, inverted=True)         : 設定馬達正/反裝
# drive(l_port, r_port, l_speed, r_speed)         : 雙馬達同步驅動
# drive_stop(l_port, r_port, stop)                : 雙馬達停止，stop 必填，同 motor_stop 的 4 種狀態
# stop_all(stop)                                  : 全域緊急停止所有馬達，stop 必填
# reset_angle(port)                               : 將該孔馬達累積角度歸零
#
# stop 參數說明：1=coast(滑行) 2=brake(煞車) 3=hold(鎖死) 4=continue(維持現狀/續轉)
#               可傳整數 1~4，或字串常數 STOP_COAST/STOP_BRAKE/STOP_HOLD/STOP_CONTINUE
#               - motor_run_degrees/motor_track_target(走角度)：continue=到位後維持速度續轉
#               - motor_stop/drive_stop/stop_all(純停止指令)：continue=不送任何指令，
#                 馬達維持呼叫前的狀態（還在轉就繼續轉、已停就繼續停著）
#
# [馬達數據讀取 Motor Reading]
# get_motor_angle(port)                  : 讀取馬達相對累積角度
# get_motor_abs_angle(port)              : 讀取馬達硬體絕對角度 (0~359)
# get_motor_speed(port)                  : 讀取馬達目前轉速
#
# [感測器數據讀取 Sensor Reading]
# get_ultrasonic_distance(port)          : 讀取超音波距離 (mm)
# get_touch_force(port)                  : 讀取觸碰/力量感測器數值
# get_color_color(port)                  : 讀取官方顏色代碼 (0~10)
# get_color_reflection(port)             : 讀取反射光強度 (0~100)
# get_color_rgb(port)                    : 讀取 RGB 數值陣列 (R, G, B)
# get_color_hsv(port)                    : 讀取 HSV 數值陣列 (H, S, V)
# get_color_hue(port)                    : 讀取色彩相角 Hue (0~360)
# get_color_sat(port)                    : 讀取色彩飽和度 Saturation (0~100)
# get_color_val(port)                    : 讀取色彩明度 Value (0~100)
# get_color_red(port)                    : 獨立讀取紅色數值
# get_color_green(port)                  : 獨立讀取綠色數值
# get_color_blue(port)                   : 獨立讀取藍色數值
#
# [系統與底層 System & Low-Level]
# get_voltage()                          : 讀取擴充板電池電壓 (V)
# get_device_id(port)                    : 讀取接在該孔的裝置 ID
# get_port_raw(port)                     : 讀取底層原始資料傳輸
# set_port_mode(port, mode)              : 強制設定該孔位的底層通訊模式
# keep_alive()                           : [非同步] 手動發送保活心跳
# keep_alive_wait(ms)                    : [非同步] 附帶保活心跳的延遲等待
# run_task(coro)                         : [非同步] 執行非同步任務
#
# ⚠ 參數驗證規則（超出範圍時的處理方式）：
#   - port_num/left_port/right_port 不是 1~6 的整數，或 drive()/drive_stop() 兩孔位相同
#     → 直接拋出 ValueError（沒有安全的預設值可以猜，必須立刻修正呼叫端）
#   - mode 不是合法的 MODE_* 常數 → 直接拋出 ValueError
#   - speed/power/PID 倍率超出範圍 → 靜默夾到邊界值（不印提示，夾到極值符合直覺）
#   - degrees 超出 -2499~2499 → 夾到邊界值並印一行提示（截斷會讓 stop 動作提早觸發）
#   - stop 是真的無法辨識的值（範圍外整數、亂打字串等）→ 印一行提示、自動改用 brake 模式
#     （stop=continue 本身不是錯誤，見上方 stop 參數說明）
# ==============================================================================
