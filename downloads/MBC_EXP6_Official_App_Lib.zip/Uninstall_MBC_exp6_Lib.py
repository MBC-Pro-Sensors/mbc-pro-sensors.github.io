# MBC EXP6 SPIKE App Library Uninstaller
# ℹ️ 版本提醒 (Version Reminder):
# [ZH] 本程式適用於 Lego Education SPIKE App 3.x 與 MINDSTORMS 10.x
# [EN] This program is designed for SPIKE App 3.x and MINDSTORMS 10.x
#
# 請在官方 App 中執行此程式，即可將函數庫從主機中移除。

import os
import sys

# 教育版 (SPIKE 3.x) 的全域儲存路徑固定為 /flash
filename = "/flash/MBC_exp6_SPIKE_App_Lib.py"

print("=========================================")
print("開始移除 " + filename + " ...")

try:
    os.remove(filename)
    print("移除成功！ (Uninstall Successful!)")
except OSError:
    print("函數庫尚未安裝或已經被移除了。 (File not found.)")
except Exception as e:
    print("移除發生錯誤 (Uninstall Failed):", e)
    
print("=========================================")
