# SPIKE 官方 APP 擴充板函數庫 - 範例程式庫

這裡提供了四個針對「樂高 SPIKE App」設計的基礎與進階控制範例，適合老師教學與學生測試使用。

⚠️ **注意：執行範例前，請先確保已經在主機中執行過 `Install_MBC_exp6_Lib.py` 將函數庫安裝完畢！**

---

## 📂 範例說明

本次全面更新的範例程式共包含 6 個檔案，由淺入深涵蓋了函數庫內部的所有 API：

### [01_Motor_Basic.py](01_Motor_Basic.py) (馬達基礎)
涵蓋基礎馬達動力控制：
- `motor_run`, `motor_power` (速度與純電力模式)
- `motor_stop`, `motor_brake` (滑行與煞車)
- `stop_all` (全域停止)

### [02_Motor_Advanced.py](02_Motor_Advanced.py) (馬達進階與編碼器)
涵蓋精確角度控制與 PID 調整：
- `motor_run_degrees`, `motor_run_target` (相對與絕對角度控制)
- `reset_angle`, `get_motor_angle`, `get_motor_abs_angle` (編碼器讀取與歸零)
- `get_motor_speed`, `motor_set_pid` (速度讀取與底層 PID 參數覆寫)

### [03_Drive_Base.py](03_Drive_Base.py) (底盤運動)
涵蓋雙輪底盤的同步控制：
- `drive`, `drive_stop` (直行、原地旋轉、差速轉彎)

### [04_Sensor_Distance_Force.py](04_Sensor_Distance_Force.py) (超音波與力量感測器)
涵蓋常用互動感測器：
- `get_ultrasonic_distance` (超音波測距 mm)
- `get_touch_force` (觸碰與按壓力量百分比)

### [05_Sensor_Color_Pro.py](05_Sensor_Color_Pro.py) (進階色彩分析)
涵蓋所有色彩相關的專業 API：
- `get_color_color`, `get_color_reflection` (官方色碼與反射光)
- `get_color_rgb`, `get_color_red`, `get_color_green`, `get_color_blue` (三原色解析)
- `get_color_hsv`, `get_color_hue`, `get_color_sat`, `get_color_val` (HSV 色彩空間)

### [06_System_Misc.py](06_System_Misc.py) (系統與底層數據)
涵蓋擴充板底層狀態的讀取：
- `get_voltage` (電池電壓即時監控)
- `get_device_id` (裝置辨識碼)
- `get_port_raw`, `set_port_mode` (底層 LPF2 原始數據與模式強制切換)

---

## 🛠️ 使用方式

1. 在 SPIKE 官方 App 建立一個 Python 專案。
2. 開啟您想測試的範例檔案。
3. 將裡面的程式碼全部複製，貼上到 SPIKE App 的視窗中。
4. 確保擴充板有接上電源，並且將主機與擴充板連接好。
5. （重要）確認程式碼中的 `port.F` (擴充板接在哪個孔) 以及馬達/感測器的孔位設定是否符合您的實際硬體接線。
6. 點擊「執行」開始測試。
